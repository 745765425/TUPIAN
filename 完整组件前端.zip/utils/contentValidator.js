// 内容验证和格式化工具
const ContentValidator = {
  // 标题限制
  titleConfig: {
    maxLength: 8,  // 最大字符数
    minLength: 2,  // 最小字符数
    fontSize: '44rpx'
  },

  // 描述内容限制
  contentConfig: {
    maxLength: 60,  // 总字符数限制
    maxLineLength: 20,  // 每行最大字符数
    maxLines: 3,  // 最大行数
    fontSize: '26rpx',
    lineHeight: 1.8
  },

  // 验证并格式化标题
  validateTitle(title) {
    if (!title) return '';
    if (title.length > this.titleConfig.maxLength) {
      return title.substring(0, this.titleConfig.maxLength);
    }
    return title;
  },

  // 验证并格式化内容
  validateContent(content) {
    if (!content) return '';
    
    // 限制总长度
    let formattedContent = content;
    if (content.length > this.contentConfig.maxLength) {
      formattedContent = content.substring(0, this.contentConfig.maxLength);
    }

    // 按行处理
    const lines = formattedContent.split('\n');
    if (lines.length > this.contentConfig.maxLines) {
      formattedContent = lines.slice(0, this.contentConfig.maxLines).join('\n');
    }

    // 处理每行长度
    const processedLines = lines.map(line => 
      line.length > this.contentConfig.maxLineLength 
        ? line.substring(0, this.contentConfig.maxLineLength) 
        : line
    );

    return processedLines.join('\n');
  },

  // 验证完整的内容对象
  validateContentObject(contentObj) {
    return {
      title: {
        text: this.validateTitle(contentObj.title.text),
        fontSize: this.titleConfig.fontSize
      },
      content: {
        text: this.validateContent(contentObj.content.text),
        fontSize: this.contentConfig.fontSize,
        lineHeight: this.contentConfig.lineHeight
      }
    };
  }
};

export default ContentValidator; 
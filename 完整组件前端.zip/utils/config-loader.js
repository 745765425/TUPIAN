// 配置加载工具类
const ConfigLoader = {
  // 读取轮播图配置
  loadSwiperConfig() {
    try {
      const banners = [
        require('../config/banners/banner1'),
        require('../config/banners/banner2'),
        require('../config/banners/banner3')
      ];
      return banners;
    } catch (error) {
      console.error('读取轮播图配置失败:', error);
      return this.getDefaultConfig();
    }
  },

  getDefaultConfig() {
    return [{
      mode: "image",
      mainTitle: "默认标题1",
      subTitle: "默认副标题1",
      description: "默认描述1",
      imageUrl: "/images/default1.png",
      backgroundColor: "#FFE4E1"
    }];
  },

  // 保存配置到文件
  saveSwiperConfig(index, config) {
    try {
      const fs = wx.getFileSystemManager();
      const filePath = `${wx.env.USER_DATA_PATH}/banners/swiper${index + 1}.json`;
      
      fs.writeFileSync(
        filePath,
        JSON.stringify(config, null, 2),
        'utf-8'
      );
      return true;
    } catch (error) {
      console.error('保存配置失败:', error);
      return false;
    }
  },

  // 监听配置文件变化
  watchConfig(callback) {
    const fs = wx.getFileSystemManager();
    // 定期检查配置文件是否更新
    setInterval(() => {
      const newConfig = this.loadSwiperConfig();
      if (newConfig) {
        callback(newConfig);
      }
    }, 5000); // 每5秒检查一次
  }
};

module.exports = ConfigLoader; 
// app.js
import { Performance } from './utils/performance'

App({
  // 先声明 globalData
  globalData: {
    navHeight: 88,
    statusBarHeight: 0,
    contentHeight: 400,
    isDevTools: false,
    performance: Performance
  },

  onLaunch() {
    try {
      // 获取设备信息并保存
      const systemInfo = {
        deviceInfo: wx.getDeviceInfo(),
        windowInfo: wx.getWindowInfo(),
        appBaseInfo: wx.getAppBaseInfo()
      }
      
      // 更新 globalData
      this.globalData = {
        navHeight: 88,
        statusBarHeight: systemInfo.windowInfo.statusBarHeight,
        contentHeight: 400,
        isDevTools: systemInfo.appBaseInfo.platform === 'devtools',
        performance: Performance
      }

      // 设置统一的页面样式
      wx.setPageStyle({
        enablePullDownRefresh: false,
        disableScroll: true
      })

      // 错误监控
      wx.onError((error) => {
        this._handleGlobalError(error);
      });
      
      // 内存警告监控
      wx.onMemoryWarning((res) => {
        console.warn('内存警告', res.level);
        this._handleMemoryWarning(res);
      });

    } catch(e) {
      console.error('初始化失败:', e)
    }
  },

  _handleGlobalError(error) {
    console.error('全局错误:', error);
  },

  _handleMemoryWarning(res) {
    console.warn('内存警告:', res);
  }
})

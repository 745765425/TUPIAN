// 视频播放器组件逻辑
Component({
  properties: {
    src: String,
    title: String,
    isFullScreen: {
      type: Boolean,
      value: false
    },
    isMuted: {
      type: Boolean,
      value: true
    }
  },

  methods: {
    onVideoTap() {
      const videoContext = wx.createVideoContext('myVideo', this);
      if (!this.data.isFullScreen) {
        this.setData({ isFullScreen: true }, () => {
          videoContext.requestFullScreen({ direction: 0 });
        });
      } else {
        videoContext.exitFullScreen();
      }
    },

    onVolumeTap() {
      this.setData({ isMuted: !this.data.isMuted });
    },

    onFullScreenChange(e) {
      this.setData({ 
        isFullScreen: e.detail.fullScreen,
        isMuted: !e.detail.fullScreen
      });
    }
  }
}); 
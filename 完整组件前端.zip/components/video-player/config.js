// 视频播放器通用配置
module.exports = {
  // 视频基础配置
  videoProps: {
    muted: true,
    objectFit: "cover",  // 非全屏时填满容器
    autoplay: true,
    autopause: false,
    showCenterPlayBtn: false,
    showPlayBtn: false,
    controls: false,
    enablePlayGesture: true,
    showFullscreenBtn: false,
    vslideGesture: false,
    vslideGestureInFullscreen: false,
    enableProgressGesture: true,
    playBtnPosition: "center",
    enableAutoRotation: true,
    showScreenLockButton: false,
    showSnapshotButton: false,
    initialTime: 0,
    loop: true,
    showProgress: true,
    showMuteBtn: false
  },

  // 容器类名配置
  containerClass: "popup-video-container",
  videoClass: "popup-video",

  // 事件处理函数名称配置
  eventHandlers: {
    loadedmetadata: "onVideoLoaded",
    error: "onVideoError",
    tap: "onVideoTap",
    play: "onVideoStateChange",
    pause: "onVideoStateChange",
    fullscreenchange: "onFullScreenChange"
  },

  // 全屏模式配置
  fullscreenConfig: {
    objectFit: "contain",  // 全屏时完整显示
    direction: 0  // 自动选择方向
  }
}; 
Component({
  data: {
    banners: []
  },

  lifetimes: {
    attached() {
      console.log('swiper组件已加载');
      this.loadConfig();
    },
    
    // 添加页面显示时重新加载配置
    pageShow() {
      this.loadConfig();
    }
  },

  methods: {
    loadConfig() {
      try {
        console.log('开始加载配置...');
        const ConfigLoader = require('../../utils/config-loader');
        const banners = ConfigLoader.loadSwiperConfig();
        console.log('加载的轮播图配置:', banners);
        
        this.setData({ banners }, () => {
          console.log('配置已更新到视图:', this.data.banners);
        });
      } catch (error) {
        console.error('加载配置失败:', error);
      }
    },

    // 提供刷新方法
    refresh() {
      this.loadConfig();
    }
  }
}); 
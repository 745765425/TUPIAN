// index.js

const ConfigLoader = require('../../utils/config-loader');

Page({
  data: {
    loading: false,
    error: null,
    currentIndex: 0,  // 当前 swiper 索引
    topCurrentIndex: 0,  // 添加这个
    contents: [
      {
        title: {
          text: "美甲喷绘",
          fontSize: "44rpx",
          spacing: "15rpx"
        },
        content: {
          text: "专业的美甲喷绘技术需要持续练习。通过系统学习，掌握色彩搭配技巧，了解不同风格的设计元素。让每一个作品都成为独特的艺术品。",
          fontSize: "26rpx",
          lineHeight: "1.8",
          letterSpacing: "0.8rpx"
        },
        exercises: [
          { name: "热身运动 1" },
          { name: "基础动作 2" },
          { name: "核心训练 3" },
          { name: "力量训练 4" },
          { name: "平衡练习 5" },
          { name: "柔韧训练 6" },
          { name: "协调动作 7" },
          { name: "耐力训练 8" },
          { name: "放松运动 9" },
          { name: "拉伸动作 10" }
        ],
        info: {
          duration: '20 min',
          calories: '95 kcal'
        }
      },
      {
        title: {
          text: "美甲技能提升",
          fontSize: "44rpx",
          spacing: "15rpx"
        },
        content: {
          text: "提升美甲技能需要掌握基础技巧，了解行业最新趋势。从基础护理到高级彩绘技法，我们提供专业培训，帮助您成为优秀的美甲师。",
          fontSize: "26rpx",
          lineHeight: "1.8",
          letterSpacing: "0.8rpx"
        },
        exercises: [
          { name: "上肢训练 1" },
          { name: "肩部练习 2" },
          { name: "胸部训练 3" },
          { name: "背部动作 4" },
          { name: "手臂练习 5" },
          { name: "核心稳定 6" },
          { name: "力量提升 7" },
          { name: "肌肉塑形 8" },
          { name: "动作组合 9" },
          { name: "拉伸放松 10" }
        ],
        info: {
          duration: '25 min',
          calories: '120 kcal'
        }
      },
      {
        title: {
          text: "学习的重要性",
          fontSize: "44rpx",
          spacing: "15rpx"
        },
        content: {
          text: "在美甲行业中，持续学习是保持竞争力的关键。新技术和设计不断涌现，保持学习热情才能立足行业。让我们一起在学习中成长。",
          fontSize: "26rpx",
          lineHeight: "1.8",
          letterSpacing: "0.8rpx"
        },
        exercises: [
          { name: "腹部训练 1" },
          { name: "核心稳定 2" },
          { name: "平板支撑 3" },
          { name: "侧身训练 4" },
          { name: "腰部练习 5" },
          { name: "旋转动作 6" },
          { name: "力量控制 7" },
          { name: "平衡训练 8" },
          { name: "组合动作 9" },
          { name: "整理放松 10" }
        ],
        info: {
          duration: '30 min',
          calories: '150 kcal'
        }
      },
      {
        title: {
          text: "关于我们",
          fontSize: "44rpx",
          spacing: "15rpx"
        },
        content: {
          text: "我们是专注美甲艺术的专业机构，拥有多年经验和优秀师资团队。始终以客户需求为导向，提供个性化服务和培训。追求完美品质。",
          fontSize: "26rpx",
          lineHeight: "1.8",
          letterSpacing: "0.8rpx"
        },
        exercises: [
          { name: "腿部热身 1" },
          { name: "深蹲练习 2" },
          { name: "弓步训练 3" },
          { name: "跳跃动作 4" },
          { name: "臀部练习 5" },
          { name: "小腿训练 6" },
          { name: "平衡控制 7" },
          { name: "力量提升 8" },
          { name: "组合练习 9" },
          { name: "拉伸放松 10" }
        ],
        info: {
          duration: '35 min',
          calories: '180 kcal'
        }
      },
      {
        title: {
          text: "我们的故事",
          fontSize: "44rpx",
          spacing: "15rpx"
        },
        content: {
          text: "十年前，我们开始了这段美丽旅程。从最初的小店到现在的连锁机构，始终保持对美甲艺术的热爱。感谢每位信任我们的顾客。",
          fontSize: "26rpx",
          lineHeight: "1.8",
          letterSpacing: "0.8rpx"
        },
        exercises: [
          { name: "全身热身 1" },
          { name: "综合动作 2" },
          { name: "力量训练 3" },
          { name: "协调练习 4" },
          { name: "爆发训练 5" },
          { name: "耐力提升 6" },
          { name: "平衡控制 7" },
          { name: "动作组合 8" },
          { name: "强化练习 9" },
          { name: "整理放松 10" }
        ],
        info: {
          duration: '40 min',
          calories: '200 kcal'
        }
      }
    ],
    topCards: [
      require('../../config/swiper/card1/card'),
      require('../../config/swiper/card2/card'),
      require('../../config/swiper/card3/card')
    ],
    isListActive: false,
    layoutConfig: {
      bottomOffset: 520,  // movable-view 高度
      navHeight: 88,
      statusBarHeight: 20,
      contentHeight: 400,
      safeTop: 20,
      safeBottom: 34
    },
    scrollIntoView: '',  // 控制滚动位置
    scrollPositions: [0, 0, 0, 0, 0],
    scrollKey: 'scroll_positions_cache',  // 添加缓存key
    showDetail: false,
    currentDetail: null,
    scrollTop: 0,
    isRefreshing: false,
    swiperDirection: '',  // 添加滑动方向的初始值
    isAnimating: false,
    friction: 2,  // 添加摩擦力属性
    slideAnimation: null,
    _lastSwipeTime: null,
    swiperData: {
      titles: [],
      subtitles: [],
      descriptions: [],
      images: []
    },
    startY: 0,
    moveY: 0,
    currentTime: 0,
    showPullArrow: true,  // 添加控制箭头显示的数据
    lastScrollTop: 0,      // 记录上次滚动位置
    debugMode: true,  // 添加调试模式开关
    enableNavigation: true,  // 允许导航
    debugDetailId: 'card1',  // 指定要显示的详情页ID
    lastState: null, // 添加状态记录
    isPlaying: false,  // 添加播放状态标记
    isFullScreen: false,  // 添加全屏状态标记
    touchStartX: 0,      // 记录触摸开始的X坐标
    touchStartY: 0,      // 记录触摸开始的Y坐标
    exitingFullscreen: false,  // 添加退出全屏动画状态
    videoInView: false,  // 添加视频是否在可视区域的标记
    isMuted: true,  // 默认静音
    videoLoaded: false,  // 视频加载状态
    videoBuffer: null,   // 视频缓存对象
    autoPlayEnabled: true,  // 添加自动播放标记
  },

  onLoad(options) {
    console.log('启动场景:', wx.getLaunchOptionsSync().scene);
    console.log('启动参数:', options);

    // 使用新的 API 获取所需信息
    const windowInfo = wx.getWindowInfo();
    const deviceInfo = wx.getDeviceInfo();
    const appBaseInfo = wx.getAppBaseInfo();
    
    // 计算布局配置
    const layoutConfig = {
      bottomOffset: 520,
      navHeight: windowInfo.statusBarHeight + 44,
      statusBarHeight: windowInfo.statusBarHeight,
      contentHeight: 400,
      safeTop: windowInfo.statusBarHeight,
      safeBottom: windowInfo.screenHeight - windowInfo.safeArea.bottom
    };
    
    this.setData({ layoutConfig });

    // 处理启动参数，打开指定详情页
    if (options && options.detail === 'card1') {
      const detailConfig = require('../../config/swiper/card1/detail');
      // 延迟执行确保页面准备就绪
      setTimeout(() => {
        this.showDetail(detailConfig);
      }, 100);
    }

    // 初始化数据
    this.initData();
  },

  // 初始化数据
  initData() {
    this.setData({
      loading: false,
      error: null,
      showDetail: false  // 确保初始状态不显示详情页
    });
  },

  onShow() {
    try {
      // 恢复动画和自动播放
      this.setData({
        'topCards[0].autoplay': true
      });
      // 预加载下一页
      this._preloadNextPage();
    } catch (error) {
      console.error('页面显示错误：', error)
    }
  },

  onHide() {
    // 保存当前状态
    wx.setStorageSync('lastPageState', {
      showDetail: this.data.showDetail,
      currentDetail: this.data.currentDetail,
      topCurrentIndex: this.data.topCurrentIndex
    });
    // 暂停不必要的动画和自动播放
    this.setData({
      'topCards[0].autoplay': false
    });
  },

  onUnload() {
    // 清理资源
    this._cleanupResources();
  },

  onError(error) {
    console.error('页面发生错误：', error)
  },

  onSwiperChange(e) {
    const { current } = e.detail;
    if (this.data.currentIndex !== current) {
      // 获取滑动速度
      const now = Date.now();
      const timeDiff = now - (this._lastSwipeTime || 0);
      this._lastSwipeTime = now;
      
      // 根据滑动速度调整动画
      const isQuickSwipe = timeDiff < 300;
      
      this.setData({ 
        currentIndex: current,
        // 添加快速滑动的类名
        quickSwipe: isQuickSwipe
      }, () => {
        wx.nextTick(() => {
          const targetScrollTop = this.data.scrollPositions[current];
          if (targetScrollTop > 0) {
            this.setScrollTop(targetScrollTop);
          }
        });
      });
    }
  },

  // 顶部轮播变化处理
  onTopSwiperChange(e) {
    try {
      const index = e.detail.current;
      if (index >= 0 && index < this.data.topCards.length) {  // 添加边界检查
        this.setData({
          topCurrentIndex: index
        });
      }
    } catch (error) {
      console.error('顶部轮播切换错误：', error);
    }
  },

  // 可以通过这个方法控制滚动到指定位置
  scrollToItem(index) {
    this.setData({
      scrollIntoView: `item-${index}`
    });
  },

  onMoveChange(e) {
    const { y } = e.detail;
    // 当向上滑动超过一定距离时，增加阻尼效果
    if (y < -150) {
      this.setData({
        friction: 8  // 增加摩擦力
      });
    } else {
      this.setData({
        friction: 2  // 恢复正常摩擦力
      });
    }
  },

  // 在设置内容时进行检查
  setContent(title, content) {
    // 标题限制在10个字符以内
    if (title.length > 10) {
      title = title.substring(0, 10) + '...';
    }
    
    // 每行大约20个字符，3行共60个字符
    if (content.length > 60) {
      content = content.substring(0, 60) + '...';
    }
  },

  // 数据过滤器
  filterContentData(data) {
    if (!data || !data.contents) return data;
    
    const filteredContents = data.contents.map(item => ({
      title: Object.assign({}, item.title, {
        text: this.dataFilter.filterTitle(item.title.text)
      }),
      content: Object.assign({}, item.content, {
        text: this.dataFilter.filterContent(item.content.text)
      }),
      exercises: item.exercises,
      info: item.info
    }));

    return Object.assign({}, data, { contents: filteredContents });
  },

  // 更新内容的方法
  updateContent(newContent) {
    if (!newContent) return;
    
    const filteredContent = this.filterContentData({
      contents: [newContent]
    }).contents[0];
    
    this.setData({
      ['contents[' + this.data.currentIndex + ']']: filteredContent
    });
  },

  // 添加新内容的方法
  addNewContent(content) {
    if (!content) return;
    
    const newContent = {
      title: { text: content.title },
      content: { text: content.description },
      exercises: [],
      info: {
        duration: '30 min',
        calories: '150 kcal'
      }
    };

    const filteredContent = this.filterContentData({
      contents: [newContent]
    }).contents[0];
    
    const contents = this.data.contents.concat([filteredContent]);
    this.setData({ contents });
  },

  // 优化 setData
  _batchUpdate(data, callback) {
    if (this._updateTimer) {
      clearTimeout(this._updateTimer);
    }
    
    this._pendingData = Object.assign({}, this._pendingData, data);
    
    this._updateTimer = setTimeout(() => {
      wx.nextTick(() => {
        if (this._pendingData) {
          this.setData(this._pendingData, () => {
            this._pendingData = null;
            callback && callback();
          });
        }
      });
    }, 50); // 50ms 的防抖时间
  },

  // 添加预加载方法
  _preloadNextPage() {
    const nextIndex = (this.data.currentIndex + 1) % this.data.contents.length;
    const nextContent = this.data.contents[nextIndex];
    
    if (nextContent) {
      // 预加载下一页的图片资源
      if (nextContent.exercises && nextContent.exercises.length) {
        nextContent.exercises.forEach(exercise => {
          if (exercise.imageUrl) {
            wx.getImageInfo({
              src: exercise.imageUrl,
              success: () => console.log('预加载图片成功'),
              fail: err => console.error('预加载图片失败:', err)
            });
          }
        });
      }
    }
  },

  _cleanupResources() {
    // 清理定时器等资源
    if (this._debounceTimer) {
      clearTimeout(this._debounceTimer);
      this._debounceTimer = null;
    }
    if (this._scrollTimer) {
      clearTimeout(this._scrollTimer);
      this._scrollTimer = null;
    }
  },

  // 添加统一的错误处理方法
  _handleError(error, context) {
    console.error(`Error in ${context}:`, error);
    
    // 上报错误
    wx.reportAnalytics('page_error', {
      context,
      message: error.message || String(error),
      stack: error.stack,
      timestamp: Date.now()
    });

    // 显示错误提示
    wx.showToast({
      title: '操作失败，请稍后重试',
      icon: 'none',
      duration: 2000
    });
  },

  // 状态管理方法
  _updatePageState(newState) {
    this._batchUpdate({
      _pageState: Object.assign({}, this.data._pageState, newState)
    });
  },

  _initializeNetworkMonitor() {
    const networkManager = getApp().globalData.networkManager;
    if (networkManager) {
      const status = networkManager.getNetworkStatus();
      if (!status.isConnected) {
        this._updatePageState({
          hasError: true,
          errorMessage: '网络连接已断开'
        });
      }
    }
  },

  _initializeLayout() {
    return new Promise((resolve, reject) => {
      try {
        const app = getApp();
        // 检查 app 和 globalData 是否存在
        if (!app || !app.globalData) {
          throw new Error('App globalData not initialized');
        }

        // 获取系统信息
        const windowInfo = wx.getWindowInfo();
        const deviceInfo = wx.getDeviceInfo();
        const appBaseInfo = wx.getAppBaseInfo();

        // 设置统一的布局配置
        this.setData({
          layoutConfig: {
            navHeight: windowInfo.statusBarHeight + 44,
            statusBarHeight: windowInfo.statusBarHeight,
            contentHeight: 400,
            safeTop: windowInfo.statusBarHeight,
            bottomOffset: 520,  // movable-view 高度
            safeBottom: windowInfo.screenHeight - windowInfo.safeArea.bottom
          }
        }, () => resolve());

      } catch (error) {
        reject(error);
      }
    });
  },

  // 添加页面状态恢复方法
  _restorePageState() {
    try {
      const savedState = wx.getStorageSync('pageState');
      if (savedState) {
        this._batchUpdate({
          currentIndex: savedState.currentIndex,
          topCurrentIndex: savedState.topCurrentIndex
        });
      }
    } catch (error) {
      console.error('恢复页面状态失败:', error);
    }
  },

  // 保存页面状态
  _savePageState() {
    try {
      wx.setStorageSync('pageState', {
        currentIndex: this.data.currentIndex,
        topCurrentIndex: this.data.topCurrentIndex,
        timestamp: Date.now()
      });
    } catch (error) {
      console.error('保存页面状态失败:', error);
    }
  },

  // 添加图片加载优化
  _optimizeImageLoading() {
    // 获取可见区域信息
    wx.createIntersectionObserver().relativeToViewport().observe('.slide-item', (res) => {
      if (res.intersectionRatio > 0) {
        // 元素进入可视区域，加载图片
        const index = res.dataset.index;
        if (index !== undefined) {
          this._loadImage(index);
        }
      }
    });
  },

  _loadImage(index) {
    const exercise = this.data.contents[this.data.currentIndex].exercises[index];
    if (exercise && exercise.imageUrl && !exercise.imageLoaded) {
      wx.getImageInfo({
        src: exercise.imageUrl,
        success: () => {
          this.setData({
            [`contents[${this.data.currentIndex}].exercises[${index}].imageLoaded`]: true
          });
        }
      });
    }
  },

  // 修改 onScrollList 方法
  onScrollList(e) {
    // 使用简单的防抖实现
    if (this._scrollTimer) {
      clearTimeout(this._scrollTimer);
    }
    
    this._scrollTimer = setTimeout(() => {
      const currentIndex = this.data.currentIndex;
      const scrollTop = e.detail.scrollTop;
      
      const positions = [...this.data.scrollPositions];
      positions[currentIndex] = scrollTop;
      
      // 更新状态
      this.setData({
        scrollPositions: positions
      });
      
      // 保存到本地存储
      try {
        wx.setStorageSync(this.data.scrollKey, positions);
      } catch (error) {
        console.error('保存滚动位置失败:', error);
      }
    }, 100);  // 100ms 防抖
  },

  // 优化滚动位置设置
  setScrollTop(scrollTop) {
    if (typeof scrollTop !== 'number' || scrollTop < 0) return;
    
    wx.createSelectorQuery()
      .select('.pure-scroll-list')
      .node()
      .exec((res) => {
        if (res && res[0] && res[0].node) {
          res[0].node.scrollTo({
            top: scrollTop,
            behavior: 'instant'
          });
        }
      });
  },

  // 显示详情
  showDetail(detail) {
    this.setData({
      currentDetail: detail,
      showDetail: true,
      moveY: 0,
      videoLoaded: false,
      autoPlayEnabled: true,
      isPlaying: false,
      isMuted: true  // 确保初始静音
    });

    // 立即创建视频上下文并播放
    setTimeout(() => {
      const videoContext = wx.createVideoContext('myVideo');
      videoContext.play();
    }, 50);  // 给一个很短的延迟确保视频组件已经渲染
  },

  // 关闭详情
  onPopupClose() {
    const videoContext = wx.createVideoContext('myVideo');
    videoContext.stop();
    
    this.setData({
      showDetail: false,
      currentDetail: null,
      videoLoaded: false,
      moveY: 0,
      isPlaying: false,
      autoPlayEnabled: false  // 关闭自动播放
    });
  },

  // 顶部卡片点击处理
  onTopCardTap(e) {
    const index = this.data.topCurrentIndex;
    try {
      const detail = require(`../../config/swiper/card${index + 1}/detail`);
      this.showDetail(detail);
    } catch (error) {
      console.error('加载详情配置失败:', error);
    }
  },

  // 底部列表项点击处理
  onExerciseItemTap(e) {
    const detail = e.currentTarget.dataset.detail;
    
    this.setData({
      currentDetail: {
        title: detail.name,
        sections: [
          {
            type: "text",
            content: detail.name  // 每个列表项显示自己的内容
          }
        ]
      },
      showDetail: true
    });
  },

  // 下拉过程中的处理
  onScrollPulling(e) {
    const { dy } = e.detail;
    if (dy >= 80) {
      this.setData({ isRefreshing: true });
      this.onPopupClose();
      // 重置刷新状态
      setTimeout(() => {
        this.setData({ isRefreshing: false });
      }, 300);
    }
  },

  // 点击滑动提示箭头的处理
  onSwipeGuideClick(e) {
    if (this.data.isAnimating) return; // 防止动画过程中重复点击
    
    const nextIndex = (this.data.currentIndex + 1) % this.data.contents.length;
    
    this.setData({
      isAnimating: true,
      currentIndex: nextIndex
    });

    // 动画结束后重置状态
    setTimeout(() => {
      this.setData({
        isAnimating: false
      });
    }, 300);
  },

  // 视频开始播放时移除封面图
  onVideoPlay(e) {
    // 获取当前视频组件
    const video = e.currentTarget;
    // 移除封面图
    video.poster = "";
  },

  // 触摸开始时记录起始位置
  onPopupTouchStart(e) {
    this.setData({
      startY: e.touches[0].clientY
    });
  },

  // 触摸移动时判断方向和距离
  onPopupTouchMove(e) {
    const moveY = e.touches[0].clientY;
    const distance = moveY - this.data.startY;

    // 只有向下滑动时才响应
    if (distance > 0) {
      this.setData({
        moveY: distance
      });
    }
  },

  // 触摸结束时判断是否关闭弹窗
  onPopupTouchEnd(e) {
    const distance = this.data.moveY;
    
    if (distance > 150) {
      this.onPopupClose();
    } else {
      // 回弹时重置moveY
      this.setData({
        moveY: 0
      });
    }
  },

  // 点击顶部状态栏关闭
  onPopupHeaderTap() {
    this.onPopupClose();
  },

  // 双击快进/快退
  onVideoDoubleClick(e) {
    // 获取当前视频上下文
    const videoContext = wx.createVideoContext('myVideo');
    
    // 获取点击位置
    const { x } = e.detail;
    const { windowWidth } = wx.getSystemInfoSync();
    
    // 根据点击位置判断快进还是快退
    if (x > windowWidth / 2) {
      // 快进15秒
      videoContext.seek(this.data.currentTime + 15);
    } else {
      // 快退15秒
      videoContext.seek(Math.max(0, this.data.currentTime - 15));
    }
  },

  // 更新当前播放时间
  onTimeUpdate(e) {
    this.setData({
      currentTime: e.detail.currentTime
    });
  },

  // 箭头点击关闭处理
  onPullArrowTap() {
    this.onPopupClose();
  },

  // 处理弹窗内容滚动
  onPopupScroll(e) {
    wx.createSelectorQuery()
      .select('.popup-video')
      .boundingClientRect(rect => {
        if (rect) {
          // 扩大检测范围，提前开始播放
          const windowInfo = wx.getWindowInfo();
          if (rect.top <= windowInfo.windowHeight + 500 && rect.bottom >= -500) {
            const videoContext = wx.createVideoContext('myVideo');
            // 只有在允许自动播放且视频已加载时才播放
            if (this.data.autoPlayEnabled && this.data.videoLoaded) {
              videoContext.play();
              this.setData({
                isPlaying: true
              });
            }
          } else {
            const videoContext = wx.createVideoContext('myVideo');
            videoContext.pause();
            this.setData({
              isPlaying: false
            });
          }
        }
      })
      .exec();
  },

  // 修改 onKeyboardEvent 处理函数
  onKeyboardEvent(e) {
    if (this.data.debugMode) {
      switch(e.key) {
        case '1':
          this.showDetail(require('../../config/swiper/card1/detail'));
          break;
        case '2':
          this.showDetail(require('../../config/swiper/card2/detail'));
          break;
        case '3':
          this.showDetail(require('../../config/swiper/card3/detail'));
          break;
        case 'Escape':  // 添加 ESC 键处理
          this.onPopupClose();
          break;
      }
    }
  },

  handleShare() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline'],
      success() {
        console.log('显示分享菜单成功');
      },
      fail(err) {
        console.error('显示分享菜单失败', err);
      }
    });
  },

  // 定义页面的分享行为
  onShareAppMessage(res) {
    if (res.from === 'button') {
      // 来自页面内分享按钮
      return {
        title: '分享标题',
        path: '/pages/index/index',
        imageUrl: '分享图片路径'  // 可选
      }
    }
  },
  
  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '分享标题',
      query: '',
      imageUrl: '分享图片路径'  // 可选
    }
  },

  // 处理视频点击
  onVideoTap() {
    console.log('视频容器被点击');
    const videoContext = wx.createVideoContext('myVideo');
    
    if (!this.data.isFullScreen) {
      // 进入全屏
      this.setData({
        isFullScreen: true,
        isPlaying: true
      }, () => {
        // 先暂停当前播放
        videoContext.pause();
        // 等待一小段时间再请求全屏和播放
        setTimeout(() => {
          videoContext.requestFullScreen({ direction: 0 });
          videoContext.play();
        }, 100);
      });
    } else {
      // 退出全屏
      // 先暂停播放
      videoContext.pause();
      videoContext.exitFullScreen();
    }
  },

  // 监听全屏变化
  onFullScreenChange(e) {
    console.log('全屏状态变化:', e.detail);
    const isEnteringFullScreen = e.detail.fullScreen;
    
    this.setData({
      isFullScreen: isEnteringFullScreen
    }, () => {
      const videoContext = wx.createVideoContext('myVideo');
      
      // 添加延迟确保状态已经切换
      setTimeout(() => {
        if (isEnteringFullScreen) {
          this.setData({ isMuted: false });
          videoContext.play();
        } else {
          this.setData({ isMuted: true });
          videoContext.play();
        }
      }, 100);
    });
  },

  // 监听视频元素进入可视区域
  onVideoIntersection(e) {
    if (e.detail.intersectionRatio > 0) {  // 视频进入可视区域
      this.setData({ videoInView: true });
      const videoContext = wx.createVideoContext('myVideo');
      videoContext.play();
    } else {  // 视频离开可视区域
      this.setData({ videoInView: false });
      const videoContext = wx.createVideoContext('myVideo');
      videoContext.pause();
    }
  },

  // 处理音量按钮点击
  onVolumeTap() {
    const videoContext = wx.createVideoContext('myVideo');
    this.setData({
      isMuted: !this.data.isMuted
    });
  },

  // 在详情页打开时就开始预加载视频
  onPopupShow() {
    if (this.data.currentDetail && this.data.currentDetail.sections) {
      const videoSection = this.data.currentDetail.sections.find(section => section.type === 'video');
      if (videoSection) {
        // 创建视频上下文
        const videoContext = wx.createVideoContext('myVideo');
        // 设置初始状态
        this.setData({
          videoLoaded: false,
          isPlaying: false,
          autoPlayEnabled: true,
          isMuted: true  // 确保初始静音状态
        }, () => {
          // 立即播放视频
          videoContext.play();
        });
      }
    }
  },

  // 监听视频加载完成
  onVideoLoaded(e) {
    console.log('视频加载完成');
    this.setData({
      videoLoaded: true,
      isPlaying: true
    }, () => {
      if (!this.data.isPlaying) {
        const videoContext = wx.createVideoContext('myVideo');
        videoContext.play();
      }
    });
  },

  // 添加视频错误处理
  onVideoError(e) {
    console.error('视频加载失败:', e);
    this.setData({
      videoLoaded: false
    });
    wx.showToast({
      title: '视频加载失败',
      icon: 'none'
    });
  },

  // 添加视频播放状态变化处理
  onVideoStateChange(e) {
    this.setData({
      isPlaying: e.type === 'play'
    });
  },
})

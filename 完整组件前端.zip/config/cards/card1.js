module.exports = {
  backgroundColor: '#27AE60',
  title: 'Weekend Special',
  description: 'Intensive training session',
  info: {
    duration: '45 min',
    calories: '200 kcal'
  }
} 
module.exports = {
  backgroundColor: '#FFB6C1',
  title: 'Morning Workout',
  description: 'Start your day with energy',
  info: {
    duration: '30 min',
    calories: '150 kcal'
  }
} 
module.exports = {
  backgroundColor: '#4A90E2',
  title: '美甲测试',
  description: '专业的美甲喷绘技术需要持续练习',
  info: {
    duration: '20 min',
    calories: '100 kcal'
  }
} 
module.exports = {
  // 第一张轮播图配置
  mode: "image",  // "image" 为纯图片模式, "color" 为底色模式
  mainTitle: "美甲测试",
  subTitle: "副标题1",
  description: "描述文字1",
  // 使用 HTTPS 链接
  imageUrl: "https://ssdue7pv4.hn-bkt.clouddn.com/2.png",
  backgroundColor: "#FFE4E1"  // 当 mode 为 "color" 时使用的背景色
} 
module.exports = {
  // 第三张轮播图配置
  mainTitle: "轮播图3",
  subTitle: "副标题3",
  description: "描述文字3",
  imageUrl: "/images/default3.png"
} 
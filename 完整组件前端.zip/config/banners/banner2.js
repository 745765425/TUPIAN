module.exports = {
  // 第二张轮播图配置
  mainTitle: "轮播图2",
  subTitle: "副标题2",
  description: "描述文字2",
  imageUrl: "/images/default2.png"
} 
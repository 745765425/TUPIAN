// 轮播图基本配置 - 第三张卡片
module.exports = {
    mode: "image",
    backgroundColor: '#FFB6C1',
    imageUrl: "https://cdn.jsdelivr.net/gh/745765425/TUPIAN/%E7%9A%84%E5%8F%91%E7%BA%A2%E5%8C%85%E5%9C%B0%E6%96%B9.avif",
    title: "美甲专业技能",
    description: "成为专业美甲师的必备技能",
    info: {
        duration: "35 min",
        calories: "180 kcal"
    }
} 
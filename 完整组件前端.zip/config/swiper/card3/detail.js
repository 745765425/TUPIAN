// 详情页配置 - 第三张卡片
const card = require('./card');

module.exports = {
  title: "专业美甲师培训",
  sections: [
    {
      type: "image",
      url: "https://cdn.jsdelivr.net/gh/745765425/TUPIAN/1.png",
      description: "美甲作品展示",
      component: "image-viewer"
    },
    {
      type: "text",
      content: "成为专业美甲师需要掌握："
    },
    {
      type: "image",
      url: "https://cdn.jsdelivr.net/gh/745765425/TUPIAN/3.png",
      description: "美甲作品展示",
      component: "image-viewer"
    }
  ]
} 
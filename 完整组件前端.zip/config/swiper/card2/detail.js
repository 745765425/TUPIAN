const card = require('./card');
const videoConfig = require('../../../components/video-player/config');

// 详情页配置 - 第二张卡片
module.exports = {
  title: "专业美甲进阶教程",
  sections: [
    {
      type: "image",
      url: "https://cdn.jsdelivr.net/gh/745765425/TUPIAN/4.png",
      description: "美甲喷枪示例",
      component: "image-viewer"
    },
    {
      type: "video",
      url: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
      title: "美甲进阶技巧",
      config: videoConfig  // 使用通用视频配置
    },
    {
      type: "text",
      content: "掌握进阶美甲技巧，提升专业技能水平。"
    }
  ]
} 
// 轮播图基本配置 - 第二张卡片
module.exports = {
  mode: "image",
  backgroundColor: '#27AE60',
  imageUrl: "https://cdn.jsdelivr.net/gh/745765425/TUPIAN/%E7%9A%84%E5%8F%91%E7%BA%A2%E5%8C%85%E5%9C%B0%E6%96%B9.avif",
  title: "美甲进阶教程",
  description: "掌握更高级的美甲技巧",
  info: {
    duration: "30 min",
    calories: "150 kcal"
  }
} 
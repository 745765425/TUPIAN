// =====================================================
// 美甲轮播图配置文件 - 第一张卡片
// =====================================================

module.exports = {
    mode: "image",           
    backgroundColor: '#27AE60',  
    imageUrl: "https://cdn.jsdelivr.net/gh/745765425/TUPIAN/IMG_3808.png",
    title: "美甲喷绘专业教程",
    description: "专业的美甲喷绘技术需要持续练习",
    info: {
        duration: "45 min",
        calories: "200 kcal"
    },

    // =====================================================
    // 视频播放器开关配置 - 就在这里修改！
    // =====================================================
    video: {
        // ↓↓↓ 在这里设置 true 或 false ↓↓↓
        enable: true,    // true = 显示视频, false = 不显示视频
        // ↑↑↑ 在这里设置 true 或 false ↑↑↑

        // 以下是视频的详细配置
        url: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E6%96%B0%E6%95%99%E7%A8%8B%E8%A7%86%E9%A2%91/-%E5%8D%95%E8%89%B2%E6%B8%90%E5%8F%981.mp4",
        poster: "",  // 如果暂时没有封面图，可以留空
        title: "美甲喷绘教程",
        description: "专业美甲喷绘技巧演示",
        autoplay: false,  // 不自动播放
        loop: true,      // 循环播放
        controls: true   // 显示控制栏
    }
} 
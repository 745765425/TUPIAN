// =====================================================
// 美甲详情页配置文件
// 注意：视频播放器的开关在 card.js 文件中设置
// =====================================================

const card = require('./card');  // 恢复这行代码，它是必需的
const videoConfig = require('../../../components/video-player/config');

module.exports = {
  debugTargetDetail: 'card1',  // 指定要显示的详情页
  autoShowDetail: false,  // 改为 false，不自动显示
  title: "美甲喷绘专业教程",
  sections: [
    // 只保留一个通用的图片配置
    {
      type: "image",
      url: "https://cdn.jsdelivr.net/gh/745765425/TUPIAN/5.png",
      description: "美甲喷绘示例",
      component: "image-viewer"
    },
    // 主标题部分
    {
      type: "text",
      content: "美甲喷绘专业教程",
      style: {
        fontSize: "48rpx",
        fontWeight: "bold",
        textAlign: "center",
        marginBottom: "20rpx",
        color: "#FFFFFF"
      }
    },
    // 副标题部分
    {
      type: "text",
      content: "专业技能培训",
      style: {
        fontSize: "32rpx",
        fontWeight: "normal",
        textAlign: "center",
        marginBottom: "40rpx",
        color: "rgba(255, 255, 255, 0.8)"
      }
    },
    // 主要内容部分
    {
      type: "text",
      content: `美甲喷绘技术要点：\n\n1. 工具准备\n- 专业喷枪设备\n- 颜料与溶剂\n- 防护用品\n\n2. 基础技巧\n- 喷涂角度控制\n- 距离把握\n- 压力调节`,
      style: {
        fontSize: "28rpx",
        lineHeight: "1.8",
        textAlign: "center",
        padding: "0 40rpx",
        color: "rgba(255, 255, 255, 0.9)"
      }
    },
    // 第三部分：工具准备文字
    {
      type: "text",
      content: `
        1. 工具准备
          - 专业喷枪
          - 颜料选择
          - 清洁工具

          4,wklfsdknds

        2. 基础技巧
          - 喷涂角度控制
          - 距离把握
          - 力度调节

        3. 进阶技巧
          - 渐变效果
          - 图案叠加
          - 细节处理

        4. 注意事项
          - 通风要求
          - 安全防护
          - 清洁维护
      `
    },

    // =====================================================
    // 视频播放器配置 - 全屏宽度显示
    // =====================================================
    {
      type: "video",
      url: card.video.url,
      title: card.video.title,
      config: videoConfig  // 使用通用配置
    },

    // 第五部分：基础技巧文字
    {
      type: "text",
      content: `
        2. 基础技巧
        - 喷涂角度控制
        - 距离把握
        - 力度调节
      `
    },
    // 第七部分：进阶技巧文字
    {
      type: "text",
      content: `
        3. 进阶技巧
          - 渐变效果
          - 图案叠加
          - 细节处理

        4. 注意事项
          - 通风要求
          - 安全防护
          - 清洁维护
      `
    },
    // 文本内容
    {
      type: "text",
      content: "专业美甲喷绘系统 - 详情介绍..."
    },
    {
      type: "image",
      url: "https://cdn.jsdelivr.net/gh/745765425/TUPIAN/IMG_9340.jpg",
      description: "专业美甲喷绘示例",
      component: "image-viewer"  // 使用新组件
    }
  ]
} 
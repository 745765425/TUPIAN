// app.js
// var unusedVar = 123;   // 使用 var 而不是 let/const
// function emptyFunc() { }  // 空函数
// function duplicateFunc() { }
// function duplicateFunc() { }  // 重复的函数声明

App({
  globalData: {
    // 数据存储
    gallery: {
      data: null,
      isComplete: false,
      hasMore: false    // 替代 hasMoreGalleryImages
    },
    
    // 用户信息
    userInfo: null,
    isAdmin: false,
    isPreloading: false  // 移到顶层
  },

  async onLaunch() {
    // 初始化云开发
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: 'nail-spray-cloud-1f7k6g24bb56801',
        traceUser: true,
      })
      console.log('云开发初始化完成，环境ID:', 'nail-spray-cloud-1f7k6g24bb56801')
    }

    // 启动时就预加载图片
    try {
      const res = await wx.cloud.callFunction({
        name: 'getGalleryFiles'
      });
      
      if (res.result?.success && res.result?.fileList?.length > 0) {
        const imageUrls = res.result.fileList.map(file => file.tempFileURL);
        
        // 预加载前6张图片
        wx.preloadAssets({
          images: imageUrls.slice(0, 6)
        });
      }
    } catch (err) {
      console.error('预加载图片失败:', err);
    }

    // 确保启动时清除所有旧数据
    this.clearAllData();

    // 确保TabBar始终隐藏
    this.ensureTabBarHidden();
  },
  
  // 添加页面显示时的处理
  onShow: function() {
    // 确保每次页面显示时都隐藏原生TabBar
    this.ensureTabBarHidden();
  },
  
  // 检查用户是否为管理员
  checkAdmin: function(callback) {
    wx.cloud.callFunction({
      name: 'checkAdmin',
      success: res => {
        console.log('检查管理员结果:', res.result)
        const isAdmin = res.result && res.result.isAdmin === true ? true : false
        this.globalData.isAdmin = isAdmin
        if (callback) callback(isAdmin)
      },
      fail: err => {
        console.error('检查管理员权限失败', err)
        this.globalData.isAdmin = false
        if (callback) callback(false)
      }
    })
  },

  // 添加全局图片工具
  imageUtil: {
    // 分析图片尺寸并返回布局信息
    analyzeImageSize(url) {
      return new Promise((resolve) => {
        wx.getImageInfo({
          src: url,
          success: (res) => {
            const { width, height } = res;
            const ratio = height / width;
            
            // 根据图片比例决定布局方式
            const layoutInfo = {
              isVertical: ratio > 1.2,  // 高宽比大于1.2认为是竖图
              isHorizontal: ratio < 0.8,  // 高宽比小于0.8认为是横图
              isSquare: ratio >= 0.8 && ratio <= 1.2,  // 接近正方形
              ratio: ratio,
              originalWidth: width,
              originalHeight: height
            };
            
            resolve(layoutInfo);
          },
          fail: (err) => this.handleError(err, 'analyzeImageSize')
        });
      });
    }
  },

  // 预加载方法
  async startPreload() {
    if (this.globalData.isPreloading) return;
    this.globalData.isPreloading = true;

    try {
      await this.preloadGallery();  // 只预加载图片
    } catch (err) {
      console.error('预加载失败:', err);
    } finally {
      this.globalData.isPreloading = false;
    }
  },

  // 添加完整的数据清理方法
  clearAllData() {
    // 清除本地存储
    try {
      wx.clearStorageSync();
    } catch(e) {
      console.error('清除存储失败:', e);
    }
  },

  // 在 app.js 中添加工具方法
  getSystemInfo() {
    return {
      windowInfo: wx.getWindowInfo(),
      deviceInfo: wx.getDeviceInfo(),
      appBaseInfo: wx.getAppBaseInfo()
    };
  },

  // 修改建议：创建一个统一的方法
  ensureTabBarHidden: function() {
    wx.hideTabBar();
  },

  // 添加统一的错误处理方法
  handleError: function(error, context) {
    console.error(`[${context}]错误:`, error);
    return null;
  },
})

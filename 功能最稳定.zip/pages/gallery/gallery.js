// pages/gallery/gallery.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    galleryItems: [],
    isLoading: false,
    showPreview: false,
    previewImage: null,
    headerState: {
      opacity: 1
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.loadGalleryImagesFromStorage();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    wx.hideTabBar();
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 1
      });
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.refreshGallery();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    if (!this.data.isLoading) {
      this.loadGalleryImagesFromStorage(true);
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
  },

  // 优化的滚动事件处理
  onScrollEvent(e) {
    wx.nextTick(() => {
      const scrollTop = e.detail.scrollTop;
      const opacity = Math.max(0, 1 - (scrollTop / 150));
      this.setData({ 
        'headerState.opacity': opacity
      });
    });
  },

  // 优化的图片加载方法
  async loadGalleryImagesFromStorage() {
    if (this.data.isLoading) return;
    
    this.setData({ isLoading: true });
    
    try {
      const res = await wx.cloud.callFunction({
        name: 'getGalleryFiles'
      });

      if (res.result?.success && res.result?.fileList?.length > 0) {
        const imagePromises = res.result.fileList.map((file, index) => {
          return new Promise((resolve) => {
            wx.getImageInfo({
              src: file.tempFileURL,
              success: (imgInfo) => {
                resolve({
                  _id: index.toString(),
                  title: file.key,
                  imageUrl: file.tempFileURL,
                  isVertical: imgInfo.height > imgInfo.width
                });
              },
              fail: () => resolve(null)
            });
          });
        });

        const newItems = await Promise.all(imagePromises);
        const validItems = newItems.filter(item => item !== null);
        
        this.setData({
          galleryItems: validItems,
          isLoading: false
        });
      } else {
        this.setData({ isLoading: false });
        wx.showToast({
          title: '暂无图片',
          icon: 'none'
        });
      }
    } catch (err) {
      console.error('获取云存储文件失败:', err);
      this.setData({ isLoading: false });
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
    }
  },

  // 图片预览相关
  handleImageTap(e) {
    const item = e.currentTarget.dataset.item;
    this.setData({
      showPreview: true,
      previewImage: item
    });
  },

  closePreview() {
    this.setData({
      showPreview: false
    });
  },

  // 新的刷新方法
  async refreshGallery() {
    try {
      await this.loadGalleryImagesFromStorage();
      wx.stopPullDownRefresh();
    } catch (err) {
      console.error('刷新失败:', err);
      wx.stopPullDownRefresh();
    }
  }
})
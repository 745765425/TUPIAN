Component({
  data: {
    selected: 0,
    color: "#666666",
    selectedColor: "#ffffff",
    backgroundColor: "#000000",
    isDetailOpen: false,
    show: true,
    useTransition: true,
    list: [{
      pagePath: "/pages/index/index",
      text: "视频",
      iconPath: "/images/video-icon.png",
      selectedIconPath: "/images/video-icon-active.png",
      icon: "video-icon"
    }, {
      pagePath: "/pages/gallery/gallery",
      text: "图库",
      iconPath: "/images/gallery-icon.png",
      selectedIconPath: "/images/gallery-icon-active.png",
      icon: "document-icon"
    }]
  },
  methods: {
    switchTab(e) {
      const data = e.currentTarget.dataset;
      const url = data.path;
      wx.switchTab({
        url
      });
      this.setData({
        selected: data.index
      });
    }
  }
}); 
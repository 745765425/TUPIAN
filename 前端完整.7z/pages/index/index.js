// index.js
Page({
  data: {
    statusBarHeight: 0, // 状态栏高度
    titleBarHeight: 80, // 标题栏高度（rpx单位）
    videoItem: {
      title: "Devolver Digital: The Return of Volvy",
      authorName: "Blink",
      authorAvatar: "https://placekitten.com/100/100",
      publishTime: "1 year ago",
      coverUrl: "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1000",
      videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
      duration: "17:34",
      specialMark: "SP"
    },
    showNavHeader: true,
    lastScrollTop: 0,
    activeTab: 'video',
    screenHeight: 0, // 屏幕高度
    videoItems: [],
    isScrolling: false,
    scrollTimer: null,
    currentPlayingVideoId: null, // 当前正在播放的视频ID
    showVideoDetail: false,
    selectedVideo: null,
    playerHeight: 300,
    videoError: false,
    safeAreaTop: 0,
    touchStartY: 0, // 触摸开始位置
    isPanelExpanded: true, // 默认为展开状态
    initialPlayerHeight: '45vh', // 初始视频高度
    expandedPlayerHeight: '35vh', // 从30vh增加到35vh，使视频位置更低
    initialTopSpace: 'calc(15vh - 40px)', // 初始顶部空间
    expandedTopSpace: '50px', // 从30px增加到50px，保留更多顶部空间
    videoTransform: 'translateY(0)',
    isSliding: false,
    touchMoveThreshold: 100,  // 下拉阈值
    touchStartX: 0,
    isDragging: false,
    dragThreshold: 50,  // 下拉阈值
    currentVideo: null,
    isDetailShow: false,
    videoList: [
      {
        id: 1,
        title: "视频标题1",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4", // 使用新链接
        coverUrl: "https://placekitten.com/300/200",
        authorName: "作者1",
        publishTime: "2小时前",
        specialMark: "SP"
      },
      {
        id: 2,
        title: "视频标题2",
        videoUrl: "原有视频链接2", // 保持原有链接
        coverUrl: "https://placekitten.com/300/201",
        authorName: "作者2",
        publishTime: "3小时前"
      },
      {
        id: 3,
        title: "视频标题3",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4", // 使用新链接
        coverUrl: "https://placekitten.com/300/202",
        authorName: "作者3",
        publishTime: "4小时前",
        specialMark: "SP"
      },
      // ... 可以继续添加更多视频，按照1、3、5、7、9的规律使用新链接
    ],
    batchSize: 20,     // 每批次加载20个视频
    startIndex: 0,     // 当前加载的起始索引
    maxKeepVideos: 60, // 最多保留60个视频在内存中
    isLoading: false,  // 添加加载状态标记
  },
  
  // 添加获取视频数据的方法
  fetchVideoItems(startIndex, batchSize) {
    return new Promise((resolve) => {
      // 模拟视频数据
      const newVideos = Array(batchSize).fill(0).map((_, index) => ({
        id: 'video-' + (startIndex + index),
        title: (startIndex + index) % 2 === 0 ? "喷枪宣传视频" : "单色渐变教程",
        authorName: "喷枪教程",
        authorAvatar: "/images/default-avatar.png",
        publishTime: "1 year ago",
        coverUrl: "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1000",
        videoUrl: (startIndex + index) % 2 === 0 
          ? "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4"
          : "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E6%96%B0%E6%95%99%E7%A8%8B%E8%A7%86%E9%A2%91/-%E5%8D%95%E8%89%B2%E6%B8%90%E5%8F%981.mp4",
        duration: "17:34",
        specialMark: "SP",
        isInViewCenter: false
      }));
      resolve(newVideos);
    });
  },
  
  onLoad() {
    // 获取系统信息，包括状态栏高度
    const systemInfo = wx.getSystemInfoSync();
    const statusBarHeight = systemInfo.statusBarHeight;
    
    // 获取胶囊按钮位置信息
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
    const menuButtonHeight = menuButtonInfo.height;
    const menuButtonTop = menuButtonInfo.top;
    
    // 计算安全区域高度（状态栏 + 胶囊按钮 + 一些额外空间）
    const safeAreaTop = menuButtonTop + menuButtonHeight + 10;
    
    this.setData({
      statusBarHeight: statusBarHeight,
      screenHeight: systemInfo.windowHeight,
      safeAreaTop: safeAreaTop,
      isDetailShow: false  // 再次确保为 false
    });
    
    // 设置导航栏为透明
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: 'transparent',
      animation: {
        duration: 0,
        timingFunc: 'easeIn'
      }
    });
    
    // 首次加载20个视频
    this.loadNextBatch();
  },
  
  onReady() {
    // 使用IntersectionObserver监测视频容器
    this.videoObserver = wx.createIntersectionObserver(this);
    this.videoObserver
      .relativeToViewport()
      .observe('.video-card-item', (res) => {
        // 当视频容器进入/离开可视区域时触发
        if (res.intersectionRatio > 0) {
          // 视频在可视区域内，可以播放
          if (this.data.selectedVideo && !this.data.videoError) {
            const videoContext = wx.createVideoContext('detail-video');
            videoContext.play();
          }
        } else {
          // 视频不在可视区域内，应该暂停
          if (this.data.selectedVideo) {
            const videoContext = wx.createVideoContext('detail-video');
            videoContext.pause();
          }
        }
      });
  },
  
  // 修改滚动处理函数
  onScroll(e) {
    const scrollTop = e.detail.scrollTop;
    const lastScrollTop = this.data.lastScrollTop || 0;
    const scrollDistance = Math.abs(scrollTop - lastScrollTop);
    
    // 更新最后滚动位置
    this.setData({
      lastScrollTop: scrollTop,
      isScrolling: true
    });
    
    // 处理导航栏的显示/隐藏
    if (scrollTop > 10 && lastScrollTop < scrollTop) {
      this.setData({
        showNavHeader: false
      });
    } else if (lastScrollTop > scrollTop) {
      this.setData({
        showNavHeader: true
      });
    }
    
    // 清除之前的计时器
    if (this.data.scrollTimer) {
      clearTimeout(this.data.scrollTimer);
    }
    
    // 在滚动过程中立即检测视频位置
    this.checkVideoInView();
    
    // 如果滚动距离很大，则完全停止所有视频
    if (scrollDistance > this.data.screenHeight / 2) {
      this.stopAllVideos();
    }
    
    // 设置新的计时器，检测滚动停止
    const timer = setTimeout(() => {
      this.setData({
        isScrolling: false
      });
      // 滚动停止后再次检测视频位置
      this.checkVideoInView();
    }, 200); // 200ms无滚动视为停止
    
    this.setData({
      scrollTimer: timer
    });
  },
  
  // 视频位置检测函数
  checkVideoInView() {
    const query = wx.createSelectorQuery();
    const screenHeight = this.data.screenHeight;
    const centerY = screenHeight / 2;
    
    // 缩小中心区域范围，使其更精确
    const threshold = screenHeight / 5;
    
    query.selectAll('.video-card-item').boundingClientRect(rects => {
      if (!rects || !rects.length) return;
      
      // 找出最接近中心的视频
      let closestVideoIndex = -1;
      let minDistance = Infinity;
      
      rects.forEach((rect, index) => {
        if (!rect) return;
        
        const cardCenterY = rect.top + rect.height / 2;
        const distanceToCenter = Math.abs(cardCenterY - centerY);
        
        if (distanceToCenter < minDistance) {
          minDistance = distanceToCenter;
          closestVideoIndex = index;
        }
      });
      
      // 只有最接近中心且在阈值范围内的视频才设置为中心视频
      const videoItems = this.data.videoItems.map((item, index) => {
        // 判断是否是最接近中心且在阈值范围内的视频
        const isInViewCenter = (index === closestVideoIndex) && (minDistance < threshold);
        
        // 如果视频状态发生变化（从中心区域移出），立即更新
        if (item.isInViewCenter && !isInViewCenter) {
          // 立即暂停该视频
          this.pauseVideoById(item.id);
        }
        
        return {
          ...item,
          isInViewCenter
        };
      });
      
      this.setData({ videoItems });
    }).exec();
  },
  
  // 暂停指定ID的视频
  pauseVideoById(videoId) {
    const videoComponentId = `video-component-${videoId}`;
    const videoComponent = this.selectComponent(`#${videoComponentId}`);
    
    if (videoComponent) {
      videoComponent.pauseVideo();
    }
  },
  
  onVideoPlay(e) {
    const videoId = e.detail.videoId;
    console.log('视频开始播放:', videoId);
    
    // 更新当前播放视频ID
    this.setData({
      currentPlayingVideoId: videoId
    });
  },
  
  onVideoPause(e) {
    const videoId = e.detail.videoId;
    console.log('视频暂停:', videoId);
    
    // 如果暂停的是当前播放的视频，清除当前播放视频ID
    if (videoId === this.data.currentPlayingVideoId) {
      this.setData({
        currentPlayingVideoId: null
      });
    }
  },
  
  onVideoEnd() {
    console.log('视频播放结束');
  },
  
  // 停止所有视频
  stopAllVideos() {
    this.data.videoItems.forEach(item => {
      const videoComponentId = `video-component-${item.id}`;
      const videoComponent = this.selectComponent(`#${videoComponentId}`);
      
      if (videoComponent) {
        videoComponent.stopVideo();
      }
    });
  },
  
  // 切换标签页
  switchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    
    // 如果切换到不同的标签，停止所有视频
    if (tab !== this.data.activeTab) {
      this.stopAllVideos();
    }
    
    // 更新激活的标签
    this.setData({
      activeTab: tab
    });
  },
  
  // 处理分享事件
  onVideoShare(e) {
    const shareInfo = e.detail;
    console.log('准备分享视频:', shareInfo);
    
    // 调用微信分享API
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },
  
  // 用户点击右上角分享或使用分享按钮时触发
  onShareAppMessage(res) {
    console.log('分享事件触发', res);
    
    // 来自页面内分享按钮
    if (res.from === 'button' && res.target && res.target.dataset.videoInfo) {
      const videoInfo = res.target.dataset.videoInfo;
      console.log('分享视频信息:', videoInfo);
      
      return {
        title: videoInfo.title || '精彩视频分享',
        imageUrl: videoInfo.coverUrl,
        path: `/pages/index/index?video_id=${videoInfo.id}`
      };
    }
    
    // 默认分享内容
    return {
      title: '精彩视频集锦',
      path: '/pages/index/index'
    };
  },
  
  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '精彩视频集锦',
      query: '',
      imageUrl: ''
    };
  },
  
  // 处理视频卡片点击
  onVideoCardTap(e) {
    const videoId = e.detail.videoId;
    const video = this.data.videoItems.find(item => item.id === videoId);
    
    // 停止所有正在播放的视频
    this.stopAllVideos();
    
    // 设置视频信息和更新状态
    this.setData({
      currentVideo: video,
      isDetailShow: true,
      // 确保所有视频的播放状态被重置
      videoItems: this.data.videoItems.map(item => ({
        ...item,
        isInViewCenter: false  // 重置所有视频的中心状态
      }))
    });
  },
  
  // 处理视频详情关闭
  onDetailClose() {
    this.setData({
      isDetailShow: false,
      currentVideo: null,  // 清空当前视频信息
      // 重新检测视频位置，确保正确的视频可以播放
      isScrolling: false
    }, () => {
      // 在状态更新后重新检测视频位置
      this.checkVideoInView();
    });
  },
  
  // 防止冒泡
  preventBubble() {
    return false;
  },
  
  // 视频错误处理
  onDetailVideoError(e) {
    console.error('视频加载错误:', e);
    this.setData({
      videoError: true
    });
  },
  
  // 重新加载视频 - 优化版本
  reloadVideo() {
    this.setData({
      videoError: false
    });
    
    // 使用nextTick确保DOM更新后再操作视频
    wx.nextTick(() => {
      const videoContext = wx.createVideoContext('detail-video');
      videoContext.play();
    });
  },
  
  // 开始滑动时
  panelTouchStart(e) {
    if (e.touches.length !== 1) return; // 只处理单指触摸
    
    this.setData({
      touchStartY: e.touches[0].clientY,
      isSliding: true
    });
    
    // 暂时暂停视频
    const videoContext = wx.createVideoContext('detail-video');
    videoContext.pause();
  },
  
  // 滑动结束时
  panelTouchEnd() {
    if (this.touchMoveTimer) {
      clearTimeout(this.touchMoveTimer);
      this.touchMoveTimer = null;
    }
    
    this.setData({
      isSliding: false
    });
    
    // 恢复视频播放
    if (this.data.selectedVideo && !this.data.videoError) {
      const videoContext = wx.createVideoContext('detail-video');
      videoContext.play();
    }
  },
  
  // 简化触摸处理
  panelTouchMove(e) {
    if (!this.data.isSliding || e.touches.length !== 1) return;
    
    // 使用节流函数，减少事件处理频率
    if (this.touchMoveTimer) return;
    
    this.touchMoveTimer = setTimeout(() => {
      const touchMoveY = e.touches[0].clientY;
      const moveDistance = this.data.touchStartY - touchMoveY;
      
      // 只处理向下滑动关闭，并添加阈值判断
      if (moveDistance < -50 && Math.abs(moveDistance) > 30) {
        // 先暂停视频，减轻关闭过程中的性能压力
        const videoContext = wx.createVideoContext('detail-video');
        videoContext.pause();
        
        // 关闭弹窗
        this.onDetailClose();
      }
      
      this.touchMoveTimer = null;
    }, 16);
  },
  
  // 视频详情页面显示时
  onDetailVideoPlay() {
    console.log('详情视频开始播放');
    // 可以在这里做一些优化，比如降低其他元素的动画频率
  },
  
  // 优化页面生命周期
  onShow() {
    // 页面显示时，预加载资源
    if (this.data.videoItems && this.data.videoItems.length > 0) {
      // 预加载前几个视频的封面
      this.preloadVideoCovers();
    }
  },
  
  onHide() {
    // 页面隐藏时，暂停所有视频播放
    this.stopAllVideos();
    
    // 如果详情页面打开，也暂停详情视频
    if (this.data.showVideoDetail) {
      const videoContext = wx.createVideoContext('detail-video');
      videoContext.pause();
    }
  },
  
  // 预加载视频封面
  preloadVideoCovers() {
    const preloadCount = Math.min(5, this.data.videoItems.length);
    for (let i = 0; i < preloadCount; i++) {
      const item = this.data.videoItems[i];
      wx.getImageInfo({
        src: item.coverUrl,
        success: () => console.log('预加载封面成功:', item.id),
        fail: () => console.log('预加载封面失败:', item.id)
      });
    }
  },
  
  // 在页面卸载时清理资源
  onUnload() {
    // 清理定时器
    if (this.data.scrollTimer) {
      clearTimeout(this.data.scrollTimer);
    }
    
    if (this.touchMoveTimer) {
      clearTimeout(this.touchMoveTimer);
    }
    
    // 清理观察者
    if (this.videoObserver) {
      this.videoObserver.disconnect();
    }
  },
  
  // 触摸开始
  handlePopupTouch(e) {
    // 记录起始触摸点
    this.setData({
      touchStartY: e.touches[0].clientY,
      touchStartX: e.touches[0].pageX,
      isDragging: false
    });
  },
  
  // 触摸移动
  handlePopupMove(e) {
    const deltaY = e.touches[0].clientY - this.data.touchStartY;
    const deltaX = e.touches[0].pageX - this.data.touchStartX;
    
    // 只有当垂直移动距离大于水平移动距离，且是向下滑动时才处理
    if (Math.abs(deltaY) > Math.abs(deltaX) && deltaY > 0) {
      this.setData({
        isDragging: true
      });
    }
  },
  
  // 触摸结束
  handlePopupEnd(e) {
    if (this.data.isDragging) {
      const deltaY = e.changedTouches[0].clientY - this.data.touchStartY;
      if (deltaY > this.data.dragThreshold) {
        this.onDetailClose();
      }
    }
    this.setData({
      isDragging: false
    });
  },
  
  // 添加滚动事件处理
  onPageScroll(e) {
    // 如果还没有设置isScrolling为true，说明刚开始滚动
    if (!this.data.isScrolling) {
      this.setData({
        isScrolling: true
      });
    }
    
    // 清除之前的定时器
    if (this.data.scrollTimer) {
      clearTimeout(this.data.scrollTimer);
    }
    
    // 设置新的定时器，滚动停止200ms后将isScrolling设为false
    this.data.scrollTimer = setTimeout(() => {
      this.setData({
        isScrolling: false
      });
    }, 200);
  },
  
  // 加载下一批视频
  async loadNextBatch() {
    if (this.data.isLoading) return;
    this.setData({ isLoading: true });

    try {
      const newVideos = await this.fetchVideoItems(this.data.startIndex, this.data.batchSize);
      
      // 将新视频添加到列表
      const updatedVideos = [...this.data.videoItems, ...newVideos];
      
      // 如果视频总数超过最大保留数量，移除最早的视频
      if (updatedVideos.length > this.data.maxKeepVideos) {
        // 在移除旧视频前，确保释放其资源
        const removeCount = updatedVideos.length - this.data.maxKeepVideos;
        updatedVideos.slice(0, removeCount).forEach(item => {
          const component = this.selectComponent(`#video-component-${item.id}`);
          if (component) {
            component.stopVideo();
          }
        });
        
        const keepStartIndex = updatedVideos.length - this.data.maxKeepVideos;
        updatedVideos.splice(0, keepStartIndex);
      }

      this.setData({
        videoItems: updatedVideos,
        startIndex: this.data.startIndex + this.data.batchSize,
        isLoading: false
      });
    } catch (error) {
      console.error('加载视频失败:', error);
      this.setData({ isLoading: false });
    }
  },
  
  // 监听滚动到底部
  onReachBottom() {
    this.loadNextBatch();
  },
  
  // 处理视频资源释放
  handleVideoResource(currentIndex) {
    const videos = this.data.videoItems;
    
    videos.forEach((item, index) => {
      const distance = Math.abs(index - currentIndex);
      const componentId = `video-component-${item.id}`;
      const component = this.selectComponent(`#${componentId}`);
      
      if (component) {
        if (distance > 10) {  // 距离当前播放视频超过10个位置的视频
          // 完全释放资源
          component.stopVideo();
        } else if (distance > 5) {  // 距离5-10个位置的视频
          // 保持暂停状态但不释放资源
          component.pauseVideo();
        }
      }
    });
  },
  
  // 添加资源优化方法
  optimizeVideoResources() {
    // 获取当前在视图中心的视频索引
    const centerIndex = this.data.videoItems.findIndex(item => item.isInViewCenter);
    if (centerIndex === -1) return;
    
    this.data.videoItems.forEach((item, index) => {
      const distance = Math.abs(index - centerIndex);
      const component = this.selectComponent(`#video-component-${item.id}`);
      
      if (component) {
        // 距离中心视频较远的视频完全释放资源
        if (distance > 10) {
          component.stopVideo();
        }
        // 距离中心视频较近但不在播放范围的视频暂停但保持资源
        else if (distance > 5) {
          component.pauseVideo();
        }
      }
    });
  }
})

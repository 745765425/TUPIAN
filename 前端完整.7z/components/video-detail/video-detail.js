Component({
  options: {
    styleIsolation: 'isolated'
  },

  properties: {
    videoInfo: {
      type: Object,
      value: {}
    },
    isPopupShow: {
      type: Boolean,
      value: false,
      observer(newVal) {
        console.log('弹窗显示状态变更:', newVal);
        if (newVal) {
          this.initPopup();
        } else {
          this.resetPopup();
        }
      }
    }
  },
  
  data: {
    playerHeight: 200, // 默认播放器高度
    minPlayerHeight: 200, // 最小播放器高度
    maxPlayerHeight: 400, // 最大播放器高度
    
    panelTranslateY: 0, // 面板位移
    minPanelHeight: 300, // 面板最小高度
    maxPanelHeight: 600, // 面板最大高度
    
    touchStartY: 0,
    touchMoveY: 0,
    isDragging: false,
    
    videoError: false, // 视频错误状态
    
    isLiked: false, // 是否已点赞
    likeCount: 0, // 点赞数
    commentCount: 0, // 评论数
    comments: [], // 评论数据
    
    commentText: '', // 评论文本
    commentInputFocus: false, // 评论输入框焦点
    
    userInfo: null, // 用户信息
    animationData: {}, // 动画数据
    
    menuButtonTop: 0,  // 胶囊按钮的top值
    statusBarHeight: 0,  // 状态栏高度（近似值）
    isPlaying: false,
    progress: 0,
    currentTime: '00:00',
    totalTime: '00:00',
    controlsVisible: true,  // 控制栏显示状态
    controlsTimer: null,    // 控制栏隐藏定时器
    isFullscreen: false,  // 添加全屏状态标记
    showFullscreenControls: false,  // 全屏控制栏显示状态
    touchStartX: 0,
    touchStartTime: 0,
    videoDuration: 0,
    hintTime: '00:00',
    hintLeft: 0,
    isSwiping: false,  // 添加滑动状态标记
    videoOrientation: 'horizontal', // 'horizontal' 或 'vertical'
  },
  
  lifetimes: {
    // 组件创建时
    created() {
      // 初始化基础配置
      this.initConfig();
      // 创建动画实例
      this.animation = wx.createAnimation({
        duration: 300,
        timingFunction: 'ease',
      });
    },
    
    // 组件挂载时
    attached() {
      console.log('视频详情组件已挂载');
      // 获取系统信息
      const systemInfo = wx.getWindowInfo();
      const screenHeight = systemInfo.windowHeight;
      
      console.log('屏幕高度:', screenHeight);
      
      // 获取胶囊按钮位置信息
      const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
      
      this.setData({
        minPlayerHeight: screenHeight * 0.25,
        maxPlayerHeight: screenHeight * 0.5,
        playerHeight: screenHeight * 0.25,
        
        minPanelHeight: screenHeight * 0.48,  // 从0.5减少到0.48，大约减少20rpx
        maxPanelHeight: screenHeight * 0.68,  // 从0.7减少到0.68，保持比例关系
        
        menuButtonTop: menuButtonInfo.top,
        statusBarHeight: menuButtonInfo.top - 4
      });
      
      // 加载评论和点赞数据
      this.loadComments();
      this.loadLikeStatus();
      
      // 设置基础事件隔离
      this.setupEventIsolation();
    },

    // 组件准备就绪时
    ready() {
      // 确保视频区域完全独立
      this.ensureVideoIndependence();
    }
  },
  
  methods: {
    // 初始化基础配置
    initConfig() {
      // 设置基础事件处理
      this._videoTouchHandler = this.preventBubble.bind(this);
    },

    // 设置事件隔离
    setupEventIsolation() {
      // 确保视频容器的事件隔离
      this.setData({
        videoContainerProps: {
          catchTap: 'preventBubble',
          catchTouchStart: 'preventBubble',
          catchTouchMove: 'preventBubble',
          catchTouchEnd: 'preventBubble'
        }
      });
    },

    // 确保视频独立性
    ensureVideoIndependence() {
      // 获取视频容器
      const query = this.createSelectorQuery();
      query.select('.video-player-container').node(res => {
        if (res && res.node) {
          // 为视频容器添加事件隔离
          res.node.addEventListener('touchstart', this._videoTouchHandler);
          res.node.addEventListener('touchmove', this._videoTouchHandler);
          res.node.addEventListener('touchend', this._videoTouchHandler);
        }
      }).exec();
    },

    // 初始化弹窗
    initPopup() {
      if (!this.animation) {
        // 如果动画实例不存在，重新创建
        this.animation = wx.createAnimation({
          duration: 300,
          timingFunction: 'ease',
        });
      }

      // 设置初始位置
      this.animation.translateY('100%').step({duration: 0});
      this.setData({
        animationData: this.animation.export()
      });

      // 延迟一帧后执行显示动画
      setTimeout(() => {
        this.animation.translateY(0).step();
        this.setData({
          animationData: this.animation.export(),
          panelTranslateY: 0,
          playerHeight: this.data.minPlayerHeight,
          videoError: false
        });
      }, 50);
    },
    
    // 重置弹窗状态
    resetPopup() {
      this.setData({
        panelTranslateY: 0,
        playerHeight: this.data.minPlayerHeight,
        commentInputFocus: false
      });
      
      // 暂停视频
      const videoContext = wx.createVideoContext('detail-video', this);
      videoContext.pause();
    },
    
    // 关闭弹窗
    closePopup() {
      if (!this.animation) {
        this.animation = wx.createAnimation({
          duration: 300,
          timingFunction: 'ease',
        });
      }

      this.animation.translateY('100%').step();
      this.setData({
        animationData: this.animation.export()
      });

      setTimeout(() => {
        this.triggerEvent('close');
      }, 300);
    },
    
    // 面板触摸开始
    panelTouchStart(e) {
      if (e.target.dataset.preventTouch) {
        return;
      }
      this.setData({
        touchStartY: e.touches[0].clientY,
        lastPanelY: this.data.panelTranslateY
      });
    },
    
    // 面板触摸移动
    panelTouchMove(e) {
      if (e.target.dataset.preventTouch) {
        return;
      }
      const touchY = e.touches[0].clientY;
      const moveY = touchY - this.data.touchStartY;
      let newPanelY = this.data.lastPanelY + moveY;
      
      // 限制面板移动范围
      if (newPanelY < -this.data.maxPanelHeight + this.data.minPanelHeight) {
        newPanelY = -this.data.maxPanelHeight + this.data.minPanelHeight;
      } else if (newPanelY > 0) {
        newPanelY = 0;
      }
      
      // 根据面板位置动态调整播放器高度
      let playerHeight = this.data.minPlayerHeight;
      if (newPanelY > -100) {
        // 当面板向下拉时，增加播放器高度
        const ratio = Math.min(1, newPanelY / 100 + 1);
        playerHeight = this.data.minPlayerHeight + 
                      (this.data.maxPlayerHeight - this.data.minPlayerHeight) * ratio;
      }
      
      this.setData({
        panelTranslateY: newPanelY,
        playerHeight: playerHeight
      });
    },
    
    // 面板触摸结束
    panelTouchEnd(e) {
      if (e.target.dataset.preventTouch) {
        return;
      }
      // 根据当前位置决定是否进入伪全屏状态
      if (this.data.panelTranslateY > -50) {
        // 向下拉超过阈值，进入伪全屏
        this.setData({
          panelTranslateY: 0,
          playerHeight: this.data.maxPlayerHeight
        });
      } else if (this.data.panelTranslateY < -this.data.maxPanelHeight + this.data.minPanelHeight + 50) {
        // 向上拉超过阈值，展示最大面板
        this.setData({
          panelTranslateY: -this.data.maxPanelHeight + this.data.minPanelHeight,
          playerHeight: this.data.minPlayerHeight
        });
      }
    },
    
    // 显示控制栏
    showControls() {
      // 清除之前的定时器
      if (this.data.controlsTimer) {
        clearTimeout(this.data.controlsTimer);
      }
      
      this.setData({ controlsVisible: true });
      
      // 设置新的定时器，3秒后隐藏
      this.data.controlsTimer = setTimeout(() => {
        this.setData({ controlsVisible: false });
      }, 3000);
    },

    // 视频区域触摸事件
    onVideoTouch() {
      this.showControls();
    },

    // 视频播放开始时
    onVideoPlay() {
      console.log('视频开始播放');
      this.setData({ isPlaying: true });
      this.showControls();  // 显示控制栏
    },
    
    onVideoPause() {
      console.log('视频暂停');
    },
    
    onVideoEnd() {
      console.log('视频播放结束');
    },
    
    onVideoError(e) {
      console.error('视频播放错误', e.detail);
      this.setData({ videoError: true });
    },
    
    // 重新加载视频
    reloadVideo() {
      this.setData({ videoError: false });
      const videoContext = wx.createVideoContext('detail-video', this);
      videoContext.play();
    },
    
    // 显示更多选项
    showMoreOptions() {
      wx.showActionSheet({
        itemList: ['举报', '不感兴趣'],
        success: (res) => {
          if (res.tapIndex === 0) {
            wx.showToast({
              title: '举报成功',
              icon: 'success'
            });
          } else if (res.tapIndex === 1) {
            wx.showToast({
              title: '已减少此类内容推荐',
              icon: 'none'
            });
          }
        }
      });
    },
    
    // 加载评论
    loadComments() {
      // 模拟评论数据
      const comments = [
        {
          id: 1,
          name: '用户A',
          avatar: '/images/default-avatar.png',  // 使用本地图片
          content: '这个视频太棒了！',
          time: '2小时前'
        },
        {
          id: 2,
          name: '用户B',
          avatar: 'https://placekitten.com/51/51',
          content: '学到了很多，感谢分享',
          time: '3小时前'
        }
      ];
      
      this.setData({ 
        comments,
        commentCount: comments.length
      });
    },
    
    // 加载点赞状态
    loadLikeStatus() {
      // 模拟点赞数据
      this.setData({
        isLiked: false,
        likeCount: 128
      });
    },
    
    // 切换点赞状态
    toggleLike() {
      const isLiked = !this.data.isLiked;
      const likeCount = isLiked ? this.data.likeCount + 1 : this.data.likeCount - 1;
      
      this.setData({
        isLiked,
        likeCount
      });
      
      // 这里可以添加向服务器提交点赞状态的代码
    },
    
    // 聚焦评论输入框
    focusCommentInput() {
      this.setData({
        commentInputFocus: true
      });
    },
    
    // 评论输入变化
    onCommentInput(e) {
      this.setData({
        commentText: e.detail.value
      });
    },
    
    // 提交评论
    submitComment() {
      if (!this.data.commentText.trim()) return;
      
      // 获取当前时间
      const now = new Date();
      const timeStr = '刚刚';
      
      // 创建新评论
      const newComment = {
        id: this.data.comments.length + 1,
        name: this.data.userInfo ? this.data.userInfo.nickName : '匿名用户',
        avatar: this.data.userInfo ? this.data.userInfo.avatarUrl : 'https://placekitten.com/50/50',
        content: this.data.commentText,
        time: timeStr
      };
      
      // 更新评论列表
      const comments = [newComment, ...this.data.comments];
      
      this.setData({
        comments,
        commentCount: comments.length,
        commentText: '',
        commentInputFocus: false
      });
      
      // 这里可以添加向服务器提交评论的代码
    },
    
    // 分享视频
    shareVideo() {
      wx.showShareMenu({
        withShareTicket: true,
        menus: ['shareAppMessage', 'shareTimeline']
      });
    },
    
    // 阻止事件冒泡
    preventBubble(e) {
      console.log('preventBubble 被触发', e);
      return false;
    },

    // 添加触摸事件处理
    handleTouchStart(e) {
      this.setData({
        touchStartY: e.touches[0].clientY,
        isDragging: true,
        touchMoveY: 0
      });
    },

    handleTouchMove(e) {
      if (!this.data.isDragging) return;
      
      const moveY = e.touches[0].clientY - this.data.touchStartY;
      if (moveY < 0) return; // 只允许向下拖动

      // 使用动画实例更新位置
      this.animation.translateY(moveY).step({duration: 0});
      this.setData({
        animationData: this.animation.export(),
        touchMoveY: moveY
      });
    },

    handleTouchEnd() {
      if (!this.data.isDragging) return;
      
      const moveY = this.data.touchMoveY;
      if (moveY > 150) { // 如果下拉超过150px，触发关闭
        this.handleClose();
      } else { // 否则回弹
        this.animation.translateY(0).step();
        this.setData({
          animationData: this.animation.export()
        });
      }
      
      this.setData({
        isDragging: false,
        touchMoveY: 0
      });
    },

    // 添加新的事件监听函数
    onPopupTap(e) {
      console.log('=== 弹窗点击 ===', e);
    },

    onControlsTap(e) {
      console.log('=== 控制区域点击 ===', e);
    },

    onIconTap(e) {
      console.log('=== 图标点击 ===', e);
      // 阻止事件冒泡
      e.stop();
    },

    handleClose() {
      // 先暂停当前播放的视频
      if (this.videoContext) {
        this.videoContext.pause();
      }
      
      this.animation.translateY('100%').step();
      this.setData({
        animationData: this.animation.export()
      });

      setTimeout(() => {
        this.triggerEvent('close');
      }, 300);
    },

    // 视频播放时间更新
    onTimeUpdate(e) {
      const currentTime = e.detail.currentTime;
      const duration = e.detail.duration;
      const progress = (currentTime / duration) * 100;
      
      // 保存视频总时长
      if (this.data.videoDuration !== duration) {
        this.setData({
          videoDuration: duration
        });
      }
      
      this.setData({
        progress,
        currentTime: this.formatTime(currentTime),
        totalTime: this.formatTime(duration)
      });
    },

    // 切换播放/暂停
    togglePlay() {
      const videoContext = wx.createVideoContext('detail-video', this);
      if (this.data.isPlaying) {
        videoContext.pause();
      } else {
        // 如果视频已经播放完，从头开始播放
        if (this.data.progress >= 100) {
          videoContext.seek(0);
        }
        videoContext.play();
      }
      this.setData({ isPlaying: !this.data.isPlaying });
    },

    // 切换全屏
    toggleFullscreen() {
      const videoContext = wx.createVideoContext('detail-video', this);
      if (!this.data.isFullscreen) {
        // 根据视频方向决定全屏方向
        if (this.data.videoOrientation === 'vertical') {
          videoContext.requestFullScreen({ direction: 0 });
        } else {
          videoContext.requestFullScreen({ direction: 90 });
        }
      } else {
        videoContext.exitFullScreen();
      }
    },

    // 格式化时间
    formatTime(seconds) {
      const min = Math.floor(seconds / 60);
      const sec = Math.floor(seconds % 60);
      return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    },

    // 视频容器点击事件
    onVideoContainerTap() {
      // 切换控制栏显示状态
      this.setData({
        controlsVisible: !this.data.controlsVisible
      });

      // 如果控制栏显示，则设置定时器自动隐藏
      if (this.data.controlsVisible) {
        if (this.data.controlsTimer) {
          clearTimeout(this.data.controlsTimer);
        }
        this.data.controlsTimer = setTimeout(() => {
          this.setData({
            controlsVisible: false
          });
        }, 3000);  // 3秒后自动隐藏
      }
    },

    // 处理全屏变化
    onFullscreenChange(e) {
      const isFullscreen = e.detail.fullScreen;
      
      // 先更新状态
      this.setData({ 
        isFullscreen,
        showFullscreenControls: isFullscreen,
        controlsVisible: true
      });

      const videoContext = wx.createVideoContext('detail-video', this);
      
      if (isFullscreen) {
        // 根据视频方向设置不同的全屏方向
        if (this.data.videoOrientation === 'vertical') {
          // 竖向视频强制使用竖屏方向
          videoContext.requestFullScreen({ direction: 0 }); // 0 表示竖屏
        } else {
          // 横向视频使用横屏方向
          videoContext.requestFullScreen({ direction: 90 }); // 90 表示横屏
        }
      } else {
        // 退出全屏时恢复原有尺寸
        this.setData({
          playerHeight: this.data.minPlayerHeight
        });
      }
    },

    // 退出全屏
    exitFullscreen() {
      const videoContext = wx.createVideoContext('detail-video', this);
      videoContext.exitFullScreen();
    },

    // 全屏模式下点击事件
    onFullscreenTap(e) {
      // 如果是滑动操作，不触发点击事件
      if (this.data.isSwiping) return;
      
      // 只处理显示/隐藏控制栏
      this.setData({
        controlsVisible: !this.data.controlsVisible
      });

      if (this.data.controlsVisible) {
        if (this.data.controlsTimer) {
          clearTimeout(this.data.controlsTimer);
        }
        this.data.controlsTimer = setTimeout(() => {
          if (this.data.isFullscreen) {
            this.setData({
              controlsVisible: false
            });
          }
        }, 3000);
      }
    },

    // 开始触摸
    onFullscreenTouchStart(e) {
      if (!this.data.isFullscreen) return;
      
      this.setData({
        touchStartX: e.touches[0].clientX,
        touchStartTime: Date.now(),
        isSwiping: false
      });
    },

    // 触摸移动
    onFullscreenTouchMove(e) {
      if (!this.data.isFullscreen) return;
      
      const moveX = Math.abs(e.touches[0].clientX - this.data.touchStartX);
      const moveTime = Date.now() - this.data.touchStartTime;
      
      // 如果水平移动距离大于10px且时间小于300ms，判定为滑动操作
      if (moveX > 10 && moveTime < 300) {
        this.setData({
          isSwiping: true
        });
        
        // 开始进度调整
        if (!this.data.isDragging) {
          this.setData({
            isDragging: true,
            touchStartTime: (this.data.progress / 100) * this.data.videoDuration
          });
        }
        
        // 计算新进度
        const screenWidth = wx.getSystemInfoSync().windowWidth;
        const timeOffset = ((e.touches[0].clientX - this.data.touchStartX) / screenWidth) * this.data.videoDuration;
        let newTime = this.data.touchStartTime + timeOffset;
        
        // 确保时间在有效范围内
        newTime = Math.max(0, Math.min(newTime, this.data.videoDuration));
        
        // 计算新的进度百分比
        const newProgress = (newTime / this.data.videoDuration) * 100;
        
        // 更新提示位置和时间
        this.setData({
          hintTime: this.formatTime(newTime),
          hintLeft: e.touches[0].clientX,
          progress: newProgress
        });
      }
    },

    // 触摸结束
    onFullscreenTouchEnd(e) {
      if (!this.data.isDragging) return;
      
      const moveX = e.changedTouches[0].clientX - this.data.touchStartX;
      const screenWidth = wx.getSystemInfoSync().windowWidth;
      const timeOffset = (moveX / screenWidth) * this.data.videoDuration;
      let newTime = this.data.touchStartTime + timeOffset;
      
      // 确保时间在有效范围内
      newTime = Math.max(0, Math.min(newTime, this.data.videoDuration));
      
      // 跳转到新时间
      const videoContext = wx.createVideoContext('detail-video', this);
      videoContext.seek(newTime);
      
      this.setData({
        isDragging: false,
        isSwiping: false,
        currentTime: this.formatTime(newTime)
      });
    },

    // 视频播放结束
    onVideoEnded() {
      this.setData({
        isPlaying: false  // 更新播放状态
      });
    },

    // 检测视频方向
    checkVideoOrientation(width, height) {
      // 考虑一些特殊比例的情况
      const ratio = width / height;
      if (ratio > 1.1) { // 宽高比大于1.1认为是横向视频
        return 'horizontal';
      } else if (ratio < 0.9) { // 宽高比小于0.9认为是竖向视频
        return 'vertical';
      } else { // 接近1:1的视频按横向处理
        return 'horizontal';
      }
    },

    // 处理视频加载完成事件
    onVideoLoaded(e) {
      const { width, height } = e.detail;
      const orientation = this.checkVideoOrientation(width, height);
      
      // 不再根据视频方向改变布局，只设置视频方向标记
      this.setData({
        videoOrientation: orientation,
        // 保持统一的播放器高度
        playerHeight: this.data.minPlayerHeight
      });
    },
  }
}) 
Component({
  options: {
    multipleSlots: true // 启用多slot支持
  },
  /**
   * 组件的属性列表
   */
  properties: {
    videoInfo: {
      type: Object,
      value: {}
    },
    extClass: {
      type: String,
      value: ''
    },
    borderRadius: {
      type: String,
      value: '12px'
    },
    // 修改属性：是否在视口中心
    isInViewCenter: {
      type: Boolean,
      value: false,
      observer: function(newVal, oldVal) {
        if (newVal && !oldVal) {
          // 清除之前的定时器
          if (this.playTimer) {
            clearTimeout(this.playTimer);
          }
          // 设置新的定时器，调整为500ms后播放
          this.playTimer = setTimeout(() => {
            // 确保视频仍在视口中心且不在滚动
            if (this.properties.isInViewCenter && !this.properties.isScrolling) {
              this.playVideo();
            }
          }, 500);
        } 
        else if (!newVal && oldVal) {
          // 清除可能存在的播放定时器
          if (this.playTimer) {
            clearTimeout(this.playTimer);
            this.playTimer = null;
          }
          this.pauseVideo();
        }
      }
    },
    // 添加滚动状态属性
    isScrolling: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        // 如果开始滚动，暂停视频
        if (newVal && this.data.isPlaying) {
          this.pauseVideo();
        }
        // 如果停止滚动且在视口中心，延迟播放视频
        else if (!newVal && this.properties.isInViewCenter) {
          if (this.playTimer) {
            clearTimeout(this.playTimer);
          }
          this.playTimer = setTimeout(() => {
            if (this.properties.isInViewCenter) {
              this.playVideo();
            }
          }, 500);
        }
      }
    },
  },
  /**
   * 组件的初始数据
   */
  data: {
    isPlaying: false,
    showControls: false,
    videoContext: null,
    keepVideoVisible: false, // 新增状态，表示保持视频可见
    isMuted: true, // 默认静音
    isDetailShow: false, // 新增状态，表示是否在详情页面
    posterVideoContext: null, // 新增属性，用于存储封面视频上下文
    showReplayButton: false,  // 添加重播按钮显示状态
    playTimer: null  // 添加播放定时器
  },
  lifetimes: {
    attached() {
      // 创建视频上下文
      this.videoContext = null;
      this.playTimer = null;  // 添加播放定时器
    },
    detached() {
      // 组件销毁时清理资源
      if (this.playTimer) {
        clearTimeout(this.playTimer);
        this.playTimer = null;
      }
      if (this.data.isPlaying) {
        this.pauseVideo();
      }
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    // 播放视频
    playVideo() {
      if (this.data.isPlaying) return;
      
      this.setData({
        isPlaying: true,
        keepVideoVisible: true,
        showControls: false
      });
      
      // 延迟获取视频上下文，确保视频元素已创建
      setTimeout(() => {
        this.videoContext = wx.createVideoContext('video-' + this.data.videoInfo.id, this);
        this.videoContext.play();
      }, 100);
      
      this.triggerEvent('play', { videoId: this.data.videoInfo.id }, {});
    },
    
    // 暂停视频
    pauseVideo() {
      if (!this.data.isPlaying) return;
      
      if (this.videoContext) {
        try {
          this.videoContext.pause();
        } catch (e) {
          console.error('暂停视频失败:', e);
        }
      }
      
      this.setData({
        isPlaying: false,
        keepVideoVisible: true,
        showReplayButton: false
      }, () => {
        this.triggerEvent('pause', { videoId: this.data.videoInfo.id }, {});
      });
    },
    
    // 修改完全停止视频的方法（仅在需要完全停止时使用，如组件销毁时）
    stopVideo() {
      if (!this.data.isPlaying && !this.data.keepVideoVisible) return;
      
      if (this.videoContext) {
        try {
          this.videoContext.stop();
        } catch (e) {
          console.error('停止视频失败:', e);
        }
      }
      
      this.setData({
        isPlaying: false,
        keepVideoVisible: false
      });
    },
    
    // 视频播放结束
    videoEnd() {
      this.setData({
        isPlaying: false,
        keepVideoVisible: true,
        showReplayButton: true,
      });
      this.triggerEvent('end', { videoId: this.data.videoInfo.id }, {});
    },
    
    // 点击视频卡片
    onTap() {
      // 点击时立即暂停当前视频
      if (this.data.isPlaying) {
        this.pauseVideo();
      }
      
      // 触发卡片点击事件
      this.onCardTap();
    },
    
    // 修改showMore方法为分享功能
    showMore() {
      // 触发自定义分享事件，传递当前视频信息
      this.triggerEvent('share', { 
        videoId: this.data.videoInfo.id,
        title: this.data.videoInfo.title,
        imageUrl: this.data.videoInfo.coverUrl,
        path: `/pages/video-detail/video-detail?id=${this.data.videoInfo.id}`
      });
    },
    
    // 修改切换静音状态的方法
    toggleMute(e) {
      // 检查事件对象是否存在并有stopPropagation方法
      if (e && typeof e.stopPropagation === 'function') {
        // 阻止事件冒泡，避免触发视频的点击事件
        e.stopPropagation();
      }
      
      // 切换静音状态
      const newMuteState = !this.data.isMuted;
      
      // 更新状态
      this.setData({
        isMuted: newMuteState
      }, () => {
        console.log('静音状态已切换为:', newMuteState ? '静音' : '有声音');
      });
    },
    
    // 添加分享方法
    showShare() {
      // 触发页面的分享事件
      wx.showShareMenu({
        withShareTicket: true,
        menus: ['shareAppMessage', 'shareTimeline']
      });
    },
    
    // 修改 onCardTap 方法
    onCardTap() {
      // 获取视频ID
      const videoId = this.data.videoInfo.id;
      console.log('视频卡片被点击:', videoId);
      
      // 暂停当前视频
      if (this.data.isPlaying) {
        this.pauseVideo();
      }
      
      // 触发自定义事件，传递给父组件
      this.triggerEvent('cardtap', { videoId });
    },
    
    // 重播方法
    replayVideo(e) {
      console.log('重播按钮被点击');

      // 先创建视频上下文
      this.videoContext = wx.createVideoContext('video-' + this.data.videoInfo.id, this);
      
      // 重置状态并重新播放
      this.setData({
        isPlaying: true,
        showReplayButton: false,
        keepVideoVisible: true
      }, () => {
        console.log('准备重新播放视频');
        this.videoContext.seek(0);
        setTimeout(() => {
          console.log('开始播放视频');
          this.videoContext.play();
        }, 100);
      });
    }
  }
}) 
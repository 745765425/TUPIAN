// pages/gallery/index.js
const galleryConfig = require('../../config/gallery/config.js');
const qiniuConfig = require('../../config/qiniu/config.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    leftImages: [],
    rightImages: [],
    loading: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.loadImages();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.loadImages().then(() => {
      wx.stopPullDownRefresh();
    });
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  // 加载图片
  async loadImages() {
    try {
      this.setData({ loading: true });
      
      const imageList = [
        'IMG_8001.JPG',
        'IMG_8002.JPG',
        'IMG_8003.JPG',
        'IMG_8004.JPG',
        'IMG_8005.JPG',
        'IMG_8006.JPG',
        'IMG_8008.JPG',
        'IMG_8009.JPG',
        'IMG_8010.JPG',
        'IMG_8011.JPG',
        'IMG_8012.JPG'
      ];
      
      // 打印每个图片的加载状态
      const images = await Promise.all(imageList.map(async filename => {
        const url = `${galleryConfig.storage.domain}${filename}`;
        try {
          // 测试图片是否可访问
          await wx.getImageInfo({ src: url });
          console.log('图片加载成功:', filename);
          return {
            id: filename,
            url: url,
            name: filename,
            updateTime: new Date().getTime()
          };
        } catch (error) {
          console.error('图片加载失败:', filename, error);
          return null;
        }
      }));

      this.distributeImages(images.filter(img => img !== null).sort((a, b) => b.updateTime - a.updateTime));
    } catch (error) {
      console.error('加载图片失败:', error);
      this.setData({ loading: false });
    }
  },

  distributeImages(images) {
    const leftImages = [];
    const rightImages = [];
    
    images.forEach((image, index) => {
      if (index % 2 === 0) {
        leftImages.push(image);
      } else {
        rightImages.push(image);
      }
    });

    this.setData({
      leftImages,
      rightImages
    });
  },

  // 修改预览图片方法
  previewImage(e) {
    const { url } = e.currentTarget.dataset;
    
    // 合并左右列的图片数组
    const allImages = [...this.data.leftImages, ...this.data.rightImages];
    const urls = allImages.map(img => img.url);
    
    wx.previewImage({
      current: url,
      urls,
      showmenu: true,  // 显示长按菜单，支持保存
      success: () => {
        console.log('预览成功');
      },
      fail: (error) => {
        console.error('预览失败:', error);
      }
    });
  },

  // 切换分类
  switchCategory(e) {
    const { path } = e.currentTarget.dataset;
    const category = path.split('/')[1];  // 获取分类名称
    this.setData({ currentCategory: category }, () => {
      this.loadImages();
    });
  }
})
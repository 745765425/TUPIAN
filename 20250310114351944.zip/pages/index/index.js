// index.js
const configUtils = require('../../utils/config.js');
const zhuyeConfig = require('../../config/zhuye/config.js');
const qidongyeConfig = require('../../config/qidongye/images.js');

// 直接引用对象属性，不使用解构赋值
const courseConfig = configUtils.courseConfig;

Page({
  data: {
    currentIndex: 0,
    topIndex: 0,
    showLaunch: true,
    launchOpacity: 1,
    courseList: [],  // 初始为空
    launchAnimation: null,
    launchImages: qidongyeConfig.launchImages,
    animationConfig: qidongyeConfig.animation,   // 获取动画配置
    styleConfig: qidongyeConfig.style,          // 获取样式配置
    topSlides: zhuyeConfig.topSlides,
    activeIcon: '',  // 当前激活的图标
    iconTapLock: false,  // 防止重复点击
    showVideo: false,
    currentVideo: null,
    texts: [],
    configVersion: 0,  // 添加配置版本号
    pageReady: false,
    scrollTimer: null,
    hasMoreContent: true,
    isLoadingMore: false
  },

  onLoad: function(options) {
    try {
      // 初始化数据 - 合并多个setData为一个
      const config = require('../../utils/config.js');
      const zhuyeConfig = require('../../config/zhuye/config.js');
      
      // 安全地加载texts数据
      let texts = [];
      if (zhuyeConfig && zhuyeConfig.texts && Array.isArray(zhuyeConfig.texts)) {
        texts = this._processTexts(zhuyeConfig.texts);
      } else if (zhuyeConfig && zhuyeConfig.courseList && Array.isArray(zhuyeConfig.courseList)) {
        // 如果没有texts但有courseList，转换格式
        texts = zhuyeConfig.courseList.map(item => ({
          text: item.text || '',
          color: item.color || '#FFFFFF',
          videoUrl: item.videoUrl || '',
          subtitle: '',
          description: ''
        }));
      }
      
      // 合并多个setData为一个
      this.setData({
        courseList: [],
        showLaunch: true,
        launchOpacity: 1,
        activeIcon: '',
        showDetail: false,
        showVideo: false,
        currentItem: null,
        currentVideo: null,
        configVersion: 1,
        texts
      });
      
      // 加载课程列表
      this.loadCourseList();
    } catch (error) {
      console.error('启动页初始化错误:', error);
      // 确保应用不会崩溃
      this.setData({
        courseList: [],
        texts: [],
        showLaunch: true
      });
    }
  },

  onShow() {
    this.setData({
      showVideo: false,
      currentVideo: null
    });
    
    this._initList();
    this.refreshConfig();
  },

  _initList() {
    this.setData({
      courseList: courseConfig.list.map((item, index) => ({
        id: index + 1,
        number: String(index + 1),
        bgColor: item.bgColor || '#4DC591',
        text: item.text,
        video: item.video,
        _ready: true
      }))
    });
  },

  // 背景切换事件处理
  onBackgroundChange(e) {
    this.setData({
      currentIndex: e.detail.current
    });
  },

  // 顶部组件切换事件处理
  onTopChange(e) {
    this.setData({
      topIndex: e.detail.current
    });
  },

  // 触摸事件处理
  handleTouchStart() {
    // 创建动画实例
    const animation = wx.createAnimation({
      duration: 1200,  // 保持原来的动画时间
      timingFunction: 'cubic-bezier(0.33, 0, 0.67, 1)',  // 使用更平滑的缓动函数
      delay: 0
    });
    
    // 设置渐隐动画
    animation.opacity(0).step();
    
    this.setData({
      launchAnimation: animation.export()
    });

    // 预加载主页内容，确保平滑过渡
    this.preloadMainContent();

    setTimeout(() => {
      this.setData({
        showLaunch: false
      });
      
      // 显示主页内容的淡入动画
      this.showMainContentWithAnimation();
    }, 1200);  // 保持与动画时间一致
  },

  handleIconTap: function(e) {
    const icon = e.currentTarget.dataset.icon;
    
    this.setData({
      activeIcon: icon
    });
    
    // 移除加载提示，保留短暂延迟以便用户感知点击效果
    setTimeout(() => {
      // 根据不同图标执行不同操作
      if (icon === 'product') {
        // 跳转到产品详情页面
        wx.navigateTo({
          url: '/pages/detail/index',
          fail: (error) => {
            console.error('跳转失败:', error);
            wx.showToast({
              title: '跳转失败，请重试',
              icon: 'none'
            });
          }
        });
      } else if (icon === 'course') {
        // 跳转到图片预览页面
        wx.navigateTo({
          url: '/pages/gallery/index',
          fail: (error) => {
            console.error('跳转失败:', error);
            wx.showToast({
              title: '跳转失败，请重试',
              icon: 'none'
            });
          }
        });
      }
    }, 200); // 短暂延迟，让用户感知到点击效果
  },

  preloadDetailPage() {
    // 预加载详情页需要的图片等资源
    const preloadImages = [
      'https://cdn.jsdelivr.net/gh/745765425/TUPIAN/2.png'
    ];
    
    Promise.all(preloadImages.map(url => {
      return new Promise((resolve, reject) => {
        wx.getImageInfo({
          src: url,
          success: (res) => resolve(res),
          fail: (err) => reject(err)
        });
      });
    }))
    .catch(error => {
      console.error('Image preload failed:', error);
    });
  },

  onHide() {
    this.setData({
      showVideo: false,
      currentVideo: null,
      launchImages: null,
      animationConfig: null,
      styleConfig: null
    });
  },

  handleItemClick: function(e) {
    const index = e.currentTarget.dataset.index;
    const item = this.data.courseList[index];
    
    if (!item) {
      console.error('无效的课程项目');
      return;
    }
    
    // 判断是视频还是详情页
    if (item.videoUrl) {
      this.setData({
        showVideo: true,
        currentVideo: {
          url: item.videoUrl || '',
          title: item.text || ''
        }
      });
    } else {
      // 确保currentItem是有效对象
      this.setData({
        showDetail: true,
        currentItem: {
          id: item.id,
          title: item.text || '课程详情',
          description: item.description || '暂无详细描述',
          bgColor: item.bgColor || '#FFFFFF'
        }
      });
    }
  },

  onVideoClose() {
    this.setData({
      showVideo: false,
      currentVideo: null
    });
  },

  onPageTap() {
    if (this.data.showVideo) {
      this.setData({
        showVideo: false,
        currentVideo: null
      });
    }
  },

  onItemTap(e) {
    const { index } = e.currentTarget.dataset;
    const item = this.data.texts[index];
    
    if (item.videoUrl) {
      this.setData({
        showVideo: true,
        currentVideo: {
          videoUrl: item.videoUrl,
          title: item.text,
          subtitle: item.subtitle || '',
          description: item.description || ''
        }
      });
    }
  },

  _processTexts(texts) {
    // 添加空值检查
    if (!texts || !Array.isArray(texts)) {
      console.warn('texts不是有效数组，返回空数组');
      return [];
    }
    
    return texts.map(text => {
      // 确保text是字符串
      if (typeof text !== 'string') {
        return {
          text: '',
          color: '#FFFFFF',
          videoUrl: '',
          subtitle: '',
          description: ''
        };
      }
      
      const [content, color, videoUrl, ...rest] = text.split('|');
      return {
        text: content || '',
        color: color || '#FFFFFF',
        videoUrl: videoUrl || '',
        subtitle: rest[0] || '',
        description: rest[1] || ''
      };
    });
  },

  refreshConfig() {
    this.setData({
      configVersion: this.data.configVersion + 1
    });
  },

  onLaunchComplete: function() {
    // 创建动画实例，保持与handleTouchStart相同的动画参数
    const animation = wx.createAnimation({
      duration: 1200,
      timingFunction: 'ease-out',
      delay: 0
    });
    
    animation.opacity(0).step();
    
    this.setData({
      launchAnimation: animation.export()
    });
    
    setTimeout(() => {
      this.setData({
        showLaunch: false
      });
      
      // 延迟加载主页内容
      this.loadMainContent();
    }, 1200);
  },

  loadCourseList: function() {
    // 只有在首次加载或刷新时显示加载提示
    const isFirstLoad = !wx.getStorageSync('courseList');
    if (isFirstLoad) {
      wx.showLoading({
        title: '加载中...',
        mask: true
      });
    }
    
    // 检查缓存是否过期
    const cacheTime = wx.getStorageSync('courseListCacheTime');
    const now = Date.now();
    const cacheExpired = !cacheTime || (now - cacheTime > 3600000); // 1小时过期
    
    // 如果缓存未过期且不是强制刷新，直接使用缓存
    if (!cacheExpired && !this.data.forceRefresh) {
      const cachedList = wx.getStorageSync('courseList');
      if (cachedList && cachedList.length > 0) {
        this.setData({ courseList: cachedList });
        if (isFirstLoad) {
          wx.hideLoading();
        }
        return;
      }
    }
    
    // 从配置文件加载数据
    try {
      // 使用utils/config.js中的processConfig函数处理配置
      const configUtils = require('../../utils/config.js');
      const config = require('../../config/zhuye/config.js');
      const processedConfig = configUtils.processConfig(config);
      
      // 确保courseList存在
      const courseList = processedConfig.courseList || [];
      
      // 处理数据前检查数组
      if (Array.isArray(courseList) && courseList.length > 0) {
        // 处理数据
        const formattedList = courseList.map((item, index) => {
          return {
            id: index + 1,
            number: (index + 1).toString().padStart(2, '0'),
            text: item.text || '',
            bgColor: item.color || '#FFFFFF',
            videoUrl: item.videoUrl || ''
          };
        });
        
        // 更新数据并缓存
        this.setData({ courseList: formattedList });
        wx.setStorageSync('courseList', formattedList);
        wx.setStorageSync('courseListCacheTime', now);
      } else {
        // 使用默认值
        this.setDefaultCourseList();
      }
    } catch (error) {
      console.error('加载课程列表失败:', error);
      // 出错时使用默认值
      this.setDefaultCourseList();
    } finally {
      // 隐藏加载提示
      if (isFirstLoad) {
        wx.hideLoading();
      }
    }
  },

  setDefaultCourseList: function() {
    const defaultList = [
      {
        id: 1,
        number: '01',
        text: '美甲基础知识',
        bgColor: '#FFE8E8',
        videoUrl: ''
      },
      {
        id: 2,
        number: '02',
        text: '美甲工具使用',
        bgColor: '#E8F4FF',
        videoUrl: ''
      },
      {
        id: 3,
        number: '03',
        text: '基础款式教学',
        bgColor: '#E8FFEA',
        videoUrl: ''
      }
    ];
    
    this.setData({ courseList: defaultList });
    wx.setStorageSync('courseList', defaultList);
  },

  loadMainContent: function() {
    // 加载主页所需的所有数据
    this.loadCourseList();
    this.preloadDetailPage();
    this.preloadImages();
  },

  // 优化图片预加载函数
  preloadImages: function() {
    const images = [
      '/assets/product.svg',
      '/assets/course.svg',
      '/assets/arrow-right.svg'
    ];
    
    // 静默预加载图标和常用图片
    images.forEach(src => {
      wx.getImageInfo({
        src,
        success: () => {
          // 静默成功，不显示日志
        },
        fail: () => {
          // 静默失败，不显示错误
        }
      });
    });
    
    // 预加载背景图片
    if (this.data.topSlides && this.data.topSlides.length > 0) {
      this.data.topSlides.forEach(slide => {
        if (slide.url) {
          wx.getImageInfo({
            src: slide.url,
            success: () => {
              // 静默成功
            },
            fail: () => {
              // 静默失败
            }
          });
        }
      });
    }
  },

  // 添加页面分享功能
  onShareAppMessage: function() {
    return {
      title: '美甲学院 - 专业美甲教学平台',
      path: '/pages/index/index',
      imageUrl: '/assets/share-image.png' // 分享图片
    };
  },

  // 添加分享到朋友圈
  onShareTimeline: function() {
    return {
      title: '美甲学院 - 专业美甲教学平台',
      query: '',
      imageUrl: '/assets/share-image.png'
    };
  },

  // 优化onReady函数，提前准备资源
  onReady: function() {
    // 页面首次渲染完成后，预加载一些资源
    if (!this.data.showLaunch) {
      // 如果不显示启动页，直接预加载资源
      this.preloadImages();
      this.preloadDetailPage();
    }
    
    // 注册页面滚动监听，优化滚动性能
    this.setData({
      pageReady: true
    });
  },

  // 优化onUnload函数，清理资源
  onUnload: function() {
    // 清理缓存的临时数据
    this.setData({
      currentVideo: null,
      currentItem: null,
      launchAnimation: null
    });
    
    // 释放一些不需要的资源
    if (this.videoContext) {
      this.videoContext = null;
    }
  },

  // 添加页面滚动优化
  onPageScroll: function(e) {
    // 使用节流函数处理滚动事件
    if (this.scrollTimer) {
      return;
    }
    
    this.scrollTimer = setTimeout(() => {
      // 滚动时的性能优化
      if (e.scrollTop > 100) {
        // 当页面滚动到一定位置时，可以考虑懒加载更多内容
        this.loadMoreContentIfNeeded();
      }
      
      this.scrollTimer = null;
    }, 100);
  },

  // 懒加载更多内容
  loadMoreContentIfNeeded: function() {
    // 检查是否需要加载更多内容
    if (this.data.hasMoreContent && !this.data.isLoadingMore) {
      this.setData({
        isLoadingMore: true
      });
      
      // 模拟加载更多内容
      setTimeout(() => {
        this.setData({
          isLoadingMore: false
        });
      }, 500);
    }
  },

  // 预加载主页内容
  preloadMainContent: function() {
    // 在启动页消失前预加载主页内容
    this.loadCourseList();
    this.preloadImages();
  },

  // 显示主页内容的淡入动画
  showMainContentWithAnimation: function() {
    // 创建主页内容的淡入动画
    const animation = wx.createAnimation({
      duration: 800,
      timingFunction: 'ease-out',
      delay: 0
    });
    
    animation.opacity(1).step();
    
    this.setData({
      mainContentAnimation: animation.export()
    });
  }
});

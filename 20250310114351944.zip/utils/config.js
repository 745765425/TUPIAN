// 安全地获取配置
let zhuyeConfig;
try {
  zhuyeConfig = require('../config/zhuye/config.js');
} catch (error) {
  console.error('加载主页配置失败:', error);
  zhuyeConfig = {};
}

// 课程列表配置 - 避免使用解构赋值
const courseConfig = {
  list: []
};

// 尝试处理课程列表
try {
  // 检查texts是否存在
  if (zhuyeConfig.texts && Array.isArray(zhuyeConfig.texts)) {
    courseConfig.list = zhuyeConfig.texts.map(function(line) {
      const parts = line.split('|');
      return {
        text: parts[0] || '',
        bgColor: parts[1] || '#4DC591',
        video: {
          url: parts[2] || '',
          title: parts[3] || '',
          subtitle: parts[4] || '',
          description: parts[5] || '',
          popupColor: parts[6] || '#FFFFFF'
        }
      };
    });
  } else if (zhuyeConfig.courseList && Array.isArray(zhuyeConfig.courseList)) {
    // 如果使用新的courseList格式
    courseConfig.list = zhuyeConfig.courseList.map(function(item) {
      return {
        text: item.text || '',
        bgColor: item.color || '#4DC591',
        video: {
          url: item.videoUrl || '',
          title: item.text || '',
          subtitle: '',
          description: '',
          popupColor: '#FFFFFF'
        }
      };
    });
  }
} catch (error) {
  console.error('处理课程列表失败:', error);
}

// 背景色函数
function getBgColor(index) {
  const colors = ['#4DC591', '#5097FF', '#FC8BAB', '#FFD858'];
  return colors[index % colors.length] || '#4DC591';
}

// 添加启动页配置
const launchImages = [
  {
    id: 'launch1',
    url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/%E9%A3%8E%E6%89%8744.webp'
  },
  // ... 其他图片
];

// 添加空值检查
function processConfig(config) {
  return config || {};
}

// 导出对象，不使用简写语法
module.exports = {
  courseConfig: courseConfig,
  launchImages: zhuyeConfig.launchImages || [],
  processConfig: processConfig,
  getBgColor: getBgColor
}; 
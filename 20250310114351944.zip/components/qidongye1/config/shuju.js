// 直接导出配置对象
module.exports = {
  // 背景图片配置（与轮播图对应）
  images: [
    {
      id: 'bg1',          // 背景图ID（不要修改）
      url: "http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/%E9%A3%8E%E6%89%8744.webp",  // 替换成您的背景图链接
      blur: 5,            // 模糊度（可以调整：0-10，数值越大越模糊）
      opacity: 0.8        // 透明度（可以调整：0-1，数值越小越透明）
    },
    // 第二张背景图配置（按相同方式修改）
    {
      id: 'bg2',
      url: "http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/5.webp",  // 替换成您的背景图链接
      blur: 5,
      opacity: 0.8
    },
    // 第三张背景图配置（按相同方式修改）
    {
      id: 'bg3',
      url: "http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/6.webp",  // 替换成您的背景图链接
      blur: 5,
      opacity: 0.8
    }
  ],
  backgrounds: [
    {
      id: 'launch1',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/%E9%A3%8E%E6%89%8744.webp',
    },
    // ... 其他背景
  ]
}; 

// 检查图片URL是否有效
// 考虑使用CDN加速图片加载 
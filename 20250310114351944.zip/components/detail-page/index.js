Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    },
    itemData: {
      type: Object,
      value: {}
    }
  },

  data: {
    animation: null
  },

  methods: {
    showDetail() {
      const animation = wx.createAnimation({
        duration: 300,
        timingFunction: 'ease-out'
      });
      animation.translateY(0).step();
      this.setData({ animation: animation.export() });
    },

    hideDetail() {
      const animation = wx.createAnimation({
        duration: 300,
        timingFunction: 'ease-in'
      });
      animation.translateY('100%').step();
      this.setData({ animation: animation.export() });
      
      setTimeout(() => {
        this.triggerEvent('close');
      }, 300);
    }
  }
}); 
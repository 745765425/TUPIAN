const express = require('express');
const qiniu = require('qiniu');
const cors = require('cors');
const app = express();

// 启用 CORS
app.use(cors());

// 七牛云配置
const config = {
  accessKey: '2K6PDf3UAMX_k8Egp6zn2Hz7phIKUhwr59hTd_',
  secretKey: '您的SecretKey',  // 请填入您的 SecretKey
  bucket: 'nailart2024'
};

// 初始化七牛云
const mac = new qiniu.auth.digest.Mac(config.accessKey, config.secretKey);
const qiniuConfig = new qiniu.conf.Config();
qiniuConfig.zone = qiniu.zone.Zone_z2;  // 华南区域
const bucketManager = new qiniu.rs.BucketManager(mac, qiniuConfig);

// 获取文件列表的接口
app.get('/api/images', (req, res) => {
  bucketManager.listPrefix(config.bucket, {
    limit: 1000
  }, (err, respBody, respInfo) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: '获取文件列表失败' });
    }
    
    if (respInfo.statusCode === 200) {
      const images = respBody.items
        .filter(item => item.key.toLowerCase().endsWith('.jpg'))
        .map(item => ({
          name: item.key,
          updateTime: item.putTime
        }));
      
      res.json(images);
    } else {
      res.status(respInfo.statusCode).json({ error: '获取文件列表失败' });
    }
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`服务启动在 http://localhost:${PORT}`);
}); 
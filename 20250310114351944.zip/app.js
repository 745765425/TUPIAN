// app.js
App({
  onLaunch() {
    // 使用新的API替代废弃的wx.getSystemInfoSync
    try {
      const deviceInfo = wx.getDeviceInfo();
      const windowInfo = wx.getWindowInfo();
      const appBaseInfo = wx.getAppBaseInfo();
      
      // 避免使用对象展开语法
      this.globalData.systemInfo = {};
      // 手动复制属性
      Object.assign(this.globalData.systemInfo, deviceInfo);
      Object.assign(this.globalData.systemInfo, windowInfo);
      Object.assign(this.globalData.systemInfo, appBaseInfo);
      
      // 判断是否为 iPhone X 系列
      this.globalData.isIPhoneX = windowInfo.safeArea && 
        windowInfo.screenHeight - windowInfo.safeArea.bottom > 34;
        
      // 记录启动性能
      this.recordLaunchPerformance();
    } catch (error) {
      // 如果新API不可用，回退到旧API
      console.log('系统信息:', wx.getSystemInfoSync());
    }
  },
  
  // 记录启动性能
  recordLaunchPerformance() {
    const startTime = Date.now();
    
    // 在页面加载完成后记录时间
    this.globalData.appLaunchTime = startTime;
    
    // 监听页面首次渲染完成
    wx.onAppShow(() => {
      const renderTime = Date.now() - startTime;
      console.log('应用启动到渲染完成时间:', renderTime + 'ms');
      
      // 可以将性能数据上报到服务器
      this.reportPerformance({
        type: 'launch',
        duration: renderTime
      });
    });
  },
  
  // 上报性能数据
  reportPerformance(data) {
    // 模拟上报数据
    console.log('性能数据:', data);
    // 实际项目中可以发送到服务器
  },

  onError(error) {
    console.error('App Error:', error);
    
    // 记录错误信息
    this.reportError({
      type: 'js',
      message: error
    });
    
    if (error && error.message) {
      wx.showToast({
        title: '遇到一些问题，请稍后重试',
        icon: 'none'
      });
    }
  },
  
  // 上报错误信息
  reportError(error) {
    // 模拟上报错误
    console.log('错误数据:', error);
    // 实际项目中可以发送到服务器
  },

  onPageNotFound() {
    wx.redirectTo({
      url: '/pages/index/index'
    });
  },

  globalData: {
    userInfo: null,
    systemInfo: {
      SDKVersion: '',
      brand: '',
      safeArea: {
        bottom: 0,
        height: 0,
        left: 0,
        right: 0,
        top: 0,
        width: 0
      }
    },
    isIPhoneX: false,
    appLaunchTime: 0
  }
});

/**
 * 主页配置文件
 * ====================================
 * 
 * 【配置项说明】
 * 1. topSlides: 主页顶部轮播图配置
 *    - 可以修改图片、标题和副标题
 *    - 可以调整轮播动画效果
 * 
 * 2. courseList: 主页课程列表配置
 *    - 课程内容和视频链接
 *    - 背景颜色等样式
 */

const videoConfig = {
  videoUrl: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4',
  title: '喷枪宣传视频',
  subtitle: '产品介绍',
  description: '这是一段产品介绍视频，展示了产品的主要特点和使用方法。'
};

module.exports = {
  // ↓↓↓ 主页顶部轮播图配置 ↓↓↓
  topSlides: [
    {
      id: 'slide1',
      url: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8001.JPG'
    },
    {
      id: 'slide2',
      url: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8002.JPG'
    },
    {
      id: 'slide3',
      url: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8003.JPG'
    }
  ],
  
  // 轮播图动画配置
  slideAnimation: {
    duration: 800,      // 动画持续时间（毫秒）
    timing: 'ease',     // 动画效果
    interval: 3000      // 自动切换间隔（毫秒）
  },
  
  // 轮播图样式配置
  slideStyle: {
    height: '500rpx',   // 轮播图高度
    radius: '16rpx',    // 圆角大小
    margin: '24rpx',    // 外边距
    blur: 5,            // 背景模糊度
    opacity: 0.8        // 背景透明度
  },

  // ↓↓↓ 主页课程列表配置 ↓↓↓
  courseList: [
    {
      text: "美甲基础知识介绍",
      color: "#FFE8E8",
      videoUrl: ""
    },
    {
      text: "美甲工具使用指南",
      color: "#E8F4FF",
      videoUrl: "http://example.com/video1.mp4"
    },
    {
      text: "基础款式教学",
      color: "#E8FFEA",
      videoUrl: ""
    },
    {
      text: "进阶技巧分享",
      color: "#FFF0E8",
      videoUrl: "http://example.com/video2.mp4"
    },
    {
      text: "流行趋势解析",
      color: "#F0E8FF",
      videoUrl: ""
    }
  ],

  videoConfig
}; 
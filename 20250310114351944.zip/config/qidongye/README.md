# 启动页配置说明

## 文件位置
配置文件位置：`config/qidongye/images.js`

## 如何修改图片
1. 用记事本打开 `images.js` 文件 
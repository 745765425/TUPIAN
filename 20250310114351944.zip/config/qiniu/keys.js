module.exports = {
  accessKey: '2K6PDf3UAMX_k8Egp6zn2Hz7phIKUhwr59hTd_',  // 您的 AccessKey
  secretKey: '您的SecretKey'  // 您的 SecretKey，请填入实际值
}; 
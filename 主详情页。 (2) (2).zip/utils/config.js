const zhuyeConfig = require('../config/zhuye/config.js');
const { texts } = require('../config/zhuye/config.js');

// 启动页配置
const launchConfig = {
  // 启动页图片列表
  launchImages: [
    {
      id: 'launch1',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/%E9%A3%8E%E6%89%8744.webp',
      duration: 3000,
    },
    {
      id: 'launch2',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/5.webp',
      duration: 3000,
    },
    {
      id: 'launch3',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/6.webp',
      duration: 3000,
    }
  ],
  animation: {
    duration: 800,
    timing: 'ease',
  },
  style: {
    blur: 0,
    opacity: 1,
    scale: 1.1,
  }
};

// 课程列表配置
const courseConfig = {
  list: texts.map(line => {
    const [content, bgColor, videoUrl, title, subtitle, description, popupColor] = line.split('|');
    return {
      text: content,
      bgColor: bgColor || '#4DC591',
      video: {
        url: videoUrl,  // 确保视频URL正确传递
        title: title,
        subtitle: subtitle,
        description: description,
        popupColor: popupColor || '#FFFFFF'
      }
    };
  })
};

// 背景色函数
function getBgColor(index) {
  const colors = [
    '#FFE4E1', // 淡玫瑰色
    '#FFB6C1', // 浅粉红
    '#FF6B6B', // 珊瑚红
    '#98D8D8', // 淡青色
    '#B0E0E6', // 粉蓝色
    '#DDA0DD', // 梅红色
    '#E6E6FA', // 淡紫色
    '#F0E68C', // 卡其色
    '#F5DEB3', // 小麦色
    '#FFF0F5', // 淡紫红
    '#E0FFFF', // 淡青色
    '#F0FFF0', // 蜜瓜色
    '#F5F5DC', // 米色
    '#FDF5E6', // 老花色
    '#FAEBD7', // 古董白
    '#FFE4C4', // 桃色
    '#FFDAB9', // 粉橘色
    '#F0FFFF', // 天蓝色
    '#F5FFFA', // 薄荷色
    '#FFF5EE'  // 海贝色
  ];
  return colors[index % colors.length]; // 循环使用颜色
}

module.exports = {
  launchConfig,
  courseConfig
}; 
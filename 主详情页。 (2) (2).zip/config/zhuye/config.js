/**
 * 主页信息列表配置
 * 
 * 使用说明：
 * 1. 直接输入文字，回车换行添加新条目
 * 2. 想改背景色就在文字后面加上 | 和颜色代码
 * 
 * 示例：
 * 美甲培训课程              (使用默认颜色)
 * 专业美甲设计|#FFE4E1      (淡玫瑰色背景)
 * 美甲进阶课程|#B0E0E6      (粉蓝色背景)
 * 
 * 常用颜色：
 * #FFE4E1  淡玫瑰色
 * #FFB6C1  浅粉红色
 * #B0E0E6  粉蓝色
 * #E6E6FA  淡紫色
 * #F0E68C  卡其色
 */

const videoConfig = {
  videoUrl: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4',
  title: '喷枪宣传视频',
  subtitle: '产品介绍',
  description: '这是一段产品介绍视频，展示了产品的主要特点和使用方法。'
}

module.exports = {
  texts: `
美甲培训课程|#FFE4E1|http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4|
美甲培刷到过|#FFE4E1|http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4|
美甲基础教学|零基础快速入门|这是详细介绍|#F8E8E8
专业美甲设计|#FFE4E1|http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4|
设计基础教程|进阶技巧讲解|专业设计教程|#E8F8F8
美甲进阶课程|#B0E0E6|http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4|进阶教程|高级技巧|进阶课程详解|#E8E8F8
创意美甲教学|#E6E6FA|http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4|创意设计|特效教学|创意课程说明|#F8F8E8
高级美甲艺术|#B0E0E6|http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4|艺术创作|专业讲解|高级课程内容|#E8F8F8
高四分五散|#B0E0E6|http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4|艺术创作|专业讲解|高级课程内容|#E8F8F8
`.trim().split('\n'),
  videoConfig
} 
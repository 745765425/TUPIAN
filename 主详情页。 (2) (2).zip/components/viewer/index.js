// 引入配置
const config = require('./config/shuju.js');

Component({
  properties: {
    src: String,
    width: {
      type: String,
      value: '100%'
    },
    height: {
      type: String,
      value: '100%'
    },
    mode: {
      type: String,
      value: 'aspectFill'
    },
    lazyLoad: {
      type: Boolean,
      value: true
    }
  },

  options: {
    styleIsolation: 'shared',
    pureDataPattern: /^_/,
    nativeMode: true
  },

  data: {
    containerStyle: config.containerStyle,
    imageProps: config.imageProps,
    shadowStyle: config.shadowStyle,
    _isLoaded: false,
    _hasError: false,
    loading: true,
    _imageInfo: null,
    _isLoading: true,
    _observer: null,
    _retryCount: 0,
    _maxRetries: 2
  },

  lifetimes: {
    attached() {
      if (config.skylineConfig.optimization) {
        wx.setPageStyle({
          optimizeRender: true,
          enableAcceleration: true
        });
      }
      this._setupObserver();
    },
    detached() {
      this.setData({
        _isLoaded: false,
        _hasError: false
      });
      this._cleanup();
    }
  },

  methods: {
    _setupObserver() {
      try {
        this.data._observer = wx.createIntersectionObserver(this, {
          thresholds: [0, 0.1],
          observeAll: true
        });
        
        this.data._observer.observe('.image-viewer', (res) => {
          if (res.intersectionRatio > 0) {
            this._loadImage();
          }
        });
      } catch (error) {
        console.error('Observer setup error:', error);
      }
    },

    _loadImage() {
      if (this.data._hasError && this.data._retryCount < this.data._maxRetries) {
        this.data._retryCount++;
        this.setData({ _hasError: false, _isLoading: true });
      }
    },

    _cleanup() {
      if (this.data._observer) {
        this.data._observer.disconnect();
        this.data._observer = null;
      }
    },

    onImageLoad(e) {
      try {
        this.setData({ _isLoading: false, _hasError: false });
        this.triggerEvent('load', e.detail);
      } catch (error) {
        console.error('Image load error:', error);
      }
    },

    onImageError(e) {
      try {
        this.setData({ _hasError: true });
        this.triggerEvent('error', e.detail);
        if (this.data._retryCount < this.data._maxRetries) {
          setTimeout(() => this._loadImage(), 1000);
        }
      } catch (error) {
        console.error('Image error handler error:', error);
      }
    }
  }
}); 
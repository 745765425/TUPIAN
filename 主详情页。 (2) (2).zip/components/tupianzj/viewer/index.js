// 引入配置
const config = require('./config/shuju.js');

Component({
  properties: {
    src: {
      type: String,
      value: ''
    }
  },

  methods: {
    onImageLoad(e) {
      this.triggerEvent('load', e.detail);
    },

    onImageError(e) {
      this.triggerEvent('error', e.detail);
    }
  }
}); 
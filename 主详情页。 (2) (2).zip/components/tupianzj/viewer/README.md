# 图片查看器组件

## 功能描述
一个优化的图片查看组件，支持多种展示比例，提供优雅的加载效果和错误处理。

## 特性
- 支持多种展示比例
  - 纵向 4:5
  - 横向 3:2
  - 经典 4:3
- 自适应容器大小
- 优化的阴影效果
- 圆角边框设计
- 懒加载支持
- 加载错误处理

## 使用方法

### 1. 引入组件
```json
{
  "usingComponents": {
    "image-viewer": "/components/image/viewer/index"
  }
}
```

### 2. 使用组件
```wxml
<image-viewer 
  src="{{imageUrl}}"
  bind:load="onImageLoad"
  bind:error="onImageError"
/>
```

### 3. 配置说明
可以通过修改 config/shuju.js 来自定义组件配置：
```javascript
const config = require('./config/shuju.js');

// 配置项说明
module.exports = {
  // 图片比例配置
  aspectRatio: {
    portrait: '4/5',    // 纵向
    landscape: '3/2',   // 横向
    classic: '4/3'      // 经典
  },
  
  // 容器样式配置
  containerStyle: {
    width: 'calc(100% - 160rpx)',
    margin: '40rpx auto',
    borderRadius: '32rpx'
  },
  
  // 其他配置...
};
```

## 属性说明
| 属性名 | 类型 | 默认值 | 说明 |
|-------|------|--------|------|
| src | String | '' | 图片地址 |

## 事件
| 事件名 | 说明 | 参数 |
|-------|------|------|
| load | 图片加载成功时触发 | event.detail |
| error | 图片加载失败时触发 | event.detail |

## 样式定制
组件提供了以下可定制的样式：
```css
/* 容器样式 */
.image-viewer-container {
  width: calc(100% - 160rpx);
  margin: 40rpx auto;
  border-radius: 32rpx;
}

/* 图片样式 */
.image-viewer {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
}
```

## 文件结构
```
components/image/viewer/
├── README.md           # 使用说明文档
├── index.js           # 组件逻辑
├── index.json         # 组件配置
├── index.wxml         # 组件模板
├── index.wxss         # 组件样式
└── config/            # 配置文件夹
    └── shuju.js       # 配置文件
```

## 引用方式
1. 组件内部引用配置：
```javascript
// 在 index.js 中
const config = require('./config/shuju.js');
```

2. 跨组件引用：
```javascript
// 在其他组件中
const imageConfig = require('/components/image/viewer/config/shuju.js');
```

## 注意事项
1. 建议使用 CDN 图片资源
2. 图片尺寸建议压缩优化
3. 建议使用 webp 格式
4. 注意处理加载失败的情况
5. 配置文件修改后需要重新编译

## 示例代码
```javascript
Page({
  data: {
    imageUrl: 'https://example.com/image.webp'
  },
  
  onImageLoad(e) {
    console.log('图片加载成功', e.detail);
  },
  
  onImageError(e) {
    console.log('图片加载失败', e.detail);
  }
});
``` 
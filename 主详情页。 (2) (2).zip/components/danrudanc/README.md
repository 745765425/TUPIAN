# 背景淡入淡出组件

## 功能描述
实现背景图片平滑过渡效果，用于页面顶部大图的切换显示。

## 特性
- 支持背景图片淡入淡出过渡
- 自动定时切换
- 可配置切换时间
- 支持自定义过渡动画时长
- 支持循环播放

## 文件结构
```
components/zhuye/lunbo/beijing/
├── README.md           # 使用说明文档
├── index.js           # 组件逻辑
├── index.json         # 组件配置
├── index.wxml         # 组件模板
├── index.wxss         # 组件样式
└── config/            # 配置文件夹
    └── shuju.js       # 配置文件
```

## 使用方法

### 1. 引入组件
```json
{
  "usingComponents": {
    "background-transition": "/components/zhuye/lunbo/beijing/index"
  }
}
```

### 2. 使用组件
```wxml
<background-transition 
  interval="3000"
  style="position: absolute; z-index: 1;"
  current-index="{{currentIndex}}"
  bind:change="onBackgroundChange"
/>
```

### 3. 配置说明
可以通过修改 config/shuju.js 来自定义组件配置：
```javascript
module.exports = {
  // 过渡动画配置
  transition: {
    duration: 2000,     // 过渡时长
    timing: 'ease-in-out'
  },
  
  // 切换间隔配置
  interval: 3000,      // 总间隔时间
  
  // 其他配置...
};
```

## 引用方式
1. 组件内部引用配置：
```javascript
// 在 index.js 中
const config = require('./config/shuju.js');
```

2. 跨组件引用：
```javascript
// 在其他组件中
const bgConfig = require('/components/zhuye/lunbo/beijing/config/shuju.js');
```

## 注意事项
1. 图片资源建议使用 CDN
2. 注意内存管理，及时释放资源
3. 建议使用 webp 格式图片
4. 配置文件修改后需要重新编译
5. 过渡时间不宜过短或过长 
Component({
  properties: {
    show: {
      type: Boolean,
      value: false,
      observer(newVal) {
        console.log('弹窗显示状态变化:', newVal);
      }
    },
    videoInfo: {
      type: Object,
      value: null,
      observer(newVal) {
        console.log('视频信息更新:', newVal);
        if (newVal) {
          this._initVideo();
        }
      }
    }
  },

  data: {
    videoContext: null,
    isFullScreen: false
  },

  lifetimes: {
    attached() {
      this._initVideo();
    },
    
    detached() {
      // 组件销毁时清理资源
      if (this.data.videoContext) {
        this.data.videoContext.stop();
      }
    }
  },

  methods: {
    _initVideo() {
      if (this.data.videoInfo) {
        // 创建视频上下文
        this.setData({
          videoContext: wx.createVideoContext('myVideo', this)
        });
      }
    },

    onMaskTap() {
      console.log('点击遮罩层，关闭弹窗');
      this.triggerEvent('close');
    },

    onVideoError(error) {
      console.log('视频播放错误:', error);
      // 可以添加错误提示或重试逻辑
    },

    preventDefault() {
      return;
    },

    onFullScreenChange(e) {
      const { fullScreen } = e.detail;
      if (fullScreen) {
        // 进入全屏时强制横屏
        this.data.videoContext.requestFullScreen({
          direction: 90  // 强制横屏
        });
      }
    }
  }
}); 
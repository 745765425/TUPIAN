// 视频播放器组件逻辑
Component({
  options: {
    styleIsolation: 'shared',
    pureDataPattern: /^_/,
    nativeMode: true
  },

  properties: {
    src: {
      type: String,
      observer(newVal) {
        if (newVal) {
          this._initVideo();
        }
      }
    },
    title: String,
    isFullScreen: {
      type: Boolean,
      value: false
    },
    isMuted: {
      type: Boolean,
      value: true
    },
    autoplay: {
      type: Boolean,
      value: true
    }
  },

  data: {
    _videoContext: null,
    _observer: null,
    _isLoading: false,
    _hasError: false,
    _retryCount: 0,
    _maxRetries: 3
  },

  lifetimes: {
    attached() {
      try {
        this._initVideo();
        this._setupObserver();
      } catch (error) {
        console.error('Video component init error:', error);
      }
    },
    
    detached() {
      this._cleanup();
    }
  },

  pageLifetimes: {
    show() {
      if (this._wasPlaying) {
        this.data._videoContext?.play();
      }
    },
    hide() {
      this._wasPlaying = !this.data.isMuted;
      this.data._videoContext?.pause();
    }
  },

  methods: {
    _initVideo() {
      try {
        this.data._videoContext = wx.createVideoContext('myVideo', this);
        this.setData({ _hasError: false });
      } catch (error) {
        console.error('Video context init error:', error);
        this.setData({ _hasError: true });
      }
    },

    _setupObserver() {
      try {
        this.data._observer = wx.createIntersectionObserver(this, {
          thresholds: [0, 0.5],
          observeAll: true
        });
      
        this.data._observer.observe('.video-container', (res) => {
          if (res.intersectionRatio <= 0) {
            this._pauseVideo();
          } else if (this.data.autoplay && !this.data._hasError) {
            this._playVideo();
          }
        });
      } catch (error) {
        console.error('Observer setup error:', error);
      }
    },

    _cleanup() {
      try {
        if (this.data._observer) {
          this.data._observer.disconnect();
          this.data._observer = null;
        }
        if (this.data._videoContext) {
          this.data._videoContext.pause();
          this.data._videoContext = null;
        }
      } catch (error) {
        console.error('Cleanup error:', error);
      }
    },

    _playVideo() {
      try {
        this.data._videoContext?.play();
      } catch (error) {
        console.error('Play video error:', error);
      }
    },

    _pauseVideo() {
      try {
        this.data._videoContext?.pause();
      } catch (error) {
        console.error('Pause video error:', error);
      }
    },

    onFirstFrame() {
      this.triggerEvent('firstframe');
    },

    onVideoWaiting() {
      this.setData({ _isLoading: true });
      this.triggerEvent('waiting');
    },

    onVideoProgress() {
      this.setData({ _isLoading: false });
      this.triggerEvent('progress');
    },

    onVideoError(error) {
      console.error('Video error:', error);
      this.setData({ _hasError: true });
      
      if (this.data._retryCount < this.data._maxRetries) {
        this.data._retryCount++;
        setTimeout(() => {
          this._initVideo();
        }, 1000);
      }
      
      this.triggerEvent('error', error);
    },

    onVideoTap() {
      try {
        if (!this.data.isFullScreen) {
          this.setData({ isFullScreen: true }, () => {
            this.data._videoContext?.requestFullScreen({ direction: 0 });
          });
        } else {
          this.data._videoContext?.exitFullScreen();
        }
      } catch (error) {
        console.error('Video tap error:', error);
      }
    },

    onVolumeTap() {
      try {
        this.setData({ isMuted: !this.data.isMuted });
      } catch (error) {
        console.error('Volume tap error:', error);
      }
    },

    onFullScreenChange(e) {
      this.setData({ 
        isFullScreen: e.detail.fullScreen,
        isMuted: !e.detail.fullScreen
      });
    }
  }
}); 
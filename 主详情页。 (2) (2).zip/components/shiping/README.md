# 视频播放器组件

## 功能描述
一个自定义的视频播放器组件，支持全屏播放、音量控制、自动播放等功能。

## 特性
- 支持全屏/非全屏切换
- 自定义音量控制
- 自动播放/循环播放
- 手势控制进度
- 自适应视频尺寸
- 支持进度条显示
- 优化的全屏模式UI

## 使用方法

### 1. 引入组件
```json
{
  "usingComponents": {
    "video-player": "/components/video-player/video-player"
  }
}
```

### 2. 使用组件
```wxml
<video-player 
  src="{{videoUrl}}"
  title="视频标题"
  isFullScreen="{{false}}"
  isMuted="{{true}}"
/>
```

## 属性说明
| 属性名 | 类型 | 默认值 | 说明 |
|-------|------|--------|------|
| src | String | - | 视频源地址 |
| title | String | - | 视频标题 |
| isFullScreen | Boolean | false | 是否全屏显示 |
| isMuted | Boolean | true | 是否静音 |

## 事件
| 事件名 | 说明 | 参数 |
|-------|------|------|
| onVideoLoaded | 视频加载完成时触发 | event |
| onVideoError | 视频加载错误时触发 | error |
| onVideoStateChange | 视频播放状态改变时触发 | {playing: Boolean} |
| onFullScreenChange | 全屏状态改变时触发 | {fullScreen: Boolean} |

## 样式定制
组件提供了丰富的样式定制选项：
```css
/* 容器样式 */
.video-container {
  /* 自定义样式 */
}

/* 视频样式 */
.video {
  /* 自定义样式 */
}

/* 全屏模式样式 */
.video.fullscreen {
  /* 自定义样式 */
}
```

## 配置说明
可以通过 config/shuju.js 修改默认配置：
```javascript
// 视频基础配置
videoProps: {
  muted: true,
  objectFit: "cover",
  autoplay: true,
  // ... 其他配置
}
```

## 注意事项
1. 建议视频资源使用 CDN 加速
2. 注意控制视频文件大小
3. 建议使用 mp4 格式
4. 需要处理网络状态变化
5. 注意内存管理，及时释放资源

## 示例代码
```wxml
<!-- 页面中使用 -->
<video-player 
  src="https://example.com/video.mp4"
  title="示例视频"
  isFullScreen="{{false}}"
  isMuted="{{true}}"
/>
```

```javascript
Page({
  data: {
    videoUrl: 'https://example.com/video.mp4'
  },
  
  onVideoStateChange(e) {
    console.log('视频状态改变：', e.detail.playing);
  },
  
  onFullScreenChange(e) {
    console.log('全屏状态改变：', e.detail.fullScreen);
  }
});
``` 
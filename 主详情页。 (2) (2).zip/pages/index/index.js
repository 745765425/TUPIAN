// index.js
const { launchConfig, courseConfig } = require('../../utils/config.js');
const zhuyeConfig = require('../../config/zhuye/config.js');

Page({
  data: {
    currentIndex: 0,
    topIndex: 0,
    showLaunch: true,
    launchOpacity: 1,
    courseList: [],  // 初始为空
    launchAnimation: null,
    topSlides: zhuyeConfig.topSlides,
    zhuyeConfig: zhuyeConfig,
    activeIcon: '',  // 当前激活的图标
    iconTapLock: false,  // 防止重复点击
    showVideoPopup: false,
    currentVideo: null
  },

  onLoad(options) {
    try {
      // 延迟加载非必要数据
      wx.nextTick(() => {
        this.setData({
          launchImages: launchConfig.launchImages,
          animationConfig: launchConfig.animation,
          styleConfig: launchConfig.style
        });
      });

      // 检查是否需要跳过启动页
      if (options.skip_launch === 'true' || options.showLaunch === 'false') {
        this.setData({
          showLaunch: false
        });
      }

      // 只保留一次数据加载
      const { courseConfig } = require('../../utils/config.js');
      console.log('加载配置数据:', courseConfig.list);
      
      // 直接设置数据，不使用 updateCourseList
      this.setData({
        courseList: courseConfig.list.map((item, index) => ({
          id: index + 1,
          number: String(index + 1),
          bgColor: item.bgColor || '#4DC591',
          text: item.text,
          video: item.video
        }))
      }, () => {
        console.log('列表数据已设置:', this.data.courseList);
        // 特别检查第一项
        console.log('第一项数据(index 0):', this.data.courseList[0]);
      });

      // 预加载详情页资源
      this.preloadDetailPage();
    } catch (error) {
      console.error('onLoad error:', error);
    }
  },

  onShow() {
    // 恢复这段代码，确保页面显示时重置视频状态
    this.setData({
      showVideoPopup: false,
      currentVideo: null
    });
    
    this._initList();
  },

  _initList() {
    const { courseConfig } = require('../../utils/config.js');
    
    this.setData({
      courseList: courseConfig.list.map((item, index) => ({
        id: index + 1,
        number: String(index + 1),
        bgColor: item.bgColor || '#4DC591',
        text: item.text,
        video: item.video,
        _ready: true  // 添加一个准备状态标记
      }))
    }, () => {
      console.log('列表重新初始化完成');
    });
  },

  // 背景切换事件处理
  onBackgroundChange(e) {
    this.setData({
      currentIndex: e.detail.current
    });
  },

  // 顶部组件切换事件处理
  onTopChange(e) {
    this.setData({
      topIndex: e.detail.current
    });
  },

  // 触摸事件处理
  handleTouchStart() {
    // 创建动画实例
    const animation = wx.createAnimation({
      duration: 1200,  // 增加动画时间
      timingFunction: 'ease-out',
      delay: 0
    });
    
    // 设置渐隐动画
    animation.opacity(0).step();
    
    // 先开始动画
    this.setData({
      launchAnimation: animation.export()
    });

    // 等动画完成后再隐藏
    setTimeout(() => {
      this.setData({
        showLaunch: false
      });
    }, 1200);  // 与动画时间一致
  },

  handleIconTap(e) {
    if (this.iconTapLock) return; // 防止重复点击
    this.iconTapLock = true;
    
    const icon = e.currentTarget.dataset.icon;
    if (this.data.activeIcon) return;
    
    this.setData({ activeIcon: icon });
    
    wx.nextTick(() => {
      setTimeout(() => {
        this.setData({ activeIcon: '' });
        if (icon === 'product') {
          wx.navigateTo({
            url: '/pages/detail/index'
          });
        }
        this.iconTapLock = false; // 解锁点击
      }, 200);
    });
  },

  preloadDetailPage() {
    // 预加载详情页需要的图片等资源
    const preloadImages = [
      'https://cdn.jsdelivr.net/gh/745765425/TUPIAN/2.png'
    ];
    
    Promise.all(preloadImages.map(url => {
      return new Promise((resolve, reject) => {
        wx.getImageInfo({
          src: url,
          success: (res) => resolve(res),
          fail: (err) => reject(err)
        });
      });
    }))
    .then(() => {
      console.log('All images preloaded successfully');
    })
    .catch(error => {
      console.error('Image preload failed:', error);
    });
  },

  onHide() {
    // 页面隐藏时关闭视频
    this.setData({
      showVideoPopup: false,
      currentVideo: null,
      launchImages: null,
      animationConfig: null,
      styleConfig: null
    });
  },

  handleItemClick(e) {
    const { index } = e.currentTarget.dataset;
    const item = this.data.courseList[index];
    
    if (!item || !item.video) {
      console.error('视频数据不存在');
      return;
    }
    
    // 设置视频数据
    const videoInfo = {
      videoUrl: item.video.url,
      title: item.video.title || item.text,
      subtitle: item.video.subtitle || '',
      description: item.video.description || '',
      popupColor: item.video.popupColor || '#FFFFFF'
    };
    
    console.log('准备显示弹窗，视频信息:', videoInfo);
    
    // 先设置数据，再显示弹窗
    this.setData({
      currentVideo: videoInfo,
      showVideoPopup: true
    });
  },

  onVideoPopupClose() {
    this.setData({
      showVideoPopup: false,
      currentVideo: null
    });
  },

  // 添加一个全局点击处理
  onPageTap() {
    if (this.data.showVideoPopup) {
      this.setData({
        showVideoPopup: false,
        currentVideo: null
      });
    }
  }
});

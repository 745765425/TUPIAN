const { videoConfig } = require('../../config/zhuye/config.js')

Page({
  data: {
    title: '专业美甲设计',
    titleWidth: 0,
    cardColor: '#4DC591',  // 默认颜色
    validColor: true,      // 颜色是否有效
    colorHint: '使用默认颜色 #4DC591',  // 颜色提示文字
    videoConfig
  },

  onLoad() {
    // 加载已保存的配置
    const config = wx.getStorageSync('pageConfig') || {}
    this.setData({
      title: config.title || '专业美甲设计',
      cardColor: config.cardColor || '#4DC591'
    })
    this.updateTitleWidth(this.data.title)
    this.validateColor(this.data.cardColor)
  },

  onReady() {
    this.updateTitleWidth(this.data.title)
  },

  handleTitleInput(e) {
    const text = e.detail.value
    this.setData({ title: text })
    this.updateTitleWidth(text)
  },

  updateTitleWidth(text) {
    // 使用 canvas 计算文字宽度
    const ctx = wx.createCanvasContext('measureText')
    ctx.setFontSize(32)  // 与文字大小一致
    ctx.measureText(text).then(res => {
      this.setData({
        titleWidth: res.width + 64  // 文字宽度 + padding
      })
    })
  },

  // 处理颜色输入
  handleColorInput(e) {
    const color = e.detail.value
    this.setData({ cardColor: color })
    this.validateColor(color)
  },

  // 验证颜色代码
  validateColor(color) {
    const isValid = /^#[0-9A-F]{6}$/i.test(color)
    this.setData({
      validColor: isValid
    })
  },

  // 保存配置
  saveConfig() {
    const config = {
      title: this.data.title,
      cardColor: this.data.validColor ? this.data.cardColor : '#4DC591'
    }
    wx.setStorageSync('pageConfig', config)
    wx.showToast({
      title: '保存成功',
      icon: 'success'
    })
  }
}) 
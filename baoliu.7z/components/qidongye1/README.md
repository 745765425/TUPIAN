# 启动页组件

## 使用方法

1. 复制整个 components/qidongye1 文件夹到你的项目中
2. 复制 config/qidongye 文件夹到你的项目中
3. 在页面的 json 文件中引入组件:
```json
{
  "usingComponents": {
    "qidongye1": "/components/qidongye1/index"
  }
}
```

4. 在页面中使用组件:
```html
<qidongye1 wx:if="{{showLaunch}}" />
```

## 组件说明

- 组件会自动执行三张图片的淡入淡出动画
- 动画时序:
  - 第一张图片(0ms): 直接显示并开始2.5秒淡出
  - 第二张图片(900ms): 开始1.5秒淡入
  - 第三张图片(2500ms): 开始1.5秒淡入

## 配置说明

图片和动画配置在 config/qidongye/images.js 中:
```javascript
module.exports = {
  launchImages: [
    {
      id: 'launch1',
      url: '图片1地址'
    },
    {
      id: 'launch2',
      url: '图片2地址'
    },
    {
      id: 'launch3',
      url: '图片3地址'
    }
  ],
  animation: {
    duration: 1200,
    timingFunction: 'ease-out',
    delay: 0
  }
};
``` 
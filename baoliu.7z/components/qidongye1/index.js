Component({
  options: {
    pureDataPattern: /^_/, // 优化数据更新性能
    styleIsolation: 'shared', // 优化样式性能
  },

  properties: {
    interval: {
      type: Number,
      value: 3000  // 这里是轮播间隔时间，现在是3秒
    },
    currentIndex: {
      type: Number,
      value: 0
    },
    type: {
      type: String,
      value: 'launch' // 'launch' 或 'main'
    }
  },

  data: {
    backgroundImages: [
      'cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/static/qidongye1.svg',
      'cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/static/qidongye2.webp',
      'cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/static/qidongye3.webp',
      'cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/static/qidongye4.svg'
    ],
    activeIndex: 0,
    _observer: null, // pure data
    screenHeight: 0,
    firstImageShown: true,
    secondImageShown: false,
    thirdImageShown: false,
    fourthImageShown: false,  // 添加第四张图片状态
    canTap: false,  // 添加标记控制是否可以点击
    fadeOut: false,
    _animationStarted: false
  },

  lifetimes: {
    attached() {
      // 获取设备屏幕信息
      this.setData({
        screenHeight: wx.getSystemInfoSync().windowHeight
      });

      // 添加标记防止重复触发
      this._animationStarted = false;

      // 检查app.js中的预加载状态
      const app = getApp();
      console.log('启动页组件初始化，检查预加载状态:', app.globalData.launchImagesPreloaded);
      
      if (app.globalData.launchImagesPreloaded) {
        console.log('图片已预加载完成，直接开始动画');
        // 图片已预加载，直接开始动画
        this.startAnimation();
      } else {
        console.log('图片尚未预加载完成，等待预加载');
        // 图片尚未预加载完成，监听状态变化
        const checkInterval = setInterval(() => {
          if (app.globalData.launchImagesPreloaded) {
            console.log('检测到图片预加载完成，开始动画');
            clearInterval(checkInterval);
            this.startAnimation();
          }
        }, 100);
        
        // 设置超时，避免无限等待
        setTimeout(() => {
          console.log('预加载等待超时，强制开始动画');
          clearInterval(checkInterval);
          this.startAnimation();
        }, 2000);
      }
    },
    detached() {
      this.stopTransition();   // 组件卸载时停止轮换
    }
  },

  methods: {
    startNormalTransition() {
      // 恢复正常的过渡时间
      this.setData({ fastTransition: false });
      
      // 从第二张图开始正常轮播
      if (this.intervalId) {
        clearInterval(this.intervalId);
      }
      
      this.intervalId = setInterval(() => {
        const nextIndex = (this.data.activeIndex + 1) % this.data.backgroundImages.length;
        this.setData({ activeIndex: nextIndex });
      }, 3000);  // 后续图片保持3秒间隔
    },

    stopTransition() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    },

    // 添加点击事件处理
    handleTap() {
      // 只有在允许点击时才响应
      if (!this.data.canTap) {
        return;
      }
      
      // 先添加淡出样式
      this.setData({
        fadeOut: true
      });
      
      // 等待动画完成后再触发关闭事件
      setTimeout(() => {
        this.triggerEvent('close');
      }, 800);  // 与 CSS 动画时间一致
    },

    onImageError(e) {
      const index = e.currentTarget.dataset.index || '未知';
      const src = e.currentTarget.dataset.src || '未知';
      console.error('图片加载失败:', {
        index: index,
        src: src,
        imageType: src.split('.').pop(),
        errorDetail: e.detail,
        timestamp: new Date().getTime(),
        fullPath: src,
        isLocalPath: src.startsWith('/'),
        platform: wx.getSystemInfoSync().platform,
        environment: __wxConfig.envVersion || '未知'
      });
      
      // 尝试加载备用图片
      if (src.endsWith('.webp')) {
        // 如果是webp格式失败，使用第一张SVG作为备用
        const backupSrc = 'cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/static/qidongye1.svg';
        this.setData({
          [`backgroundImages[${index}]`]: backupSrc
        });
      }
    },
    
    onImageLoad(e) {
      const index = e.currentTarget.dataset.index || '未知';
      const src = e.currentTarget.dataset.src || '未知';
      console.log('图片加载成功:', {
        index: index,
        src: src,
        imageType: src.split('.').pop(),
        timestamp: new Date().getTime()
      });
    },

    startAnimation() {
      // 防止重复触发
      if (this._animationStarted) {
        console.log('动画已经开始，忽略重复调用');
        return;
      }
      this._animationStarted = true;
      
      // 重置状态
      this.setData({
        activeIndex: 0,
        firstImageShown: true,
        secondImageShown: true,
        thirdImageShown: true,
        fourthImageShown: false,
        canTap: false
      });
      
      // 第四张图片从2.5秒开始，4秒完全显示
      setTimeout(() => {
        console.log('准备显示第四张图片');
        this.setData({
          activeIndex: 3,
          fourthImageShown: true
        });
        console.log('第四张图片状态更新完成');
      }, 2500);

      // 4秒后检查最终状态
      setTimeout(() => {
        console.log('动画完成后最终状态:', {
          activeIndex: this.data.activeIndex,
          firstShown: this.data.firstImageShown,
          secondShown: this.data.secondImageShown,
          thirdShown: this.data.thirdImageShown,
          fourthShown: this.data.fourthImageShown
        });
        this.stopTransition();
        this.setData({
          canTap: true
        });
      }, 4000);
    }
  }
}); 
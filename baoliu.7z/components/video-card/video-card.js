Component({
  options: {
    multipleSlots: true // 启用多slot支持
  },
  /**
   * 组件的属性列表
   */
  properties: {
    videoInfo: {
      type: Object,
      value: {}
    },
    extClass: {
      type: String,
      value: ''
    },
    borderRadius: {
      type: String,
      value: '12px'
    },
    // 修改属性：是否在视口中心
    isInViewCenter: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        if (!this.videoContext) {
          this.videoContext = wx.createVideoContext(`video-${this.data.videoInfo.id}`, this);
        }
        
        // 防止快速切换视图时的播放/暂停冲突
        if (this._viewChangeTimer) {
          clearTimeout(this._viewChangeTimer);
        }
        
        // 使用延时处理视图变化，避免快速切换导致的冲突
        this._viewChangeTimer = setTimeout(() => {
          if (newVal) {
            // 使用我们的播放方法，它包含了Promise处理
            this.playVideo();
          } else {
            // 使用我们的暂停方法，它包含了Promise处理
            this.pauseVideo();
          }
        }, 50);
      }
    },
    isDetailShow: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        if (newVal) {
          // 详情页打开时，只暂停视频，保持可见性
          this.pauseVideo();
          if (this.playTimer) {
            clearTimeout(this.playTimer);
            this.playTimer = null;
          }
        }
      }
    },
    autoPlayDisabled: {
      type: Boolean,
      value: false
    },
    preventAutoPlay: {
      type: Boolean,
      value: true  // 默认阻止自动播放
    },
    isInView: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        // 防止快速滚动时的播放/暂停冲突
        if (this._inViewTimer) {
          clearTimeout(this._inViewTimer);
        }
        
        this._inViewTimer = setTimeout(() => {
          if (newVal) {
            this.autoPlayVideo();
          } else {
            this.pauseVideo();
          }
        }, 100);
      }
    },
    isFirstVideo: {
      type: Boolean,
      value: false
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    isPlaying: false,
    showControls: false,
    videoContext: null,
    keepVideoVisible: false, // 新增状态，表示保持视频可见
    isMuted: true, // 默认静音
    posterVideoContext: null, // 新增属性，用于存储封面视频上下文
    showReplayButton: false,  // 添加重播按钮显示状态
    playTimer: null,  // 添加播放定时器
    windowHeight: 0,
    isPlayingVideo: false,
    _isPlaying: false,
    _isPlayRequested: false,
    _playPromise: null
  },
  lifetimes: {
    attached() {
      if (!this.videoContext) {
        this.videoContext = wx.createVideoContext(`video-${this.data.videoInfo.id}`, this);
      }
      
      try {
        const windowInfo = wx.getWindowInfo();
        this.setData({
          windowHeight: windowInfo.windowHeight
        });
      } catch (error) {
        console.error('获取窗口信息失败:', error);
      }
    },
    detached() {
      if (this.videoContext) {
        this.videoContext.pause();
      }
      
      if (this.playTimer) {
        clearTimeout(this.playTimer);
        this.playTimer = null;
      }
      
      // 清理所有定时器
      if (this._viewChangeTimer) {
        clearTimeout(this._viewChangeTimer);
        this._viewChangeTimer = null;
      }
      
      if (this._inViewTimer) {
        clearTimeout(this._inViewTimer);
        this._inViewTimer = null;
      }
      
      if (this._autoPlayTimer) {
        clearTimeout(this._autoPlayTimer);
        this._autoPlayTimer = null;
      }
      
      // 组件销毁时，确保清理所有状态和操作
      this._isPlaying = false;
      this._isPlayRequested = false;
      this._playPromise = null;
      
      // 尝试暂停视频，避免潜在的播放状态残留
      try {
        const videoContext = wx.createVideoContext('video_' + this.data.videoInfo.id, this);
        if (videoContext) {
          videoContext.pause();
        }
      } catch (e) {
        console.log('视频组件销毁时暂停视频失败', e);
      }
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    // 播放视频
    playVideo() {
      if (this._playPromise) return;
      
      if (!this.videoContext) {
        this.videoContext = wx.createVideoContext(`video-${this.data.videoInfo.id}`, this);
      }
      
      if (this.videoContext) {
        this._playPromise = new Promise((resolve) => {
          this.videoContext.play();
          setTimeout(() => {
            this._isPlaying = true;
            this._isPlayRequested = false;
            resolve();
            this._playPromise = null;
          }, 300);
        });
      }
    },
    
    // 暂停视频
    pauseVideo() {
      if (this._playPromise) {
        this._playPromise.then(() => {
          this._doPause();
        });
      } else {
        this._doPause();
      }
    },
    
    // 实际执行暂停的方法
    _doPause() {
      if (!this._isPlaying && !this._isPlayRequested) return;
      
      if (!this.isPlayingVideo) return;
      this.isPlayingVideo = false;

      if (this.videoContext && this.data.isPlaying) {
        this.videoContext.pause();
        this.setData({
          isPlaying: false,
          keepVideoVisible: true
        });
        this._isPlaying = false;
        this._isPlayRequested = false;
      }
    },
    
    // 视频播放结束
    videoEnd() {
      this.isPlayingVideo = false;
      this.setData({
        isPlaying: false,
        keepVideoVisible: true,
        showReplayButton: true
      });
      // 触发结束事件
      this.triggerEvent('videoend');
    },
    
    // 点击视频卡片
    onTap() {
      // 点击时立即暂停当前视频
      if (this.data.isPlaying) {
        this.pauseVideo();
      }
      
      // 触发卡片点击事件
      this.onCardTap();
    },
    
    // 修改showMore方法为分享功能
    showMore() {
      // 触发自定义分享事件，传递当前视频信息
      this.triggerEvent('share', { 
        videoId: this.data.videoInfo.id,
        title: this.data.videoInfo.title,
        imageUrl: this.data.videoInfo.coverUrl,
        path: `/pages/video-detail/video-detail?id=${this.data.videoInfo.id}`
      });
    },
    
    // 修改切换静音状态的方法
    toggleMute(e) {
      // 检查事件对象是否存在并有stopPropagation方法
      if (e && typeof e.stopPropagation === 'function') {
        // 阻止事件冒泡，避免触发视频的点击事件
        e.stopPropagation();
      }
      
      // 切换静音状态
      const newMuteState = !this.data.isMuted;
      
      // 更新状态
      this.setData({
        isMuted: newMuteState
      }, () => {
      });
    },
    
    // 修改 onCardTap 方法
    onCardTap() {
      this.triggerEvent('cardtap', { 
        videoId: this.data.videoInfo.id 
      });
    },
    
    // 修改重播方法
    replayVideo() {
      console.log('重播按钮被点击');

      // 先创建视频上下文
      this.videoContext = wx.createVideoContext('video-' + this.data.videoInfo.id, this);
      
      // 重置状态并重新播放
      this.setData({
        isPlaying: true,
        showReplayButton: false,
        keepVideoVisible: true
      }, () => {
        this.videoContext.seek(0);
        setTimeout(() => {
          this.videoContext.play();
        }, 100);
      });
    },
    
    // 修改视频错误处理
    onVideoError(error) {
      console.error('视频播放错误:', error);
      this.triggerEvent('videoError', { error });
    },
    
    // 添加处理云文件的方法
    async getVideoUrl(fileID) {
      try {
        const { fileList } = await wx.cloud.getTempFileURL({
          fileList: [fileID]
        })
        return fileList[0].tempFileURL
      } catch (err) {
        console.error('获取视频链接失败:', err)
        return ''
      }
    },
    
    // 添加自动播放方法
    autoPlayVideo() {
      // 如果禁用了自动播放或设置了阻止自动播放，则不执行
      if (this.data.autoPlayDisabled || this.data.preventAutoPlay) {
        return;
      }
      
      // 延迟播放，避免过早触发
      if (this._autoPlayTimer) {
        clearTimeout(this._autoPlayTimer);
      }
      
      this._autoPlayTimer = setTimeout(() => {
        this.playVideo();
      }, 200);
    }
  }
}) 
Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    }
  },

  methods: {
    handleWechat() {
      console.log('点击了添加微信');
      wx.previewImage({
        urls: ['https://6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805.tcb.qcloud.la/static/qrcode..webp?sign=76b7496ccd7df161e0d31da777657aae&t=1742499006'],
        longPressActions: {
          itemList: ['添加好友'],
          itemColor: '#000000',
          success: (res) => {
            console.log('用户选择了：', res.tapIndex);
            if (res.tapIndex === 0) {
              wx.scanCode({
                scanType: ['qrCode'],
                success: (res) => {
                  console.log('识别成功：', res);
                }
              });
            }
          }
        },
        success: () => {
          console.log('预览图片成功');
        },
        fail: (err) => {
          console.error('预览图片失败:', err);
        }
      });
      this.handleClose();
    },

    handlePhone() {
      this.triggerEvent('showconfirm', {
        title: '拨打电话',
        content: '是否拨打电话 19925762035？',
        type: 'phone'
      });
    },

    handleClose() {
      this.triggerEvent('close');
    },

    // 阻止冒泡
    preventBubble() {}
  }
}); 
Page({
  data: {
    loaded: false
  },
  onLoad: function() {
    // 这个页面只用于预加载，实际不会显示
    const app = getApp();
    console.log('启动页面加载，预加载状态:', app.globalData.launchImagesPreloaded);
    
    if (app.globalData.launchImagesPreloaded) {
      console.log('图片已预加载完成，直接跳转到主页');
      wx.switchTab({
        url: '/pages/index/index'
      });
    } else {
      console.log('等待图片预加载完成');
      // 等待预加载完成
      const checkInterval = setInterval(() => {
        if (app.globalData.launchImagesPreloaded) {
          console.log('检测到图片预加载完成，跳转到主页');
          clearInterval(checkInterval);
          wx.switchTab({
            url: '/pages/index/index'
          });
        }
      }, 100);
      
      // 设置超时，避免无限等待
      setTimeout(() => {
        console.log('预加载等待超时，强制跳转到主页');
        clearInterval(checkInterval);
        wx.switchTab({
          url: '/pages/index/index'
        });
      }, 3000);
    }
  }
}) 
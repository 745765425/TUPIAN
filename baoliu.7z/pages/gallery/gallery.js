// pages/gallery/gallery.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    galleryItems: [],
    isLoading: false,
    showPreview: false,
    previewImage: null,
    headerState: {
      opacity: 1
    },
    galleryUrls: [],  // 添加这个数组来存储所有图片URL
    navBarBgImage: '/static/daohanglan.svg'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    // 检查是否有预加载的数据
    if (app.globalData.gallery?.isComplete) {
      // 使用预加载的数据
      const fileList = app.globalData.gallery.data;
      this.processGalleryData(fileList);
    } else {
      // 如果没有预加载数据,则正常加载
      this.loadGalleryImagesFromStorage();
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    wx.hideTabBar();
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 1
      });
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.refreshGallery();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    if (!this.data.isLoading) {
      this.loadGalleryImagesFromStorage(true);
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
  },

  // 优化的滚动事件处理
  onScrollEvent(e) {
    wx.nextTick(() => {
      const scrollTop = e.detail.scrollTop;
      const opacity = Math.max(0, 1 - (scrollTop / 150));
      this.setData({ 
        'headerState.opacity': opacity
      });
    });
  },

  // 优化的图片加载方法
  async loadGalleryImagesFromStorage() {
    if (this.data.isLoading) return;
    
    this.setData({ isLoading: true });
    
    try {
      console.log('开始调用云函数');
      const res = await wx.cloud.callFunction({
        name: 'getGalleryFiles'
      });

      console.log('云函数返回数据:', res);
      console.log('文件列表:', res.result.result.fileList);

      if (!res.result || !res.result.result) {
        throw new Error('云函数返回数据格式错误');
      }

      if (res.result.result.success && Array.isArray(res.result.result.fileList) && res.result.result.fileList.length > 0) {
        const imagePromises = res.result.result.fileList.map((file, index) => {
          return new Promise((resolve) => {
            // 开发者工具中直接使用 URL
            if (wx.getSystemInfoSync().platform === 'devtools') {
              resolve({
                _id: index.toString(),
                title: file.key,
                imageUrl: file.tempFileURL,
                isVertical: false  // 在开发者工具中默认为横向
              });
            } else {
              // 手机端继续使用 getImageInfo
              wx.getImageInfo({
                src: file.tempFileURL,
                success: (imgInfo) => {
                  resolve({
                    _id: index.toString(),
                    title: file.key,
                    imageUrl: file.tempFileURL,
                    isVertical: imgInfo.height > imgInfo.width
                  });
                },
                fail: (error) => {
                  console.error('获取图片信息失败:', error);
                  resolve(null);
                }
              });
            }
          });
        });

        const newItems = await Promise.all(imagePromises);
        const validItems = newItems.filter(item => item !== null);
        
        this.setData({
          galleryItems: validItems,
          galleryUrls: validItems.map(item => item.imageUrl),
          isLoading: false
        });
      } else {
        console.log('云函数返回数据详情:', JSON.stringify(res.result));
        wx.showToast({
          title: '暂无图片',
          icon: 'none'
        });
      }
    } catch (err) {
      console.error('获取云存储文件失败:', err);
      wx.showToast({
        title: '加载失败: ' + (err.message || '未知错误'),
        icon: 'none'
      });
    } finally {
      this.setData({ isLoading: false });
    }
  },

  // 图片预览相关
  handleImageTap(e) {
    const item = e.currentTarget.dataset.item;
    
    // 禁用页面滚动
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 0
    });
    
    this.setData({
      showPreview: true,
      previewImage: item
    });
  },

  closePreview() {
    this.setData({
      showPreview: false
    });
  },

  // 新的刷新方法
  async refreshGallery() {
    try {
      await this.loadGalleryImagesFromStorage();
      wx.stopPullDownRefresh();
    } catch (err) {
      console.error('刷新失败:', err);
      wx.stopPullDownRefresh();
    }
  },

  // 添加处理数据的方法
  async processGalleryData(fileList) {
    const imagePromises = fileList.map((file, index) => {
      return new Promise((resolve) => {
        if (wx.getSystemInfoSync().platform === 'devtools') {
          resolve({
            _id: index.toString(),
            title: file.key,
            imageUrl: file.tempFileURL,
            isVertical: false
          });
        } else {
          wx.getImageInfo({
            src: file.tempFileURL,
            success: (imgInfo) => {
              resolve({
                _id: index.toString(),
                title: file.key,
                imageUrl: file.tempFileURL,
                isVertical: imgInfo.height > imgInfo.width
              });
            },
            fail: (error) => {
              console.error('获取图片信息失败:', error);
              resolve(null);
            }
          });
        }
      });
    });

    const newItems = await Promise.all(imagePromises);
    const validItems = newItems.filter(item => item !== null);
    
    this.setData({
      galleryItems: validItems,
      galleryUrls: validItems.map(item => item.imageUrl)
    });
  }
})
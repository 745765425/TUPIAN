const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

exports.main = async (event, context) => {
  try {
    console.log('开始获取文件列表');

    // 构造文件ID列表
    const fileIDs = [];
    for(let i = 1; i <= 8; i++) {
      fileIDs.push(`cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/gallery/naildidi.com(${i}).webp`);
    }

    console.log('准备获取的文件列表:', fileIDs);

    // 获取临时访问链接
    const result = await cloud.getTempFileURL({
      fileList: fileIDs
    });

    console.log('获取到的临时链接:', result.fileList);

    if (!result.fileList) {
      throw new Error('获取文件列表失败');
    }

    // 处理文件列表
    const processedFileList = result.fileList
      .filter(file => file.status === 0) // 只处理成功的文件
      .sort((a, b) => {
        const getNumber = (filename) => {
          const match = filename.match(/\((\d+)\)/);
          return match ? parseInt(match[1]) : 0;
        };
        const fileNameA = a.fileID.split('/').pop();
        const fileNameB = b.fileID.split('/').pop();
        return getNumber(fileNameA) - getNumber(fileNameB);
      })
      .map(file => {
        const filename = file.fileID.split('/').pop();
        return {
          key: filename,
          tempFileURL: file.tempFileURL
        };
      });

    console.log('最终处理的文件列表:', processedFileList);

    return {
      result: {
        success: true,
        fileList: processedFileList
      }
    };

  } catch (err) {
    console.error('云函数执行错误:', err);
    return {
      result: {
        success: false,
        error: err.message || '获取文件列表失败'
      }
    };
  }
}; 
# 微信小程序云开发图片瀑布流实现文档

> 记录时间：2025-03-22
> 问题类型：云函数部署与图片获取
> 环境：微信小程序云开发

## 问题描述
在重新部署云函数后，无法获取云存储中的图片列表，主要涉及云函数的配置和调用问题。

## 解决方案

### 1. 云函数配置
#### 1.1 目录结构

bash
cloudfunctions/
└── getGalleryFiles/
├── index.js
└── package.json
  
#### 1.2 云函数代码 (index.js)
javascript
const cloud = require('wx-server-sdk')
cloud.init({
env: cloud.DYNAMIC_CURRENT_ENV
})
exports.main = async (event, context) => {
try {
console.log('开始获取文件列表');
// 构造文件ID列表
const fileIDs = [];
for(let i = 1; i <= 8; i++) {
fileIDs.push(cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/gallery/naildidi.com(${i}).webp);
}
console.log('准备获取的文件列表:', fileIDs);
// 获取临时访问链接
const result = await cloud.getTempFileURL({
fileList: fileIDs
});
// 处理文件列表
const processedFileList = result.fileList
.filter(file => file.status === 0)
.sort((a, b) => {
const getNumber = (filename) => {
const match = filename.match(/
(
\d
+
)
(\d+)/);
return match ? parseInt(match[1]) : 0;
};
const fileNameA = a.fileID.split('/').pop();
const fileNameB = b.fileID.split('/').pop();
return getNumber(fileNameA) - getNumber(fileNameB);
})
.map(file => {
const filename = file.fileID.split('/').pop();
return {
key: filename,
tempFileURL: file.tempFileURL
};
});
return {
result: {
success: true,
fileList: processedFileList
}
};
} catch (err) {
console.error('云函数执行错误:', err);
return {
result: {
success: false,
error: err.message || '获取文件列表失败'
}
};
}
};

#### 1.3 package.json 配置
json
{
"name": "getGalleryFiles",
"version": "1.0.0",
"description": "",
"main": "index.js",
"scripts": {
"test": "echo \"Error: no test specified\" && exit 1"
},
"author": "",
"license": "ISC",
"dependencies": {
"wx-server-sdk": "~2.6.3"
}
}

### 2. 特别注意事项（易被忽略的重点）

1. **云函数中的关键区别**
   - ❌ 不能使用 `wx` 对象
   - ✅ 必须使用 `cloud` 对象
   - 这是最容易出错的地方

2. **数据结构层级**
   ```javascript
   // 云函数返回的数据结构
   {
     result: {  // 第一层 result
       result: {  // 第二层 result
         success: true,
         fileList: [...] // 实际数据
       }
     }
   }
   ```
   - 前端访问时要使用 `res.result.result.fileList`
   - 很多人只写一层 result 就出错了

3. **文件路径问题**
   - 必须使用完整的云文件ID
   - 包含环境ID和完整路径
   - 示例：`cloud://环境ID.文件路径`

4. **重新部署注意事项**
   - 删除云函数时要先备份代码
   - 重新部署时要检查权限设置
   - 确保环境ID正确配置

### 3. 故障排查步骤

1. **云函数日志检查**
   ```javascript
   console.log('准备获取的文件列表:', fileIDs);
   console.log('获取到的临时链接:', result.fileList);
   ```
   - 添加详细的日志输出
   - 检查每个步骤的执行结果

2. **权限检查清单**
   - [ ] 云函数运行权限
   - [ ] 云存储访问权限
   - [ ] 文件读取权限
   - [ ] 临时链接有效期

3. **常见错误及解决方案**
   ```javascript
   // 错误示例
   wx.cloud.storage.list  // ❌ 云函数中不能用
   
   // 正确示例
   cloud.storage.list     // ✅ 使用 cloud 对象
   ```

### 4. 维护建议

1. **文件命名规范**
   - 统一格式：naildidi.com(序号).webp
   - 序号从1开始递增
   - 保持命名一致性

2. **代码管理**
   - 保持代码备份
   - 记录修改历史
   - 定期检查日志

3. **性能优化**
   - 控制图片大小
   - 使用 webp 格式
   - 实现懒加载

## 问题解决历程
1. 发现问题：云函数重新部署后无法获取图片
2. 定位原因：使用了错误的对象（wx 替代 cloud）
3. 解决方案：修改云函数代码，使用正确的 API
4. 验证结果：成功获取并显示图片列表

## 参考资料
- [微信云开发文档](https://developers.weixin.qq.com/miniprogram/dev/wxcloud/basis/getting-started.html)
- [云函数介绍](https://developers.weixin.qq.com/miniprogram/dev/wxcloud/basis/capabilities.html#云函数)

## 更新记录
- 2025-03-22：首次创建文档，记录云函数部署和图片获取问题的解决方案

这个文档现在包含了：
完整的问题描述和解决方案
特别容易被忽略的注意事项
3. 详细的代码示例
故障排查步骤
维护建议
问题解决历程
参考资料和更新记录
需要我补充或修改任何部分吗？

## 从零开始：如何获取云存储指定文件夹下的文件

### 1. 前期准备
1. **开通云开发**
   - 登录微信小程序后台
   - 点击"云开发"
   - 开通云开发环境（记住环境ID）

2. **配置云存储**
   - 在云开发控制台中选择"云存储"
   - 创建需要的文件夹（例如：gallery）
   - 上传测试文件

### 2. 创建云函数
1. **创建函数目录**
   ```bash
   # 在项目根目录下
   cloudfunctions/
   └── getGalleryFiles/      # 创建这个文件夹
   ```

2. **初始化云函数**
   - 在微信开发者工具中
   - 右键点击 getGalleryFiles 文件夹
   - 选择"新建 Node.js 云函数"

3. **安装依赖**
   ```bash
   cd cloudfunctions/getGalleryFiles
   npm init -y
   npm install --save wx-server-sdk@~2.6.3
   ```

### 3. 编写云函数代码
1. **基础框架**
   ```javascript
   // index.js
   const cloud = require('wx-server-sdk')
   
   cloud.init({
     env: cloud.DYNAMIC_CURRENT_ENV  // 使用动态环境ID
   })
   
   exports.main = async (event, context) => {
     try {
       // 核心代码将在这里实现
     } catch (err) {
       console.error(err)
       return { success: false, error: err.message }
     }
   }
   ```

2. **完整实现**
   ```javascript
   const cloud = require('wx-server-sdk')
   
   cloud.init({
     env: cloud.DYNAMIC_CURRENT_ENV
   })
   
   exports.main = async (event, context) => {
     try {
       console.log('开始获取文件列表');
       
       // 方法一：如果文件数量固定，直接构造文件列表
       const fileIDs = [];
       for(let i = 1; i <= 8; i++) {
         fileIDs.push(`cloud://你的环境ID/gallery/naildidi.com(${i}).webp`);
       }
       
       // 方法二：如果需要动态获取文件列表（需要更高权限）
       /* const result = await cloud.storage.listFiles({
         prefix: 'gallery/',
         limit: 100
       }); */
       
       // 获取临时访问链接
       const { fileList } = await cloud.getTempFileURL({
         fileList: fileIDs
       });
       
       // 处理结果
       const processedList = fileList
         .filter(file => file.status === 0)  // 只保留成功的文件
         .map(file => ({
           key: file.fileID.split('/').pop(),  // 提取文件名
           tempFileURL: file.tempFileURL       // 临时访问链接
         }));
       
       return {
         result: {
           success: true,
           fileList: processedList
         }
       };
     } catch (err) {
       console.error('云函数执行错误:', err);
       return {
         result: {
           success: false,
           error: err.message
         }
       };
     }
   }
   ```

### 4. 部署云函数
1. **右键点击 getGalleryFiles 文件夹**
2. **选择"上传并部署：云端安装依赖"**
3. **等待部署完成**

### 5. 前端调用
```javascript
// pages/gallery/gallery.js
Page({
  async loadGalleryImages() {
    try {
      wx.showLoading({ title: '加载中...' });
      
      const res = await wx.cloud.callFunction({
        name: 'getGalleryFiles'
      });
      
      console.log('云函数返回:', res);
      
      if (res.result && res.result.result.success) {
        const fileList = res.result.result.fileList;
        // 处理文件列表...
      }
    } catch (err) {
      console.error('获取图片失败:', err);
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  }
});
```

### 6. 常见问题及解决方案

1. **路径问题**
   ```javascript
   // ❌ 错误示例
   'gallery/image.webp'  // 路径不完整
   
   // ✅ 正确示例
   'cloud://环境ID.文件路径/gallery/image.webp'  // 完整路径
   ```

2. **权限问题**
   - 检查云函数权限配置
   - 确认云存储访问权限
   - 验证环境ID是否正确

3. **部署问题**
   - 删除旧的 node_modules
   - 重新安装依赖
   - 完整部署云函数

4. **调试技巧**
   ```javascript
   // 添加详细日志
   console.log('输入参数:', event);
   console.log('文件列表:', fileList);
   console.log('处理结果:', processedList);
   ```

### 7. 性能优化建议

1. **文件命名优化**
   - 使用有序的文件名
   - 便于排序和管理
   - 例如：`naildidi.com(1).webp`

2. **链接缓存**
   - 合理设置临时链接有效期
   - 可以在前端缓存链接
   - 避免频繁请求

3. **错误重试**
   ```javascript
   async function getFiles(retryCount = 3) {
     for(let i = 0; i < retryCount; i++) {
       try {
         return await wx.cloud.callFunction({
           name: 'getGalleryFiles'
         });
       } catch (err) {
         if (i === retryCount - 1) throw err;
         await new Promise(r => setTimeout(r, 1000));
       }
     }
   }
   ```

### 8. 测试验证
1. 上传测试文件到云存储
2. 部署云函数
3. 调用云函数获取文件列表
4. 验证文件访问链接
5. 检查错误处理

这个完整的教程应该能帮助新手从零开始实现云存储文件获取功能。需要补充或者解释任何部分吗？

## 常见错误及解决方案（补充）

### 1. 数据结构访问错误

#### 问题表现
```javascript
// 日志输出
gallery.js:112 文件列表: undefined
```

#### 错误代码
```javascript
// ❌ 错误的数据访问方式
console.log('文件列表:', res.result.fileList);
if (res.result.success && Array.isArray(res.result.fileList)) {
  // ...
}
```

#### 正确代码
```javascript
// ✅ 正确的数据访问方式
console.log('文件列表:', res.result.result.fileList);
if (res.result.result.success && Array.isArray(res.result.result.fileList)) {
  // ...
}
```

#### 原因分析
云函数返回的数据结构是双层 result：
```javascript
{
  result: {           // 第一层：云函数框架添加的
    result: {         // 第二层：我们自己返回的
      success: true,
      fileList: [...]
    }
  }
}
```

### 2. 云函数部署问题

#### 问题表现
```bash
Error: ENOENT: no such file or directory, open 'cloudfunctions/getGalleryList/index.js'
```

#### 解决步骤
1. **检查 project.config.json 配置**
```json
{
  "functions": [
    {
      "name": "getGalleryFiles",  // 确保名称正确
      "runtime": "nodejs16"
    }
  ]
}
```

2. **清理步骤**
   - 删除旧的云函数（如果存在）
   - 清除开发者工具缓存
   - 重启开发者工具
   - 重新部署云函数

3. **验证部署**
   - 检查云开发控制台中的云函数列表
   - 查看云函数日志
   - 测试云函数调用

### 3. 代码规范和最佳实践

#### 云函数返回格式规范
```javascript
// 统一的返回格式
return {
  result: {
    success: true,    // 状态标识
    fileList: [...],  // 数据内容
    error: null       // 错误信息
  }
};
```

#### 前端访问规范
```javascript
try {
  const res = await wx.cloud.callFunction({
    name: 'getGalleryFiles'
  });

  // 1. 先检查返回值结构
  if (!res.result || !res.result.result) {
    throw new Error('返回数据格式错误');
  }

  // 2. 再检查业务状态
  if (!res.result.result.success) {
    throw new Error(res.result.result.error || '操作失败');
  }

  // 3. 最后处理数据
  const fileList = res.result.result.fileList;
  // ...处理数据
} catch (err) {
  console.error('操作失败:', err);
  wx.showToast({
    title: err.message || '未知错误',
    icon: 'none'
  });
}
```

### 4. 调试技巧

#### 日志检查点
```javascript
// 云函数中
console.log('开始获取文件列表');
console.log('准备获取的文件列表:', fileIDs);
console.log('获取到的临时链接:', result.fileList);

// 前端中
console.log('云函数返回数据:', res);
console.log('文件列表:', res.result.result.fileList);
console.log('处理后的数据:', processedList);
```

#### 错误处理最佳实践
1. **云函数端**：
   ```javascript
   try {
     // 业务逻辑
   } catch (err) {
     console.error('具体操作名称失败:', err);
     return {
       result: {
         success: false,
         error: err.message || '操作失败',
         fileList: []
       }
     };
   }
   ```

2. **前端**：
   ```javascript
   try {
     // 业务逻辑
   } catch (err) {
     console.error('具体错误描述:', err);
     wx.showToast({
       title: this.formatError(err),
       icon: 'none'
     });
   } finally {
     this.setData({ isLoading: false });
   }
   ```

### 5. 发布前检查清单

- [ ] 云函数名称与配置文件一致
- [ ] 云函数已正确部署
- [ ] 数据访问路径正确
- [ ] 错误处理完善
- [ ] 日志输出合理
- [ ] 清理测试代码
- [ ] 性能优化完成

### 6. 常见陷阱和注意事项

1. **云函数部署相关**
   - 确保函数名称一致性
   - 部署前清理缓存
   - 检查运行时版本

2. **数据结构相关**
   - 注意双层 result 结构
   - 统一返回格式
   - 完整错误处理

3. **性能优化相关**
   - 合理使用日志
   - 控制返回数据大小
   - 优化图片加载

## 更新记录
- 2025-03-22：首次创建文档
- 2025-03-23：补充常见错误和解决方案
- 2025-03-23：添加调试技巧和最佳实践





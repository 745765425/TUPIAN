export const CLOUD_FUNCTIONS = {
  GET_GALLERY: 'getGalleryFiles',
  // ... 其他云函数名称
}; 
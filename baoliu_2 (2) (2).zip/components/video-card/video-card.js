Component({
  options: {
    multipleSlots: true, // 启用多slot支持
    addGlobalClass: true
  },
  /**
   * 组件的属性列表
   */
  properties: {
    videoInfo: {
      type: Object,
      value: {},
      observer: function(newVal) {
        if (newVal && newVal.videoUrl) {
          // 创建视频上下文
          if (newVal.id) {
            this.initVideoContext(newVal.id);
          }
          
          // 获取临时访问URL
          this.getTempVideoUrl(newVal.videoUrl);
        }
      }
    },
    extClass: {
      type: String,
      value: ''
    },
    borderRadius: {
      type: String,
      value: '12px'
    },
    isDetailShow: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        if (newVal) {
          // 详情页打开时，只暂停视频，保持可见性
          this.pauseVideo();
          if (this.playTimer) {
            clearTimeout(this.playTimer);
            this.playTimer = null;
          }
        }
      }
    },
    isInView: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        // 防止快速滚动时的播放/暂停冲突
        if (this._inViewTimer) {
          clearTimeout(this._inViewTimer);
        }
        
        this._inViewTimer = setTimeout(() => {
          if (newVal) {
            console.log('视频进入视图，但不自动播放');
          } else {
            this.pauseVideo();
          }
        }, 100);
      }
    },
    isFirstVideo: {
      type: Boolean,
      value: false
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    showControls: false,
    keepVideoVisible: false, // 新增状态，表示保持视频可见
    isMuted: true, // 默认静音
    posterVideoContext: null, // 新增属性，用于存储封面视频上下文
    showReplayButton: false,  // 控制重播按钮显示
    playTimer: null,  // 添加播放定时器
    windowHeight: 0,
    isPlayingVideo: false,
    _isPlaying: false,
    _isPlayRequested: false,
    _playPromise: null,
    isPlaying: false,  // 添加播放状态标记
    videoContext: null,  // 添加videoContext到data中
    currentTime: 0, // 添加当前播放时间记录
    duration: 0,
    tempVideoUrl: '',
    isLoading: false,  // 改为 false，默认不显示加载状态
    isPreloading: false  // 新增预加载状态
  },
  lifetimes: {
    attached() {
      try {
        const windowInfo = wx.getWindowInfo();
        this.setData({
          windowHeight: windowInfo.windowHeight
        });

        if (this.properties.videoInfo && this.properties.videoInfo.id) {
          this.initVideoContext(this.properties.videoInfo.id);
        }

        if (this.properties.videoInfo && this.properties.videoInfo.videoUrl) {
          // 预加载视频
          this.preloadVideo();
        }
      } catch (error) {
        console.error('初始化失败:', error);
      }
    },
    detached() {
      if (this.playTimer) {
        clearTimeout(this.playTimer);
        this.playTimer = null;
      }
      
      // 清理所有定时器
      if (this._viewChangeTimer) {
        clearTimeout(this._viewChangeTimer);
        this._viewChangeTimer = null;
      }
      
      if (this._inViewTimer) {
        clearTimeout(this._inViewTimer);
        this._inViewTimer = null;
      }
      
      if (this._autoPlayTimer) {
        clearTimeout(this._autoPlayTimer);
        this._autoPlayTimer = null;
      }
      
      // 组件销毁时，确保清理所有状态和操作
      this._isPlaying = false;
      this._isPlayRequested = false;
      this._playPromise = null;
      
      // 组件销毁时暂停视频
      if (this.videoContext) {
        this.videoContext.pause();
        this.videoContext = null;
      }
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    // 初始化视频上下文
    initVideoContext(videoId) {
      if (!this.videoContext) {
        this.videoContext = wx.createVideoContext(`video-${videoId}`, this);
        console.log('视频上下文已创建:', videoId);
      }
    },

    // 统一的播放控制方法
    togglePlay(e) {
      console.log('触发播放/暂停', e);
      
      // 检查e是否是有效的事件对象
      if (e && typeof e.stopPropagation === 'function' && e.currentTarget && e.currentTarget.dataset.role === 'video-control') {
        e.stopPropagation();
      }
      
      if (!this.videoContext) {
        this.initVideoContext(this.properties.videoInfo.id);
      }
      
      if (!this.videoContext) {
        console.error('无法创建视频上下文');
        return;
      }

      if (!this.data.isPlaying) {
        console.log('开始播放');
        // 检查是否需要从头开始播放
        if (this.data.currentTime >= this.data.duration - 0.5) {
          console.log('视频接近结束，从头开始播放');
          this.videoContext.seek(0);
        }
        this.videoContext.play();
      } else {
        console.log('暂停播放');
        this.videoContext.pause();
      }
    },

    // 视频事件处理
    onVideoPlay() {
      console.log('视频开始播放事件');
      this.setData({
        isPlaying: true
      });
    },

    onVideoPause() {
      console.log('视频暂停事件');
      this.setData({ isPlaying: false });
    },

    onVideoEnded(e) {
      console.log('视频播放结束');
      
      // 更新播放状态
      this.setData({
        isPlaying: false,
        currentTime: 0  // 重置当前时间
      });
      
      // 不自动重新播放，等待用户点击
      
      // 触发事件通知父组件
      this.triggerEvent('videoended', {
        videoId: this.properties.videoInfo.id,
        videoInfo: this.properties.videoInfo
      });
    },

    onVideoError(e) {
      console.error('视频加载错误:', e.detail);
      
      // 记录错误信息
      const errorMsg = e.detail.errMsg || '未知错误';
      const errorCode = e.detail.errCode || -1;
      
      console.error(`视频错误: ${errorMsg}, 代码: ${errorCode}`);
      
      // 尝试重新获取临时链接
      if (this.properties.videoInfo && this.properties.videoInfo.videoUrl) {
        console.log('尝试重新获取视频链接');
        this.getTempVideoUrl(this.properties.videoInfo.videoUrl);
      }
      
      // 显示错误提示（可选）
      wx.showToast({
        title: '视频加载失败，正在重试',
        icon: 'none',
        duration: 2000
      });
    },

    // 静音控制
    toggleMute() {
      this.setData({
        isMuted: !this.data.isMuted
      });
    },

    // 打开详情
    openDetail() {
      console.log('触发 openDetail 事件，传递的视频信息:', this.properties.videoInfo);
      
      // 确保有视频信息
      if (!this.properties.videoInfo) {
        console.error('视频信息不存在');
        wx.showToast({
          title: '视频信息不存在',
          icon: 'none'
        });
        return;
      }
      
      // 如果视频正在播放，先暂停
      if (this.data.isPlaying) {
        console.log('打开弹窗前暂停视频');
        if (!this.videoContext) {
          this.videoContext = wx.createVideoContext(`video-${this.properties.videoInfo.id}`, this);
        }
        this.videoContext.pause();
        this.setData({ isPlaying: false });
      }
      
      // 触发 cardtap 事件，传递视频信息和当前播放时间
      this.triggerEvent('cardtap', { 
        videoId: this.properties.videoInfo.id,
        videoInfo: this.properties.videoInfo,
        currentTime: this.data.currentTime // 传递当前播放时间
      });
    },

    // 视频时间更新事件
    onTimeUpdate(e) {
      // 更新当前时间和总时长
      this.setData({
        currentTime: e.detail.currentTime,
        duration: e.detail.duration
      });
    },

    // 播放视频
    playVideo() {
      console.log('执行播放视频');
      
      if (!this.videoContext) {
        console.log('创建视频上下文');
        this.videoContext = wx.createVideoContext(`video-${this.properties.videoInfo.id}`, this);
      }
      
      if (this.videoContext) {
        console.log('调用播放方法');
        this.videoContext.play();
        
        // 更新状态
        this.setData({
          isPlaying: true
        });
      } else {
        console.error('无法创建视频上下文');
      }
    },
    
    // 暂停视频
    pauseVideo() {
      console.log('执行暂停视频');
      
      if (!this.videoContext) {
        this.videoContext = wx.createVideoContext(`video-${this.data.videoInfo.id}`, this);
      }
      
      this.videoContext.pause();
      this.setData({ isPlaying: false });
    },
    
    // 实际执行暂停的方法
    _doPause() {
      if (!this._isPlaying && !this._isPlayRequested) return;
      
      if (!this.isPlayingVideo) return;
      this.isPlayingVideo = false;

      if (this.videoContext && this.data.isPlaying) {
        this.videoContext.pause();
        this.setData({
          isPlaying: false,
          keepVideoVisible: true
        });
        this._isPlaying = false;
        this._isPlayRequested = false;
      }
    },
    
    // 视频播放结束
    videoEnd() {
      this.isPlayingVideo = false;
      this.setData({
        isPlaying: false,
        keepVideoVisible: true,
        showReplayButton: true
      });
      // 触发结束事件
      this.triggerEvent('videoend');
    },
    
    // 点击视频卡片
    onTap() {
      // 点击时立即暂停当前视频
      if (this.data.isPlaying) {
        this.pauseVideo();
      }
      
      // 触发卡片点击事件
      this.onCardTap();
    },
    
    // 修改showMore方法为分享功能
    showMore() {
      // 触发自定义分享事件，传递当前视频信息
      this.triggerEvent('share', { 
        videoId: this.data.videoInfo.id,
        title: this.data.videoInfo.title,
        imageUrl: this.data.videoInfo.coverUrl,
        path: `/pages/video-detail/video-detail?id=${this.data.videoInfo.id}`
      });
    },
    
    // 修改 onCardTap 方法
    onCardTap(e) {
      // 检查点击来源，避免与视频播放控制冲突
      const target = e.target;
      const dataset = target.dataset;
      
      // 如果点击的是视频控制层或其他特定元素，不触发详情
      if (dataset && (dataset.role === 'video-control' || dataset.role === 'mute-button' || dataset.role === 'share-button')) {
        return;
      }
      
      // 触发详情页打开
      this.openDetail();
    },
    
    // 修改重播方法
    replayVideo(e) {
      if (this.data.videoContext) {
        this.data.videoContext.seek(0);  // 跳转到视频开始
        this.data.videoContext.play();   // 开始播放
        
        this.setData({
          isPlaying: true,
          showReplayButton: false  // 隐藏重播按钮
        });
      }
    },
    
    // 添加处理云文件的方法
    async getVideoUrl(fileID) {
      try {
        const { fileList } = await wx.cloud.getTempFileURL({
          fileList: [fileID]
        })
        return fileList[0].tempFileURL
      } catch (err) {
        console.error('获取视频链接失败:', err)
        return ''
      }
    },
    
    // 添加自动播放方法
    autoPlayVideo() {
      console.log('自动播放已禁用');
      return;
    },
    
    handleVideoError(e) {
      console.error('视频加载错误:', e.detail);
      // 可以在这里添加错误处理逻辑
    },

    // 添加测试链接方法
    async testVideoUrl() {
      const videoUrl = this.properties.videoInfo.videoUrl;
      console.log('原始视频链接:', videoUrl);

      try {
        // 测试获取临时链接
        const result = await wx.cloud.getTempFileURL({
          fileList: [videoUrl]
        });
        
        if (result.fileList && result.fileList[0].tempFileURL) {
          console.log('获取到临时链接:', result.fileList[0].tempFileURL);
          
          // 测试临时链接的可访问性
          wx.request({
            url: result.fileList[0].tempFileURL,
            method: 'HEAD',
            success: (res) => {
              console.log('链接可访问，状态码:', res.statusCode);
              console.log('响应头:', res.header);
            },
            fail: (err) => {
              console.error('链接访问失败:', err);
            }
          });
        }
      } catch (err) {
        console.error('获取临时链接失败:', err);
      }
    },

    // 改进URL编码和处理函数
    encodeVideoUrl(url) {
      if (!url) return '';
      
      try {
        // 首先移除URL中的#及其后面的内容
        if (url.includes('#')) {
          url = url.split('#')[0];
          console.log('移除#后的URL:', url);
        }
        
        // 检查URL是否已经编码
        if (url.indexOf('%') > -1 && decodeURIComponent(url) !== url) {
          console.log('URL已经编码，跳过处理');
          return url;
        }
        
        // 使用encodeURI保留URL结构，但编码中文字符
        let encodedUrl = url;
        
        // 如果URL包含中文，进行编码
        if (/[\u4e00-\u9fa5]/.test(url)) {
          // 分离协议和域名部分
          const urlParts = url.match(/^(https?:\/\/[^\/]+)(\/.*)/);
          if (urlParts) {
            const domain = urlParts[1]; // 协议和域名
            const path = urlParts[2];   // 路径部分
            
            // 只对路径部分进行编码
            encodedUrl = domain + encodeURI(path);
          } else {
            // 如果无法分离，对整个URL进行编码
            encodedUrl = encodeURI(url);
          }
          
          console.log('URL包含中文，已编码:', encodedUrl);
        }
        
        return encodedUrl;
      } catch (e) {
        console.error('URL编码失败:', e);
        return url; // 出错时返回原始URL
      }
    },

    // 改进getTempVideoUrl方法
    getTempVideoUrl: function(videoUrl) {
      console.log('获取临时视频链接 - 原始URL:', videoUrl);
      
      // 先进行URL编码和处理
      const encodedUrl = this.encodeVideoUrl(videoUrl);
      console.log('获取临时视频链接 - 处理后URL:', encodedUrl);
      
      // 检查是否已经是临时链接
      if (encodedUrl.indexOf('tempFileURL') > -1) {
        this.setData({ tempVideoUrl: encodedUrl });
        return;
      }
      
      // 检查是否是云存储文件ID
      const isCloudID = encodedUrl.startsWith('cloud://') || 
                        (encodedUrl.startsWith('https://') && encodedUrl.includes('tcb.qcloud.la'));
      
      if (isCloudID || encodedUrl.startsWith('https://')) {
        // 使用云函数获取临时链接
        wx.cloud.getTempFileURL({
          fileList: [encodedUrl],
          success: res => {
            console.log('获取临时链接成功:', res);
            if (res.fileList && res.fileList[0] && res.fileList[0].tempFileURL) {
              let tempUrl = res.fileList[0].tempFileURL;
              
              // 确保临时链接中没有#号
              if (tempUrl.includes('#')) {
                tempUrl = tempUrl.split('#')[0];
              }
              
              // 添加时间戳防止缓存问题
              if (!tempUrl.includes('?')) {
                tempUrl += '?';
              } else {
                tempUrl += '&';
              }
              tempUrl += `t=${new Date().getTime()}`;
              
              console.log('最终使用的临时链接:', tempUrl);
              
              this.setData({
                tempVideoUrl: tempUrl
              });
            }
          },
          fail: err => {
            console.error('获取临时链接失败:', err);
            // 失败时尝试使用编码后的原始链接
            this.setData({ tempVideoUrl: encodedUrl });
          }
        });
      } else {
        // 如果不是云存储ID，直接使用编码后的链接
        this.setData({ tempVideoUrl: encodedUrl });
      }
    },

    // 添加分享按钮点击处理函数
    onShareButtonTap(e) {
      // 阻止事件冒泡，只处理分享
      console.log('分享按钮被点击，阻止冒泡');
      // 不需要做任何事情，微信会自动处理分享
    },

    // 添加预加载方法
    preloadVideo() {
      if (!this.properties.videoInfo || !this.properties.videoInfo.videoUrl) return;
      
      console.log('预加载视频:', this.properties.videoInfo.videoUrl);
      
      // 先获取临时链接
      this.getTempVideoUrl(this.properties.videoInfo.videoUrl);
      
      // 设置一个标记，表示视频正在预加载
      this.setData({ isPreloading: true });
      
      // 延迟一段时间后创建视频上下文，这样可以确保临时链接已经获取
      setTimeout(() => {
        if (this.data.tempVideoUrl) {
          // 创建视频上下文
          this.initVideoContext(this.properties.videoInfo.id);
          
          // 标记预加载完成
          this.setData({ isPreloading: false });
        }
      }, 1000);
    }
  }
}) 
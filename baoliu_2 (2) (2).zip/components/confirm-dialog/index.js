Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    },
    title: {
      type: String,
      value: ''
    },
    content: {
      type: String,
      value: ''
    }
  },

  methods: {
    handleConfirm() {
      this.triggerEvent('confirm');
      this.handleClose();
    },

    handleClose() {
      this.triggerEvent('close');
    },

    preventBubble() {}
  }
}); 
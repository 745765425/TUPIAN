// app.js
// var unusedVar = 123;   // 使用 var 而不是 let/const
// function emptyFunc() { }  // 空函数
// function duplicateFunc() { }
// function duplicateFunc() { }  // 重复的函数声明

App({
  globalData: {
    // 数据存储
    gallery: {
      data: null,
      isComplete: false,
      hasMore: false    // 替代 hasMoreGalleryImages
    },
    
    // 用户信息
    userInfo: null,
    isAdmin: false,
    isPreloading: false,  // 移到顶层
    launchImagesPreloaded: false
  },

  async onLaunch() {
    // 初始化云开发
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: 'nail-spray-cloud-1f7k6g24bb56801',
        traceUser: true,
      })
      console.log('云开发初始化完成，环境ID:', 'nail-spray-cloud-1f7k6g24bb56801')
    }

    // 预加载启动页图片 - 移到最前面确保最优先加载
    this.preloadLaunchImages();

    // 添加预加载图片数据的逻辑
    try {
      const res = await wx.cloud.callFunction({
        name: 'getGalleryFiles'
      });

      if (res.result?.success && res.result?.fileList?.length > 0) {
        // 将数据存储到全局
        this.globalData.gallery = {
          data: res.result.fileList,
          isComplete: true,
          hasMore: false
        };
      }
    } catch (err) {
      console.error('预加载图片数据失败:', err);
    }

    // 确保启动时清除所有旧数据
    this.clearAllData();

    // 确保启动时TabBar隐藏
    this.ensureTabBarHidden();
  },
  
  // 添加页面显示时的处理
  onShow: function() {
    // 确保每次页面显示时都隐藏原生TabBar
    this.ensureTabBarHidden();
  },
  
  // 检查用户是否为管理员
  checkAdmin: function(callback) {
    wx.cloud.callFunction({
      name: 'checkAdmin',
      success: res => {
        console.log('检查管理员结果:', res.result)
        const isAdmin = res.result && res.result.isAdmin === true ? true : false
        this.globalData.isAdmin = isAdmin
        if (callback) callback(isAdmin)
      },
      fail: err => {
        console.error('检查管理员权限失败', err)
        this.globalData.isAdmin = false
        if (callback) callback(false)
      }
    })
  },

  // 添加全局图片工具
  imageUtil: {
    // 分析图片尺寸并返回布局信息
    analyzeImageSize(url) {
      return new Promise((resolve) => {
        wx.getImageInfo({
          src: url,
          success: (res) => {
            const { width, height } = res;
            const ratio = height / width;
            
            // 根据图片比例决定布局方式
            const layoutInfo = {
              isVertical: ratio > 1.2,  // 高宽比大于1.2认为是竖图
              isHorizontal: ratio < 0.8,  // 高宽比小于0.8认为是横图
              isSquare: ratio >= 0.8 && ratio <= 1.2,  // 接近正方形
              ratio: ratio,
              originalWidth: width,
              originalHeight: height
            };
            
            resolve(layoutInfo);
          },
          fail: (err) => this.handleError(err, 'analyzeImageSize')
        });
      });
    }
  },

  // 预加载方法
  async startPreload() {
    if (this.globalData.isPreloading) return;
    this.globalData.isPreloading = true;

    try {
      await this.preloadGallery();  // 只预加载图片
    } catch (err) {
      console.error('预加载失败:', err);
    } finally {
      this.globalData.isPreloading = false;
    }
  },

  // 添加完整的数据清理方法
  clearAllData() {
    // 清除本地存储
    try {
      wx.clearStorageSync();
    } catch(e) {
      console.error('清除存储失败:', e);
    }
  },

  // 在 app.js 中添加工具方法
  getSystemInfo() {
    return {
      windowInfo: wx.getWindowInfo(),
      deviceInfo: wx.getDeviceInfo(),
      appBaseInfo: wx.getAppBaseInfo()
    };
  },

  // 修改建议：创建一个统一的方法
  ensureTabBarHidden: function() {
    wx.hideTabBar();
  },

  // 添加统一的错误处理方法
  handleError: function(error, context) {
    console.error(`[${context}]错误:`, error);
    return null;
  },

  preloadLaunchImages: function() {
    const launchImages = [
      'cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/static/qidongye1.svg',
      'cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/static/qidongye2.webp',
      'cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/static/qidongye3.webp',
      'cloud://nail-spray-cloud-1f7k6g24bb56801.6e61-nail-spray-cloud-1f7k6g24bb56801-1342588805/static/qidongye4.svg'
    ];
    
    // 先设置为false，确保预加载状态正确
    this.globalData.launchImagesPreloaded = false;
    console.log('开始预加载启动页图片');
    
    // 先获取临时链接，再下载
    wx.cloud.getTempFileURL({
      fileList: launchImages,
      success: res => {
        console.log('获取临时链接成功:', res.fileList);
        
        // 记录已加载的图片数量
        let loadedCount = 0;
        const totalImages = res.fileList.length;
        
        // 下载每个文件
        res.fileList.forEach(file => {
          if (!file.tempFileURL) {
            console.error('获取临时链接失败:', file);
            loadedCount++;
            if (loadedCount === totalImages) {
              this.globalData.launchImagesPreloaded = true;
              console.log('启动页图片预加载完成(部分失败)');
            }
            return;
          }
          
          // 使用临时链接下载
          wx.downloadFile({
            url: file.tempFileURL,
            success: () => {
              loadedCount++;
              console.log(`预加载启动页图片 ${loadedCount}/${totalImages}`);
              
              // 所有启动页图片加载完成
              if (loadedCount === totalImages) {
                this.globalData.launchImagesPreloaded = true;
                console.log('所有启动页图片预加载完成');
              }
            },
            fail: (err) => {
              loadedCount++;
              console.error(`下载临时文件失败: ${file.tempFileURL}`, err);
              
              // 即使失败也继续
              if (loadedCount === totalImages) {
                this.globalData.launchImagesPreloaded = true;
                console.log('启动页图片预加载完成(部分失败)');
              }
            }
          });
        });
      },
      fail: err => {
        console.error('获取临时链接失败:', err);
        // 即使获取临时链接失败，也标记为预加载完成，避免无限等待
        this.globalData.launchImagesPreloaded = true;
        console.log('启动页图片预加载失败，但继续执行');
      }
    });
    
    // 设置超时，确保不会永远等待
    setTimeout(() => {
      if (!this.globalData.launchImagesPreloaded) {
        this.globalData.launchImagesPreloaded = true;
        console.log('启动页图片预加载超时，强制完成');
      }
    }, 2000);
  },
})

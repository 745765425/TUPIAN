const cloud = require('wx-server-sdk');
const COS = require('cos-nodejs-sdk-v5');
const config = require('./config.json');

// 初始化 COS 实例
const cos = new COS({
  SecretId: config.SecretId,
  SecretKey: config.SecretKey
});

// 初始化云开发
cloud.init();

exports.main = async (event, context) => {
  const { page = 1, limit = 10 } = event;
  const folder = '视频列表/';  // 与您创建的文件夹路径匹配

  try {
    // 获取 COS 文件夹中的视频列表
    const cosFiles = await cos.getBucket({
      Bucket: config.Bucket,
      Region: config.Region,
      Prefix: folder,
      Delimiter: '/'
    });

    // 处理视频文件信息
    let videoList = cosFiles.Contents
      .filter(file => file.Key.endsWith('.mp4'))
      .map(file => {
        const fileName = file.Key.split('/').pop();
        const [displayNumber, title, subtitle, playCount] = fileName.split('_');
        
        return {
          id: file.Key, // 使用文件路径作为唯一ID
          sequenceNumber: parseInt(displayNumber),
          displayNumber,
          videoUrl: `https://${config.Bucket}.cos.${config.Region}.myqcloud.com/${file.Key}`,
          title: title || '视频教程',
          subtitle: subtitle || '美甲教程',
          playCount: playCount ? playCount.replace('.mp4', '') : '0',
          createTime: file.LastModified
        };
      });

    // 获取临时访问URL
    const fileList = videoList.map(item => item.videoUrl);
    const tempUrlResult = await cloud.getTempFileURL({
      fileList: fileList
    });
    
    // 将临时URL添加到视频信息中
    if (tempUrlResult.fileList && tempUrlResult.fileList.length > 0) {
      tempUrlResult.fileList.forEach((file, index) => {
        if (file.tempFileURL) {
          videoList[index].tempUrl = file.tempFileURL;
        }
      });
    }

    return {
      success: true,
      data: videoList
    };

  } catch (error) {
    console.error('获取视频列表失败:', error);
    return {
      success: false,
      error: error.message
    };
  }
}; 
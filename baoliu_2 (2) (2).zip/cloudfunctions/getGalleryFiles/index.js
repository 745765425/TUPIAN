const COS = require('cos-nodejs-sdk-v5');
const config = require('./config.json');

// 使用配置文件初始化 COS
const cos = new COS({
    SecretId: config.SecretId,
    SecretKey: config.SecretKey
});

exports.main = async (event, context) => {
    const folder = event.folder || '瀑布流/';
    
    const params = {
        Bucket: config.Bucket,
        Region: config.Region,
        Prefix: folder,
        Delimiter: '/',
        MaxKeys: 1000
    };

    try {
        const data = await cos.getBucket(params);
        
        // 过滤并处理图片文件
        const files = data.Contents
            .filter(item => /\.(jpg|jpeg|png|gif|webp)$/i.test(item.Key))
            .map(item => {
                const key = item.Key.split('/').pop();
                return {
                    Key: item.Key,
                    key: key,
                    url: `https://${config.Bucket}.cos.${config.Region}.myqcloud.com/${item.Key}`,
                    createTime: item.LastModified
                };
            });
        
        return {
            success: true,
            data: files,
            result: {
                success: true,
                fileList: files
            }
        };
    } catch (err) {
        console.error('获取文件列表失败:', err);
        return {
            success: false,
            error: err.message,
            result: {
                success: false,
                error: err.message
            }
        };
    }
}; 
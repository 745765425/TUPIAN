Component({
  properties: {
    videoInfo: {
      type: Object,
      value: null,
      observer: function(newVal) {
        if (newVal && newVal.id) {
          // 当videoInfo更新时，重新创建videoContext
          this.initVideoContext();
        }
      }
    },
    autoplay: {
      type: Boolean,
      value: false
    }
  },
  
  data: {
    isPlaying: false,
    isLoading: true
  },
  
  lifetimes: {
    // 在组件初始化时确保创建 videoContext
    attached: function() {
      // 确保 videoInfo.id 存在
      if (this.data.videoInfo && this.data.videoInfo.id) {
        this.initVideoContext();
      }
    },
    
    detached: function() {
      // 组件销毁时释放资源
      if (this.videoContext) {
        this.videoContext.stop();
        this.videoContext = null;
      }
    }
  },
  
  methods: {
    // 初始化视频上下文
    initVideoContext: function() {
      // 使用setTimeout确保视频元素已经渲染
      setTimeout(() => {
        if (this.data.videoInfo && this.data.videoInfo.id) {
          this.videoContext = wx.createVideoContext(`video-${this.data.videoInfo.id}`, this);
          console.log('视频上下文已创建:', this.videoContext);
          
          // 如果设置了自动播放，则自动播放视频
          if (this.properties.autoplay) {
            this.playVideo();
          }
        }
      }, 100);
    },
    
    // 在视频加载完成时的处理
    onVideoLoaded: function() {
      console.log('视频加载完成');
      this.setData({ isLoading: false });
      
      // 添加判断，确保 videoContext 存在
      if (!this.videoContext && this.data.videoInfo && this.data.videoInfo.id) {
        this.initVideoContext();
      }
      
      // 如果设置了自动播放，则播放视频
      if (this.properties.autoplay) {
        this.playVideo();
      }
    },
    
    // 播放视频
    playVideo: function() {
      if (this.videoContext) {
        console.log('开始播放视频');
        this.videoContext.play();
        this.setData({ isPlaying: true });
      } else {
        console.error('videoContext 不存在，无法播放视频');
        // 尝试重新创建
        this.initVideoContext();
      }
    },
    
    // 暂停视频
    pauseVideo: function() {
      if (this.videoContext) {
        this.videoContext.pause();
        this.setData({ isPlaying: false });
      }
    },
    
    // 视频播放错误处理
    onVideoError: function(e) {
      console.error('视频播放错误:', e.detail);
      this.setData({ isLoading: false });
      // 可以在这里添加错误提示或重试逻辑
    },
    
    // 视频播放状态变化
    onVideoStateChange: function(e) {
      console.log('视频状态变化:', e.detail);
      // 根据状态更新UI
      if (e.detail.state === 'play') {
        this.setData({ isPlaying: true });
      } else if (e.detail.state === 'pause') {
        this.setData({ isPlaying: false });
      }
    }
  }
}); 
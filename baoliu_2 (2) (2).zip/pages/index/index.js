// index.js
Page({
  data: {
    statusBarHeight: 0, // 状态栏高度
    titleBarHeight: 80, // 标题栏高度（rpx单位）
    showNavHeader: true,
    lastScrollTop: 0,
    activeTab: 'video',
    screenHeight: 0, // 屏幕高度
    safeAreaTop: 0,
    touchStartY: 0, // 触摸开始位置
    touchStartX: 0,
    isDragging: false,
    dragThreshold: 50,  // 下拉阈值
    isDetailShow: false,
    videoList: [],
    loading: false,
    page: 1,
    limit: 10,
    hasMore: true,  // 是否还有更多数据
    isLoading: false,
    hasError: false,
    showLaunch: true,
    headerState: {     // 新增：专门用于管理header状态
      opacity: 1,
      lastScrollTop: 0,
      isHidden: false
    },
    navBarBgImage: '/static/daohanglan.svg',
    showTabBar: false,
    currentVideo: null, // 当前选中的视频
    showVideoDetail: false, // 初始不显示视频详情
  },
  
  onLoad() {
    console.log('===== 页面加载 =====');
    
    const windowInfo = wx.getWindowInfo();
    const systemInfo = wx.getDeviceInfo();
    const appBaseInfo = wx.getAppBaseInfo();
    
    const statusBarHeight = windowInfo.statusBarHeight;
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
    const menuButtonHeight = menuButtonInfo.height;
    const menuButtonTop = menuButtonInfo.top;
    
    const safeAreaTop = menuButtonTop + menuButtonHeight + 10;
    
    this.setData({
      statusBarHeight: statusBarHeight,
      screenHeight: windowInfo.windowHeight,
      safeAreaTop: safeAreaTop,
      isDetailShow: false,
      hasFirstScroll: false,
      initializing: true,
      isBottomBarVisible: true,
    });
    
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: 'transparent',
      animation: {
        duration: 0,
        timingFunc: 'easeIn'
      }
    });
    
    // 设置底部导航栏选中状态
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 0  // 0表示当前是视频页面
      });
    }
    
    this.loadVideos();
  },
  
  onScrollEvent(e) {
    const scrollTop = e.detail.scrollTop;
    
    // 处理顶部容器透明度
    const opacity = Math.max(0, 1 - (scrollTop / 150));
    this.setData({ 
      'headerState.opacity': opacity
    });
  },
  
  onLaunchClose() {
    console.log('===== 启动页关闭 =====');
    this.setData({
      showLaunch: false,
      showTabBar: true  // 启动页关闭后显示TabBar
    });
    
    // 通知TabBar显示
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        isVisible: true
      });
    }
  },
  
  onShow() {
    // 在页面显示时，确保底部导航栏显示正确的选中状态
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 0,
        isVisible: true  // 确保导航栏可见
      });
    }
  },
  
  // 修改暂停所有视频的方法
  pauseAllVideos() {
    // 获取所有视频卡片组件
    const videoCards = this.selectAllComponents('.video-card');
    
    if (videoCards && videoCards.length > 0) {
      console.log('找到视频卡片组件:', videoCards.length);
      
      // 遍历所有视频卡片组件，暂停正在播放的视频
      videoCards.forEach(card => {
        if (card.data.isPlaying) {
          console.log('暂停视频:', card.data.videoInfo.id);
          card.pauseVideo();
        }
      });
    } else {
      console.log('没有找到视频卡片组件');
      
      // 备用方案：尝试通过ID直接暂停视频
      this.data.videoList.forEach(video => {
        const videoContext = wx.createVideoContext(`video-${video.id}`);
        if (videoContext) {
          videoContext.pause();
        }
      });
    }
  },
  
  // 修改视频检测方法
  checkVideoVisibility() {
    console.log('===== 检查视频可见性 =====');
    if (this.data.videoList && this.data.videoList.length > 0) {
      console.log('当前视频列表状态:', this.data.videoList[0].isInViewCenter);
    }
    this.checkVideoInView();
  },

  // 修改视频点击事件处理
  onVideoTap(e) {
    console.log('页面接收到事件:', e);
    console.log('事件详情数据:', e.detail);
    
    // 检查是否有视频信息
    if (!e.detail || !e.detail.videoInfo) {
      console.error('没有接收到视频信息');
      return;
    }
    
    const videoInfo = e.detail.videoInfo;
    console.log('点击视频:', videoInfo);
    
    // 确保视频信息完整
    if (!videoInfo.videoUrl) {
      console.error('视频URL不存在');
      return;
    }
    
    this.setData({
      isDetailShow: true,
      currentVideo: videoInfo
    });
    
    // 添加这行，确认状态已更新
    console.log('弹窗状态已更新:', this.data.isDetailShow, this.data.currentVideo);
    
    // 延迟检查弹窗状态
    setTimeout(() => {
      console.log('延迟检查弹窗状态:', this.data.isDetailShow);
      
      // 获取弹窗组件实例，使用正确的选择器
      const videoDetail = this.selectComponent('#video-detail');
      console.log('弹窗组件实例:', videoDetail);
    }, 500);
  },

  onDetailClose() {
    console.log('关闭视频详情');
    this.setData({
      showVideoDetail: false,
      currentVideo: null  // 清空当前视频
    });
  },

  checkVideoInView() {
    if (this.data.videoList && this.data.videoList.length > 0) {
      const video = this.data.videoList[0];
      if (video) {
        // 只标记视频在视图中，但不触发自动播放
        console.log('视频在视图中，但不自动播放');
      }
    }
  },

  handleShareVideo(e) {
    const { videoInfo } = e.detail;
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  // 官方分享API
  onShareAppMessage(e) {
    // 从按钮的 dataset 中获取视频信息
    const { videoInfo } = e.target.dataset;
    return {
      title: videoInfo ? videoInfo.title : '美甲喷绘视频',
      path: '/pages/index/index',
      imageUrl: videoInfo ? videoInfo.coverUrl : '/images/default-cover.png',
      success: function(res) {
        wx.showToast({
          title: '分享成功',
          icon: 'success'
        });
      },
      fail: function(res) {
        wx.showToast({
          title: '分享失败',
          icon: 'none'
        });
      }
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '美甲喷绘视频',
      query: '',
      imageUrl: '/images/default-cover.png'
    }
  },

  // 处理视频卡片点击
  onVideoCardTap(e) {
    console.log('收到 cardtap 事件:', e.detail);
    
    const { videoId, videoInfo } = e.detail;
    console.log('视频卡片被点击:', videoId, videoInfo);
    
    // 显示详情弹窗
    this.setData({
      currentVideo: videoInfo,
      showVideoDetail: true
    }, () => {
      // setData回调，确保状态已更新
      console.log('弹窗状态已更新:', this.data.showVideoDetail);
      
      // 只在这里调用一次show方法
      const videoDetail = this.selectComponent('#video-detail');
      if (videoDetail) {
        console.log('找到视频详情组件，调用show方法');
        videoDetail.show();
      } else {
        console.error('未找到视频详情组件');
      }
    });
    
    // 添加确认日志
    console.log('设置弹窗状态:', this.data.showVideoDetail);
    console.log('设置当前视频:', this.data.currentVideo);
  },

  // 页面触底事件
  onReachBottom() {
    if (!this.data.loading && this.data.hasMore) {
      this.loadVideos();
    }
  },

  // 加载视频列表
  async loadVideos() {
    if (this.data.loading || !this.data.hasMore) return;

    this.setData({ loading: true });

    try {
      const res = await wx.cloud.callFunction({
        name: 'getVideoList',
        data: {
          page: this.data.page,
          limit: this.data.limit
        }
      });

      const newVideos = res.result.data || [];
      
      this.setData({
        videoList: [...this.data.videoList, ...newVideos],
        page: this.data.page + 1,
        hasMore: newVideos.length === this.data.limit,
        loading: false
      });

    } catch (error) {
      console.error('加载视频失败:', error);
      this.setData({ loading: false });
    }
  }
})

Page({
  data: {
    videoInfo: null
  },
  
  onLoad(options) {
    if (options.id) {
      // 如果有ID参数，可以在这里加载视频详情
      console.log('加载视频ID:', options.id);
    }
  },
  
  onShow() {
    // 页面显示时的处理
    console.log('详情页显示');
  },
  
  onUnload() {
    // 页面卸载时的清理工作
    console.log('详情页卸载');
  }
}) 
data: {
  videoList: [
    // ... 现有视频列表 ...
    {
      id: '新ID', // 可以是数字或字符串，确保与现有ID不重复
      title: '法式以及模版-单色渐变',
      coverUrl: '视频封面图片URL', // 如果有封面图，请替换为实际URL
      videoUrl: 'https://naildidi-1342588805.cos.ap-guangzhou.myqcloud.com/%E5%96%B7%E7%BB%98%E6%95%99%E7%A8%8B/%E6%B3%95%E5%BC%8F%E4%BB%A5%E5%8F%8A%E6%A8%A1%E7%89%88-%E5%8D%95%E8%89%B2%E6%B8%90%E5%8F%981.mp4',
      duration: '00:00', // 视频时长，如果知道请填写
      views: 0,
      uploadTime: '2023-01-01', // 上传日期，请替换为实际日期
      description: '法式以及模版-单色渐变教程' // 视频描述
    }
  ],
  // ... 其他数据 ...
} 
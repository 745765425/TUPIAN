// pages/gallery/gallery.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    galleryItems: [],
    isLoading: false,
    showPreview: false,
    previewImage: null,
    headerState: {
      opacity: 1
    },
    galleryUrls: [],  // 添加这个数组来存储所有图片URL
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    // 检查是否有预加载的数据
    if (app.globalData.gallery?.isComplete) {
      // 使用预加载的数据
      const fileList = app.globalData.gallery.data;
      this.processGalleryData(fileList);
    } else {
      // 如果没有预加载数据,则正常加载
      this.loadGalleryImagesFromStorage();
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    wx.hideTabBar();
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 1
      });
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.refreshGallery();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    if (!this.data.isLoading) {
      this.loadGalleryImagesFromStorage(true);
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
  },

  // 优化的滚动事件处理
  onScrollEvent(e) {
    wx.nextTick(() => {
      const scrollTop = e.detail.scrollTop;
      const opacity = Math.max(0, 1 - (scrollTop / 150));
      this.setData({ 
        'headerState.opacity': opacity
      });
    });
  },

  // 优化的图片加载方法
  async loadGalleryImagesFromStorage() {
    if (this.data.isLoading) return;
    this.setData({ isLoading: true });
    
    try {
        // 1. 调用云函数获取图片列表
        const res = await wx.cloud.callFunction({
            name: 'getGalleryFiles',
            data: { folder: '瀑布流/' }
        });
        console.log('云函数返回数据:', res);

        if (!res.result?.success || !Array.isArray(res.result.data)) {
            throw new Error('获取图片列表失败');
        }

        // 2. 获取系统信息
        const systemInfo = await new Promise((resolve, reject) => {
            wx.getSystemInfo({
                success: resolve,
                fail: reject
            });
        });
        console.log('系统信息:', systemInfo);

        // 3. 处理每个图片
        const imagePromises = res.result.data.map(file => {
            return new Promise((resolve) => {
                console.log('处理图片:', file.url);
                wx.getImageInfo({
                    src: file.url,
                    success: (imgInfo) => {
                        console.log('获取图片信息成功:', file.key, imgInfo);
                        resolve({
                            _id: file.Key,
                            title: file.key,
                            imageUrl: file.url,
                            isVertical: imgInfo.height > imgInfo.width
                        });
                    },
                    fail: (error) => {
                        console.error('获取图片信息失败:', file.key, error);
                        // 即使获取失败也返回基本信息
                        resolve({
                            _id: file.Key,
                            title: file.key,
                            imageUrl: file.url,
                            isVertical: false
                        });
                    }
                });
            });
        });

        // 4. 等待所有图片处理完成
        const items = await Promise.all(imagePromises);
        console.log('所有图片处理完成:', items);

        // 5. 更新页面数据
        this.setData({
            galleryItems: items,
            galleryUrls: items.map(item => item.imageUrl)
        });

    } catch (err) {
        console.error('加载图片失败:', err);
        wx.showToast({
            title: '加载失败',
            icon: 'none'
        });
    } finally {
        this.setData({ isLoading: false });
    }
  },

  // 图片预览相关
  handleImageTap(e) {
    const item = e.currentTarget.dataset.item;
    
    // 禁用页面滚动
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 0
    });
    
    this.setData({
      showPreview: true,
      previewImage: item
    });
  },

  closePreview() {
    this.setData({
      showPreview: false
    });
  },

  // 新的刷新方法
  async refreshGallery() {
    try {
      await this.loadGalleryImagesFromStorage();
      wx.stopPullDownRefresh();
    } catch (err) {
      console.error('刷新失败:', err);
      wx.stopPullDownRefresh();
    }
  },

  // 添加处理数据的方法
  processGalleryData(fileList) {
    console.log('处理图片数据:', fileList);
    if (!fileList || !fileList.length) {
      console.log('没有图片数据');
      this.setData({
        galleryItems: [],
        isLoading: false
      });
      return;
    }

    const imagePromises = fileList.map((file, index) => {
      return new Promise((resolve) => {
        // 如果已经有缓存的尺寸信息
        if (file.dimensions) {
          resolve({
            _id: index.toString(),
            title: file.key,
            imageUrl: file.url,
            isVertical: file.dimensions.height > file.dimensions.width
          });
        } else {
          wx.getImageInfo({
            src: file.url,
            success: (imgInfo) => {
              resolve({
                _id: index.toString(),
                title: file.key,
                imageUrl: file.url,
                isVertical: imgInfo.height > imgInfo.width
              });
            },
            fail: (error) => {
              console.error('获取图片信息失败:', error);
              resolve(null);
            }
          });
        }
      });
    });

    Promise.all(imagePromises).then(items => {
      const validItems = items.filter(item => item !== null);
      console.log('处理后的图片数据:', validItems);
      this.setData({
        galleryItems: validItems,
        galleryUrls: validItems.map(item => item.imageUrl),
        isLoading: false
      });
    });
  },

  onLoad: function() {
    // 调用云函数获取图片列表
    wx.cloud.callFunction({
      name: 'getGalleryFiles',
      data: {
        folder: '瀑布流/'  // 指定文件夹
      }
    }).then(res => {
      console.log('获取图片列表成功:', res);
      if (res.result && res.result.success && res.result.data) {
        // 直接处理返回的文件列表
        this.processGalleryData(res.result.data);
      }
    }).catch(err => {
      console.error('获取图片列表失败:', err);
      this.setData({
        isLoading: false,
        galleryItems: []
      });
    });
  }
})
Page({
  data: {
    isExiting: false,
    canExit: false,
    launchImages: [
      {
        url: 'cloud://...../qidongye1.svg',
        animationClass: 'image1'
      },
      {
        url: 'cloud://...../qidongye2.svg',
        animationClass: 'image2'
      },
      {
        url: 'cloud://...../qidongye3.svg',
        animationClass: 'image3'
      },
      {
        url: 'cloud://...../qidongye4.svg',
        animationClass: 'image4'
      }
    ]
  },

  onLoad() {
    // 3.3秒后允许点击退出
    setTimeout(() => {
      this.setData({ canExit: true });
    }, 3300);
  },

  onTapToEnter() {
    if (!this.data.canExit || this.data.isExiting) return;

    wx.vibrateShort({
      complete: (res) => {
        console.log('震动结果：', res)
      }
    });

    this.setData({ isExiting: true });

    setTimeout(() => {
      wx.switchTab({
        url: '/pages/index/index'
      });
    }, 800);
  }
}); 
// index.js
const { launchConfig, courseConfig } = require('../../utils/config.js');
const zhuyeConfig = require('../../config/zhuye/config.js');

Page({
  data: {
    currentIndex: 0,
    topIndex: 0,
    showLaunch: true,
    launchOpacity: 1,
    courseList: [],  // 初始为空
    launchAnimation: null,
    topSlides: zhuyeConfig.topSlides,
    zhuyeConfig: zhuyeConfig,
    activeIcon: '',  // 当前激活的图标
    iconTapLock: false  // 防止重复点击
  },

  onLoad(options) {
    try {
      // 延迟加载非必要数据
      wx.nextTick(() => {
        this.setData({
          launchImages: launchConfig.launchImages,
          animationConfig: launchConfig.animation,
          styleConfig: launchConfig.style
        });
      });

      // 检查是否需要跳过启动页
      if (options.skip_launch === 'true' || options.showLaunch === 'false') {
        this.setData({
          showLaunch: false
        });
      }

      // 更新列表数据
      this.updateCourseList();
      
      // 预加载详情页资源
      this.preloadDetailPage();
    } catch (error) {
      console.error('onLoad error:', error);
    }
  },

  // 添加更新列表的方法
  updateCourseList() {
    // 重新获取最新的配置
    const courseConfig = require('../../utils/config.js').courseConfig;
    
    const list = courseConfig.list.map((item, index) => ({
      id: index + 1,
      number: String(index + 1),
      bgColor: item.bgColor || '#4DC591',  // 使用配置的背景色或默认颜色
      text: item.text
    }));

    this.setData({ courseList: list });
  },

  // 背景切换事件处理
  onBackgroundChange(e) {
    this.setData({
      currentIndex: e.detail.current
    });
  },

  // 顶部组件切换事件处理
  onTopChange(e) {
    this.setData({
      topIndex: e.detail.current
    });
  },

  // 触摸事件处理
  handleTouchStart() {
    // 创建动画实例
    const animation = wx.createAnimation({
      duration: 1200,  // 增加动画时间
      timingFunction: 'ease-out',
      delay: 0
    });
    
    // 设置渐隐动画
    animation.opacity(0).step();
    
    // 先开始动画
    this.setData({
      launchAnimation: animation.export()
    });

    // 等动画完成后再隐藏
    setTimeout(() => {
      this.setData({
        showLaunch: false
      });
    }, 1200);  // 与动画时间一致
  },

  handleIconTap(e) {
    if (this.iconTapLock) return; // 防止重复点击
    this.iconTapLock = true;
    
    const icon = e.currentTarget.dataset.icon;
    if (this.data.activeIcon) return;
    
    this.setData({ activeIcon: icon });
    
    wx.nextTick(() => {
      setTimeout(() => {
        this.setData({ activeIcon: '' });
        if (icon === 'product') {
          wx.navigateTo({
            url: '/pages/detail/index'
          });
        }
        this.iconTapLock = false; // 解锁点击
      }, 200);
    });
  },

  preloadDetailPage() {
    // 预加载详情页需要的图片等资源
    const preloadImages = [
      'https://cdn.jsdelivr.net/gh/745765425/TUPIAN/2.png'
    ];
    
    Promise.all(preloadImages.map(url => {
      return new Promise((resolve, reject) => {
        wx.getImageInfo({
          src: url,
          success: (res) => resolve(res),
          fail: (err) => reject(err)
        });
      });
    }))
    .then(() => {
      console.log('All images preloaded successfully');
    })
    .catch(error => {
      console.error('Image preload failed:', error);
    });
  },

  onHide() {
    // 页面隐藏时清理内存
    this.setData({
      launchImages: null,
      animationConfig: null,
      styleConfig: null
    });
  }
});

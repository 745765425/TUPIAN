// app.js
App({
  onLaunch(options) {
    // 预加载一些必要资源
    try {
      // 使用新的 API 获取系统信息
      const systemInfo = wx.getAppBaseInfo();
      const deviceInfo = wx.getDeviceInfo();
      const windowInfo = wx.getWindowInfo();
      
      this.globalData.systemInfo = {
        ...systemInfo,
        ...deviceInfo,
        ...windowInfo
      };
      
      // 判断是否为 iPhone X 系列
      this.globalData.isIPhoneX = windowInfo.safeArea && 
        windowInfo.screenHeight - windowInfo.safeArea.bottom > 34;
    } catch (error) {
      console.error('System info error:', error);
    }
  },

  onError(error) {
    console.error('App Error:', error);
    if (error && error.message) {
      wx.showToast({
        title: '遇到一些问题，请稍后重试',
        icon: 'none'
      });
    }
  },

  onPageNotFound() {
    wx.redirectTo({
      url: '/pages/index/index'
    });
  },

  globalData: {
    userInfo: null,
    systemInfo: null,
    isIPhoneX: false
  }
});

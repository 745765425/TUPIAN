// 启动页图片配置文件
// 说明：
// - 可以直接修改图片链接来更换启动页图片
// - 支持添加或删除图片
// - 确保链接可以正常访问
// - 建议使用CDN图片链接
// - 建议使用webp格式以获得更好的加载性能

module.exports = {
  // 启动页图片列表
  launchImages: [
    {
      id: 'launch1',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/%E9%A3%8E%E6%89%8744.webp',
      duration: 3000,
    },
    {
      id: 'launch2',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/5.webp',
      duration: 3000,
    },
    {
      id: 'launch3',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/6.webp',
      duration: 3000,
    }
  ],

  // 动画效果配置
  animation: {
    duration: 800,
    timing: 'ease',
  },

  // 图片样式配置
  style: {
    blur: 0,
    opacity: 1,
    scale: 1.1,
  }
}; 
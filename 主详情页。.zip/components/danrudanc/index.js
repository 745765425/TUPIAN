Component({
  options: {
    pureDataPattern: /^_/, // 优化数据更新性能
    styleIsolation: 'shared', // 优化样式性能
    nativeMode: true  // 启用原生模式提高性能
  },

  properties: {
    interval: {
      type: Number,
      value: 3000  // 总间隔3秒
    },
    currentIndex: {
      type: Number,
      value: 0
    },
    type: {
      type: String,
      value: 'launch' // 'launch' 或 'main'
    }
  },

  data: {
    backgrounds: [
      {
        id: 'launch1',
        url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/%E9%A3%8E%E6%89%8744.webp'
      },
      {
        id: 'launch2',
        url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/5.webp'
      },
      {
        id: 'launch3',
        url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/6.webp'
      }
    ],
    activeIndex: 0,
    _observer: null // pure data
  },

  lifetimes: {
    attached() {
      try {
        this.data._observer = wx.createIntersectionObserver(this, {
          nativeMode: true,  // 启用原生模式
          thresholds: [0, 0.5, 1]  // 优化观察阈值
        });
        this.data._observer
          .relativeToViewport()
          .observe('.background-container', (res) => {
            if (res.intersectionRatio > 0) {
              this.startTransition();
            } else {
              this.stopTransition();
            }
          });
      } catch (error) {
        console.error('attached error:', error);
      }
    },
    detached() {
      try {
        if (this.intervalId) {
          clearInterval(this.intervalId);
          this.intervalId = null;
        }
        if (this.data._observer) {
          this.data._observer.disconnect();
        }
      } catch (error) {
        console.error('detached error:', error);
      }
    }
  },

  methods: {
    startTransition() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
      
      this.intervalId = setInterval(() => {
        try {
          const nextIndex = (this.data.activeIndex + 1) % this.data.backgrounds.length;
          this.setData({
            activeIndex: nextIndex
          });
          this.triggerEvent('change', { current: nextIndex });
        } catch (error) {
          console.error('transition error:', error);
          clearInterval(this.intervalId);
        }
      }, this.data.interval);
    },

    stopTransition() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    }
  }
}); 
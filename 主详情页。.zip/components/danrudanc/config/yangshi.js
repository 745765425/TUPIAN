export default {
  transition: {
    duration: '0.3s',
    timing: 'ease-in-out'
  },
  mask: {
    gradient: {
      start: 'rgba(0,0,0,0.2)',
      end: 'rgba(0,0,0,0.6)'
    }
  }
} 
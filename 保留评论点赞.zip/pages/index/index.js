// index.js
Page({
  data: {
    statusBarHeight: 0, // 状态栏高度
    titleBarHeight: 80, // 标题栏高度（rpx单位）
    videoItem: {
      title: "Devolver Digital: The Return of Volvy",
      authorName: "Blink",
      authorAvatar: "https://placekitten.com/100/100",
      publishTime: "1 year ago",
      coverUrl: "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1000",
      videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
      duration: "17:34",
      specialMark: "SP"
    },
    showNavHeader: true,
    lastScrollTop: 0,
    activeTab: 'video',
    screenHeight: 0, // 屏幕高度
    videoItems: [
      {
        id: 'video-1',
        title: "喷枪基础教程详细说明1",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/200",
        authorName: "喷枪教程",
        publishTime: "1 year ago",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 'video-2',
        title: "喷枪进阶技巧教程",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/201",
        authorName: "喷枪教程",
        publishTime: "2 year ago",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 'video-3',
        title: "喷枪高级应用",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/202",
        authorName: "喷枪教程",
        publishTime: "3 year ago",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 'video-4',
        title: "喷枪实战技巧",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/203",
        authorName: "喷枪教程",
        publishTime: "4 year ago",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 'video-5',
        title: "喷枪作品展示",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/204",
        authorName: "喷枪教程",
        publishTime: "5 year ago",
        specialMark: "SP",
        isInViewCenter: false
      }
    ],
    isScrolling: false,
    scrollTimer: null,
    currentPlayingVideoId: null, // 当前正在播放的视频ID
    showVideoDetail: false,
    selectedVideo: null,
    playerHeight: 300,
    videoError: false,
    safeAreaTop: 0,
    touchStartY: 0, // 触摸开始位置
    isPanelExpanded: true, // 默认为展开状态
    initialPlayerHeight: '45vh', // 初始视频高度
    expandedPlayerHeight: '35vh', // 从30vh增加到35vh，使视频位置更低
    initialTopSpace: 'calc(15vh - 40px)', // 初始顶部空间
    expandedTopSpace: '50px', // 从30px增加到50px，保留更多顶部空间
    videoTransform: 'translateY(0)',
    isSliding: false,
    touchStartX: 0,
    isDragging: false,
    dragThreshold: 50,  // 下拉阈值
    currentVideo: null,
    isDetailShow: false,
    videoList: [
      {
        id: 1,
        title: "喷枪基础教程1",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/200",
        authorName: "喷枪教程",
        publishTime: "2小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 2,
        title: "喷枪基础教程2",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/201",
        authorName: "喷枪教程",
        publishTime: "3小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 3,
        title: "喷枪基础教程3",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/202",
        authorName: "喷枪教程",
        publishTime: "4小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 4,
        title: "喷枪进阶教程1",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/203",
        authorName: "喷枪教程",
        publishTime: "5小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 5,
        title: "喷枪进阶教程2",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/204",
        authorName: "喷枪教程",
        publishTime: "6小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 6,
        title: "喷枪进阶教程3",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/205",
        authorName: "喷枪教程", 
        publishTime: "7小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 7,
        title: "喷枪高级教程1",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/206",
        authorName: "喷枪教程",
        publishTime: "8小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 8,
        title: "喷枪高级教程2",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/207",
        authorName: "喷枪教程",
        publishTime: "9小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 9,
        title: "喷枪高级教程3",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/208",
        authorName: "喷枪教程",
        publishTime: "10小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 10,
        title: "喷枪专业教程1",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/209",
        authorName: "喷枪教程",
        publishTime: "11小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 11,
        title: "喷枪专业教程2",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/210",
        authorName: "喷枪教程",
        publishTime: "12小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 12,
        title: "喷枪专业教程3",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/211",
        authorName: "喷枪教程",
        publishTime: "13小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 13,
        title: "喷枪专业教程4",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/212",
        authorName: "喷枪教程",
        publishTime: "14小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 14,
        title: "喷枪专业教程5",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/213",
        authorName: "喷枪教程",
        publishTime: "15小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 15,
        title: "喷枪专业教程6",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/214",
        authorName: "喷枪教程",
        publishTime: "16小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 16,
        title: "喷枪专业教程7",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/215",
        authorName: "喷枪教程",
        publishTime: "17小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 17,
        title: "喷枪专业教程8",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/216",
        authorName: "喷枪教程",
        publishTime: "18小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 18,
        title: "喷枪专业教程9",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/217",
        authorName: "喷枪教程",
        publishTime: "19小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 19,
        title: "喷枪专业教程10",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/218",
        authorName: "喷枪教程",
        publishTime: "20小时前",
        specialMark: "SP",
        isInViewCenter: false
      },
      {
        id: 20,
        title: "喷枪专业教程11",
        videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
        coverUrl: "https://placekitten.com/300/219",
        authorName: "喷枪教程",
        publishTime: "21小时前",
        specialMark: "SP",
        isInViewCenter: false
      }
    ],
    batchSize: 1,      // 改为1
    startIndex: 0,     // 保持不变
    maxKeepVideos: 1,  // 改为1
    isLoading: false,  // 保持不变
    videos: [],
    hasError: false,
    showLaunch: true,  // 默认显示启动页
    headerOpacity: 1,  // 顶部容器透明度
    headerState: {     // 新增：专门用于管理header状态
      opacity: 1,
      lastScrollTop: 0,
      isHidden: false
    },
    isBottomBarVisible: false,
    hasFirstScroll: false,  // 添加标记，记录是否已经发生过第一次滚动
    initializing: true,  // 添加初始化标记
    currentVideoIndex: 0,
    observer: null
  },
  
  // 修改 fetchVideoItems 方法，只返回一个视频
  fetchVideoItems(startIndex, batchSize) {
    return new Promise((resolve) => {
      const videos = [
        {
          id: 'video-1',
          title: "喷枪基础教程详细说明1",
          authorName: "喷枪教程",
          authorAvatar: "/images/default-avatar.png",
          publishTime: "1 year ago",
          videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
          coverUrl: "https://placekitten.com/300/200",
          specialMark: "SP",
          isInViewCenter: false
        },
        {
          id: 'video-2',
          title: "喷枪进阶技巧教程",
          authorName: "喷枪教程",
          authorAvatar: "/images/default-avatar.png",
          publishTime: "2 year ago",
          videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
          coverUrl: "https://placekitten.com/300/201",
          specialMark: "SP",
          isInViewCenter: false
        },
        {
          id: 'video-3',
          title: "喷枪专业应用实例",
          authorName: "喷枪教程",
          authorAvatar: "/images/default-avatar.png",
          publishTime: "6 months ago",
          videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
          coverUrl: "https://placekitten.com/300/202",
          specialMark: "SP",
          isInViewCenter: false
        },
        {
          id: 'video-4',
          title: "喷枪使用注意事项",
          authorName: "喷枪教程",
          authorAvatar: "/images/default-avatar.png",
          publishTime: "3 months ago",
          videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
          coverUrl: "https://placekitten.com/300/203",
          specialMark: "SP",
          isInViewCenter: false
        },
        {
          id: 'video-5',
          title: "喷枪维护保养指南",
          authorName: "喷枪教程",
          authorAvatar: "/images/default-avatar.png",
          publishTime: "1 month ago",
          videoUrl: "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4",
          coverUrl: "https://placekitten.com/300/204",
          specialMark: "SP",
          isInViewCenter: false
        }
      ];
      resolve(videos);
    });
  },
  
  onLoad() {
    console.log('===== 页面加载 =====');
    // 隐藏 TabBar
    wx.hideTabBar();
    
    // 使用新的API替代wx.getSystemInfoSync
    const windowInfo = wx.getWindowInfo();
    const systemInfo = wx.getDeviceInfo();
    const appBaseInfo = wx.getAppBaseInfo();
    
    const statusBarHeight = windowInfo.statusBarHeight;
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
    const menuButtonHeight = menuButtonInfo.height;
    const menuButtonTop = menuButtonInfo.top;
    
    // 计算安全区域高度
    const safeAreaTop = menuButtonTop + menuButtonHeight + 10;
    
    // 初始化时不执行视频检测
    this.data.initializing = true;
    
    this.setData({
      statusBarHeight: statusBarHeight,
      screenHeight: windowInfo.windowHeight,
      safeAreaTop: safeAreaTop,
      isDetailShow: false,
      hasFirstScroll: false,
      initializing: true,  // 添加初始化标记
      // 添加初始状态，防止自动播放
      videoItems: this.data.videoItems.map(item => ({
        ...item,
        isInViewCenter: false,
        isPlaying: false,
        preventAutoPlay: true
      })),
      isBottomBarVisible: true  // 确保底部栏可见
    });
    
    // 设置导航栏为透明
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: 'transparent',
      animation: {
        duration: 0,
        timingFunc: 'easeIn'
      }
    });
    
    // 首次加载20个视频
    this.loadNextBatch();
    this.fetchVideos();

    // 设置第一个视频为播放状态
    this.setData({
      [`videoList[0].isInViewCenter`]: true
    }, () => {
      console.log('onLoad: 已设置第一个视频为播放状态');
    });

    // 创建视频检测器
    this.createVideoObserver();
  },
  
  onReady() {
    console.log('===== 页面准备完成 =====');
    // 页面加载完成后检查初始视频可视状态
    this.checkVideoVisibility();
    console.log('已执行初始视频检查');
  },
  
  // 在 pages/index/index.js 中实现滚动事件处理
  onScrollEvent(e) {
    const scrollTop = e.detail.scrollTop;
    
    // 处理顶部容器透明度
    const opacity = Math.max(0, 1 - (scrollTop / 150));
    this.setData({ 
      isScrolling: true,
      'headerState.opacity': opacity
    });
    
    // 立即检测视频位置并暂停不在中心的视频
    this.checkVideoInView(true);
    
    // 清除之前的定时器
    if (this.scrollTimer) {
      clearTimeout(this.scrollTimer);
    }
    
    // 设置滚动停止检测
    this.scrollTimer = setTimeout(() => {
      this.setData({ 
        isScrolling: false 
      }, () => {
        this.checkVideoInView(false);
      });
    }, 100);
  },
  
  // 优化视频检测逻辑
  checkVideoInView(isScrolling) {
    const query = wx.createSelectorQuery();
    query.selectAll('.video-card-item').boundingClientRect((rects) => {
      if (!rects || rects.length === 0) return;
      
      const windowInfo = wx.getWindowInfo();
      // 将中心点向下移动屏幕高度的10%
      const centerY = (windowInfo.windowHeight / 2) + (windowInfo.windowHeight * 0.1);
      // 缩小检测范围为屏幕高度的1/5（原来是1/4）
      const threshold = windowInfo.windowHeight / 5;
      
      // 找到最接近中心的视频
      let bestVideo = null;
      let minDistance = Infinity;
      
      rects.forEach((rect, index) => {
        const videoCenter = rect.top + rect.height / 2;
        const distanceToCenter = Math.abs(videoCenter - centerY);
        
        // 更新最接近中心的视频
        if (distanceToCenter < threshold && distanceToCenter < minDistance) {
          minDistance = distanceToCenter;
          bestVideo = index;
        }
        
        // 这里只是设置 isInViewCenter 为 false，不应该导致重置
        if (distanceToCenter >= threshold && this.data.videoList[index].isInViewCenter) {
          this.setData({
            [`videoList[${index}].isInViewCenter`]: false
          });
        }
      });

      // 只有在完全停止滚动且找到合适的视频时才播放
      if (!isScrolling && bestVideo !== null) {
        this.setData({
          [`videoList[${bestVideo}].isInViewCenter`]: true
        });
      }
    }).exec();
  },
  
  // 暂停所有视频
  pauseAllVideos() {
    const updatedItems = this.data.videoItems.map(item => ({
      ...item,
      isInViewCenter: false,
      keepVideoVisible: true
    }));
    
    this.setData({
      videoItems: updatedItems
    });
  },
  
  // 暂停指定ID的视频
  pauseVideoById(videoId) {
    const videoComponentId = `video-component-${videoId}`;
    const videoComponent = this.selectComponent(`#${videoComponentId}`);
    
    if (videoComponent) {
      videoComponent.pauseVideo();
    }
  },
  
  onVideoPlay(e) {
    const videoId = e.detail.videoId;
    
    // 如果详情页打开，阻止所有视频播放
    if (this.data.isDetailShow) {
      console.log('详情页打开，阻止视频:', videoId, '播放');
      this.stopAllVideos();
      return;
    }
    
    this.setData({
      currentPlayingVideoId: videoId
    });
  },
  
  onVideoPause(e) {
    const videoId = e.detail.videoId;
    console.log('视频暂停:', videoId);
    
    // 如果暂停的是当前播放的视频，清除当前播放视频ID
    if (videoId === this.data.currentPlayingVideoId) {
      this.setData({
        currentPlayingVideoId: null
      });
    }
  },
  
  onVideoEnd(e) {
    console.log('视频播放结束');
  },
  
  // 停止所有视频
  stopAllVideos() {
    const updatedItems = this.data.videoItems.map(item => ({
      ...item,
      isInViewCenter: false,
      keepVideoVisible: true
    }));
    
    this.setData({
      videoItems: updatedItems
    });
  },
  
  // 修改切换标签方法，添加调试日志
  switchTab(e) {
    console.log('switchTab triggered', e.currentTarget.dataset.tab);  // 添加日志
    const tab = e.currentTarget.dataset.tab;
    
    if (tab === 'document') {
      wx.navigateTo({
        url: '/pages/gallery/gallery',
        success: () => {
          console.log('成功跳转到图片页面');  // 添加日志
          this.setData({
            activeTab: 'document'
          });
        },
        fail: (err) => {
          console.error('跳转失败:', err);  // 添加错误日志
        }
      });
    } else {
      this.setData({
        activeTab: 'video'
      });
    }
  },
  
  // 处理分享事件
  onVideoShare(e) {
    const shareInfo = e.detail;
    console.log('准备分享视频:', shareInfo);
    
    // 调用微信分享API
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },
  
  // 用户点击右上角分享或使用分享按钮时触发
  onShareAppMessage(res) {
    console.log('分享事件触发', res);
    
    // 来自页面内分享按钮
    if (res.from === 'button' && res.target && res.target.dataset.videoInfo) {
      const videoInfo = res.target.dataset.videoInfo;
      console.log('分享视频信息:', videoInfo);
      
      return {
        title: videoInfo.title || '精彩视频分享',
        imageUrl: videoInfo.coverUrl,
        path: `/pages/index/index?video_id=${videoInfo.id}`
      };
    }
    
    // 默认分享内容
    return {
      title: '精彩视频集锦',
      path: '/pages/index/index'
    };
  },
  
  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '精彩视频集锦',
      query: '',
      imageUrl: ''
    };
  },
  
  // 处理视频卡片点击
  onVideoCardTap(e) {
    const { videoId } = e.detail;
    // 找到对应的视频信息
    const videoInfo = this.data.videoList.find(v => v.id === videoId);
    
    if (videoInfo) {
      console.log('准备显示视频详情:', videoInfo);
      this.setData({
        currentVideo: videoInfo,
        isDetailShow: true
      });
    }
  },
  
  // 修改详情页关闭处理
  onDetailClose() {
    console.log('关闭详情页');
    
    // 恢复底部栏的层级和透明度
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        isDetailOpen: false  // 详情页关闭
      });
    }
    
    this.setData({
      isDetailShow: false,
      currentVideo: null
    }, () => {
      setTimeout(() => {
        this.checkVideoVisibility();
      }, 100);
    });
  },
  
  // 防止冒泡
  preventBubble() {
    return false;
  },
  
  // 视频错误处理
  onDetailVideoError(e) {
    console.error('视频加载错误:', e);
    this.setData({
      videoError: true
    });
  },
  
  // 重新加载视频 - 优化版本
  reloadVideo() {
    this.setData({
      videoError: false
    });
    
    // 使用nextTick确保DOM更新后再操作视频
    wx.nextTick(() => {
      const videoContext = wx.createVideoContext('detail-video');
      videoContext.play();
    });
  },
  
  // 开始滑动时
  panelTouchStart(e) {
    if (e.touches.length !== 1) return; // 只处理单指触摸
    
    this.setData({
      touchStartY: e.touches[0].clientY,
      isSliding: true
    });
    
    // 暂时暂停视频
    const videoContext = wx.createVideoContext('detail-video');
    videoContext.pause();
  },
  
  // 滑动结束时
  panelTouchEnd() {
    if (this.touchMoveTimer) {
      clearTimeout(this.touchMoveTimer);
      this.touchMoveTimer = null;
    }
    
    this.setData({
      isSliding: false
    });
    
    // 恢复视频播放
    if (this.data.selectedVideo && !this.data.videoError) {
      const videoContext = wx.createVideoContext('detail-video');
      videoContext.play();
    }
  },
  
  // 简化触摸处理
  panelTouchMove(e) {
    if (!this.data.isSliding || e.touches.length !== 1) return;
    
    const touchMoveY = e.touches[0].clientY;
    const moveDistance = this.data.touchStartY - touchMoveY;
    
    // 只处理向下滑动关闭，并添加阈值判断
    if (moveDistance < -50 && Math.abs(moveDistance) > 30) {
      // 先暂停视频，减轻关闭过程中的性能压力
      const videoContext = wx.createVideoContext('detail-video');
      videoContext.pause();
      
      // 关闭弹窗
      this.onDetailClose();
    }
  },
  
  // 视频详情页面显示时
  onDetailVideoPlay() {
    console.log('详情视频开始播放');
    // 可以在这里做一些优化，比如降低其他元素的动画频率
  },
  
  // 修改页面显示事件
  onShow() {
    // 隐藏原生TabBar
    wx.hideTabBar();
    
    // 更新自定义TabBar选中状态
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 0
      });
    }

    // 恢复之前保存的header状态
    const headerState = this.data.headerState;
    this.setData({
      headerOpacity: headerState.opacity
    });

    // 页面显示时检查视频可见性
    setTimeout(() => {
      this.checkVideoVisibility();
    }, 300);
  },
  
  onHide() {
    // 保持header状态不变
    // 其他清理工作继续执行
    this.stopAllVideos();
    
    if (this.data.showVideoDetail) {
      const videoContext = wx.createVideoContext('detail-video');
      videoContext.pause();
    }
  },
  
  // 简化预加载方法
  preloadVideoCovers() {
    if (this.data.videoItems && this.data.videoItems.length > 0) {
      const item = this.data.videoItems[0];
      wx.getImageInfo({
        src: item.coverUrl,
        success: () => console.log('预加载封面成功:', item.id),
        fail: () => console.log('预加载封面失败:', item.id)
      });
    }
  },
  
  // 在页面卸载时清理资源
  onUnload() {
    // 重置header状态
    this.setData({
      headerState: {
        opacity: 1,
        lastScrollTop: 0,
        isHidden: false
      },
      headerOpacity: 1
    });

    // 清理其他资源
    if (this.scrollTimer) {
      clearTimeout(this.scrollTimer);
    }
    
    if (this.touchMoveTimer) {
      clearTimeout(this.touchMoveTimer);
    }
    
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
  },
  
  // 触摸开始
  handlePopupTouch(e) {
    // 记录起始触摸点
    this.setData({
      touchStartY: e.touches[0].clientY,
      touchStartX: e.touches[0].pageX,
      isDragging: false
    });
  },
  
  // 触摸移动
  handlePopupMove(e) {
    const deltaY = e.touches[0].clientY - this.data.touchStartY;
    const deltaX = e.touches[0].pageX - this.data.touchStartX;
    
    // 只有当垂直移动距离大于水平移动距离，且是向下滑动时才处理
    if (Math.abs(deltaY) > Math.abs(deltaX) && deltaY > 0) {
      this.setData({
        isDragging: true
      });
    }
  },
  
  // 触摸结束
  handlePopupEnd(e) {
    if (this.data.isDragging) {
      const deltaY = e.changedTouches[0].clientY - this.data.touchStartY;
      if (deltaY > this.data.dragThreshold) {
        this.onDetailClose();
      }
    }
    this.setData({
      isDragging: false
    });
  },
  
  // 修改 loadNextBatch 方法，只加载一次
  async loadNextBatch() {
    if (this.data.isLoading || this.data.videoItems.length > 0) return; // 如果已有视频或正在加载，则不再加载
    this.setData({ isLoading: true });

    try {
      const sampleVideo = await this.fetchVideoItems(0, 1);
      
      this.setData({
        videoItems: sampleVideo,
        isLoading: false
      });
    } catch (error) {
      console.error('加载视频失败:', error);
      this.setData({ isLoading: false });
    }
  },
  
  // 简化 onReachBottom 方法
  onReachBottom() {
    // 不再加载更多视频
  },
  
  // 简化视频资源管理方法
  handleVideoResource() {
    // 只有一个视频，不需要复杂的资源管理
  },
  
  // 简化资源优化方法
  optimizeVideoResources() {
    // 只有一个视频，不需要复杂的优化
  },
  
  // 获取视频列表
  fetchVideos: function() {
    this.setData({ isLoading: true, hasError: false });
    
    // 临时使用模拟数据
    setTimeout(() => {
      this.setData({
        videos: [
          {
            id: 'video-1',
            title: '喷枪基础教程详细说明',
            description: '专业喷枪使用教程',
            videoUrl: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4',
            coverUrl: '../../images/video-cover.png',
            author: {
              id: 'author-1',
              name: '喷枪宣传视频',
              avatar: '../../images/default-avatar.png'
            },
            stats: {
              likes: 128,
              comments: 15,
              shares: 5
            }
          }
          // 可以添加更多视频
        ],
        isLoading: false
      });
    }, 1000);
  },
  
  // 处理视频点击事件
  handleVideoTap: function(e) {
    const videoId = e.currentTarget.dataset.id;
    const videoInfo = this.data.videos.find(v => v.id === videoId);
    
    // 获取视频详情组件实例
    const videoDetailComponent = this.selectComponent('#videoDetail');
    if (videoDetailComponent) {
      videoDetailComponent.show(videoInfo);
    }
  },
  
  // 修改启动页关闭处理
  onLaunchClose() {
    console.log('===== 启动页关闭 =====');
    this.setData({
      showLaunch: false
    }, () => {
      // 这里重新检测并强制设置第一个视频播放
      setTimeout(() => {
        this.checkVideoInView();  // 这里可能导致重置
        this.setData({
          [`videoList[0].isInViewCenter`]: true
        });
      }, 100);
    });
  },
  
  // 修改视频可见性检测方法
  checkVideoVisibility() {
    console.log('===== 检查视频可见性 =====');
    if (this.data.videoList && this.data.videoList.length > 0) {
      console.log('当前视频列表状态:', this.data.videoList.map(v => ({
        id: v.id,
        isInViewCenter: v.isInViewCenter
      })));
    }
    this.checkVideoInView();
  },
  
  // 添加暂停所有视频的方法
  pauseAllVideos() {
    const updatedItems = this.data.videoItems.map(item => ({
      ...item,
      isInViewCenter: false,
      keepVideoVisible: true
    }));
    
    this.setData({
      videoItems: updatedItems
    });
  },
  
  attached() {
    // 使用新的 API 获取系统信息
    const windowInfo = wx.getWindowInfo();
    const appBaseInfo = wx.getAppBaseInfo();
    
    this.setData({
      screenHeight: windowInfo.windowHeight,
      // ... 其他设置
    });
  },
  
  // 添加视频错误处理
  onVideoError(e) {
    console.error('视频加载失败:', e);
    const videoId = e.currentTarget.dataset.id;
    // 可以在这里添加重试逻辑或显示错误提示
  },

  // 创建视频检测器
  createVideoObserver() {
    // 不再使用 IntersectionObserver
  },
})

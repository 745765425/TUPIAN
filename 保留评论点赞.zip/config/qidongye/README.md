# 启动页配置说明

## 文件位置
配置文件位置：`config/qidongye/images.js`

## 如何修改图片
1. 用记事本打开 `images.js` 文件 

## 图片配置
- 需要准备3张图片
- 图片尺寸建议: 750×1624像素
- 图片格式建议: webp
- 图片大小建议: 300KB以内

## 动画配置
- firstImage: 2.5秒淡出动画
- secondImage: 1.5秒淡入动画(0.9秒后开始)
- thirdImage: 1.5秒淡入动画(2.5秒后开始)

## 图片链接
当前使用的图片链接:
1. http://ssdue7pv4.hn-bkt.clouddn.com/%E5%90%AF%E5%8A%A8%E9%A1%B5/%E5%90%AF%E5%8A%A8%E9%A1%B51.webp
2. http://ssdue7pv4.hn-bkt.clouddn.com/%E5%90%AF%E5%8A%A8%E9%A1%B5/%E5%90%AF%E5%8A%A8%E9%A1%B52.webp
3. http://ssdue7pv4.hn-bkt.clouddn.com/%E5%90%AF%E5%8A%A8%E9%A1%B5/%E5%90%AF%E5%8A%A8%E9%A1%B53.webp 
// app.js
// var unusedVar = 123;   // 使用 var 而不是 let/const
// function emptyFunc() { }  // 空函数
// function duplicateFunc() { }
// function duplicateFunc() { }  // 重复的函数声明

App({
  globalData: {
    // 数据存储
    gallery: {
      data: null,        // 替代 preloadedGallery
      isComplete: false, // 替代 galleryLoadComplete
      hasMore: false    // 替代 hasMoreGalleryImages
    },
    
    // 加载状态管理
    video: {
      data: null,
      loadState: {
        firstLoaded: false,
        isLoadingRest: false
      }
    },
    
    // 用户信息
    userInfo: null,
    isAdmin: false,
    isPreloading: false  // 移到顶层
  },

  onLaunch: function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // env 参数决定接下来小程序发起的云开发调用会默认请求到哪个云环境的资源
        env: 'nail-spray-cloud-1f7k6g24bb56801', // 确认这是正确的环境ID
        traceUser: true,
      })
    }

    // 确保启动时清除所有旧数据
    this.clearAllData();

    // 确保TabBar始终隐藏
    this.ensureTabBarHidden();

    // 启动预加载
    this.startPreload();
  },
  
  // 添加页面显示时的处理
  onShow: function() {
    // 确保每次页面显示时都隐藏原生TabBar
    this.ensureTabBarHidden();
  },
  
  // 检查用户是否为管理员
  checkAdmin: function(callback) {
    wx.cloud.callFunction({
      name: 'checkAdmin',
      success: res => {
        console.log('检查管理员结果:', res.result)
        const isAdmin = res.result && res.result.isAdmin === true ? true : false
        this.globalData.isAdmin = isAdmin
        if (callback) callback(isAdmin)
      },
      fail: err => {
        console.error('检查管理员权限失败', err)
        this.globalData.isAdmin = false
        if (callback) callback(false)
      }
    })
  },

  // 添加全局图片工具
  imageUtil: {
    // 分析图片尺寸并返回布局信息
    analyzeImageSize(url) {
      return new Promise((resolve) => {
        wx.getImageInfo({
          src: url,
          success: (res) => {
            const { width, height } = res;
            const ratio = height / width;
            
            // 根据图片比例决定布局方式
            const layoutInfo = {
              isVertical: ratio > 1.2,  // 高宽比大于1.2认为是竖图
              isHorizontal: ratio < 0.8,  // 高宽比小于0.8认为是横图
              isSquare: ratio >= 0.8 && ratio <= 1.2,  // 接近正方形
              ratio: ratio,
              originalWidth: width,
              originalHeight: height
            };
            
            resolve(layoutInfo);
          },
          fail: (err) => this.handleError(err, 'analyzeImageSize')
        });
      });
    }
  },

  // 预加载方法
  async startPreload() {
    if (this.globalData.isPreloading) return;
    this.globalData.isPreloading = true;

    try {
      await this.preloadGallery();  // 只预加载图片
      await this.preloadVideos();   // 然后预加载视频
    } catch (err) {
      console.error('预加载失败:', err);
    } finally {
      this.globalData.isPreloading = false;
    }
  },

  // 添加完整的数据清理方法
  clearAllData() {
    // 清除全局数据
    this.globalData.gallery.data = null;
    this.globalData.gallery.isComplete = false;
    this.globalData.gallery.hasMore = false;
    
    // 清除本地存储
    try {
      wx.clearStorageSync();
    } catch(e) {
      console.error('清除存储失败:', e);
    }
  },

  // 预加载图片库
  async preloadGallery() {
    try {
      const galleryData = [
        {
          id: 'image-1',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8001.JPG',
          title: '喷枪作品展示1'
        },
        {
          id: 'image-2',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8002.JPG',
          title: '喷枪作品展示2'
        },
        {
          id: 'image-3',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8003.JPG', 
          title: '喷枪作品展示3'
        },
        {
          id: 'image-4',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8004.JPG',
          title: '喷枪作品展示4'
        },
        {
          id: 'image-5',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8005.JPG',
          title: '喷枪作品展示5'
        },
        {
          id: 'image-6',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8006.JPG',
          title: '喷枪作品展示6'
        },
        {
          id: 'image-7',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8008.JPG',
          title: '喷枪作品展示7'
        },
        {
          id: 'image-8',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8009.JPG',
          title: '喷枪作品展示8'
        },
        {
          id: 'image-9',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8010.JPG',
          title: '喷枪作品展示9'
        },
        {
          id: 'image-10',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8011.JPG',
          title: '喷枪作品展示10'
        },
        {
          id: 'image-11',
          imageUrl: 'http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8012.JPG',
          title: '喷枪作品展示11'
        }
      ];

      // 直接设置数据，不要用对象赋值
      this.globalData.gallery.data = galleryData;
      this.globalData.gallery.isComplete = true;
      this.globalData.gallery.hasMore = false;

      // 添加日志确认数据
      console.log('预加载图片完成:', this.globalData.gallery.data);
    } catch (err) {
      console.error('预加载图片失败:', err);
      this.globalData.gallery.data = [];
    }
  },

  // 预加载视频列表
  async preloadVideos() {
    try {
      const videoData = [
        {
          id: 'video-1',
          videoUrl: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4',
          title: '喷枪基础教程1',
          authorName: "喷枪教程",
          publishTime: "2小时前",
          specialMark: "SP"
        },
        {
          id: 'video-2',
          videoUrl: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4',
          title: '喷枪基础教程2',
          authorName: "喷枪教程",
          publishTime: "3小时前",
          specialMark: "SP"
        },
        {
          id: 'video-3',
          videoUrl: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4',
          title: '喷枪基础教程3',
          authorName: "喷枪教程",
          publishTime: "4小时前",
          specialMark: "SP"
        },
        {
          id: 'video-4',
          videoUrl: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4',
          title: '喷枪进阶教程1',
          authorName: "喷枪教程",
          publishTime: "5小时前",
          specialMark: "SP"
        },
        {
          id: 'video-5',
          videoUrl: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%96%B7%E6%9E%AA%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91/%E5%92%AFgo.mp4',
          title: '喷枪进阶教程2',
          authorName: "喷枪教程",
          publishTime: "6小时前",
          specialMark: "SP"
        }
      ];

      // 修改这里,不要覆盖 gallery 数据
      this.globalData.video.data = videoData;

    } catch (err) {
      console.error('预加载视频失败:', err);
      this.globalData.video.data = [];
    }
  },

  // 合并视频预加载的公共逻辑
  async preloadVideo(videoContext, duration = 100) {
    return new Promise((resolve) => {
      videoContext.play();
      videoContext.seek(0);
      setTimeout(() => {
        videoContext.pause();
        resolve();
      }, duration);
    });
  },

  // 修改预加载第一个视频的方法
  async preloadFirstVideo(videoInfo) {
    if (this.globalData.video.loadState.firstLoaded) return;
    
    try {
      const videoContext = wx.createVideoContext('preload-video');
      await this.preloadVideo(videoContext);
      this.globalData.video.loadState.firstLoaded = true;
      return videoInfo;
    } catch (err) {
      return this.handleError(err, 'preloadFirstVideo');
    }
  },

  // 修改预加载其他视频的方法
  async preloadRestVideos(videos) {
    if (this.globalData.video.loadState.isLoadingRest) return;
    this.globalData.video.loadState.isLoadingRest = true;
    
    for (const video of videos) {
      try {
        const videoContext = wx.createVideoContext(`preload-video-${video.id}`);
        await this.preloadVideo(videoContext);
      } catch (err) {
        this.handleError(err, `preloadVideo:${video.id}`);
      }
    }
    
    this.globalData.video.loadState.isLoadingRest = false;
  },

  onScrollEvent(e) {
    const scrollTop = e.detail.scrollTop;
    
    // 处理顶部容器透明度
    const opacity = Math.max(0, 1 - (scrollTop / 150));
    this.setData({ 
      isScrolling: true,
      'headerState.opacity': opacity
    });
    
    // 立即检测视频位置并暂停不在中心的视频
    this.checkVideoInView(true);
    
    // 清除之前的定时器
    if (this.scrollTimer) {
      clearTimeout(this.scrollTimer);
    }
    
    // 设置滚动停止检测
    this.scrollTimer = setTimeout(() => {
      this.setData({ 
        isScrolling: false 
      }, () => {
        this.checkVideoInView(false);
      });
    }, 100);
  },

  // 在 app.js 中添加工具方法
  getSystemInfo() {
    return {
      windowInfo: wx.getWindowInfo(),
      deviceInfo: wx.getDeviceInfo(),
      appBaseInfo: wx.getAppBaseInfo()
    };
  },

  // 修改建议：创建一个统一的方法
  ensureTabBarHidden: function() {
    wx.hideTabBar();
  },

  // 添加统一的错误处理方法
  handleError: function(error, context) {
    console.error(`[${context}]错误:`, error);
    return null;
  },
})

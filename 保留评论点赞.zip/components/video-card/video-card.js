Component({
  options: {
    multipleSlots: true // 启用多slot支持
  },
  /**
   * 组件的属性列表
   */
  properties: {
    videoInfo: {
      type: Object,
      value: {}
    },
    extClass: {
      type: String,
      value: ''
    },
    borderRadius: {
      type: String,
      value: '12px'
    },
    // 修改属性：是否在视口中心
    isInViewCenter: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        if (!this.videoContext) {
          this.videoContext = wx.createVideoContext(`video-${this.data.videoInfo.id}`, this);
        }
        
        if (newVal) {
          this.videoContext.play();
          this.setData({ 
            isPlaying: true,
            keepVideoVisible: true
          });
        } else {
          this.videoContext.pause();
          this.setData({
            isPlaying: false,
            keepVideoVisible: true
          });
        }
      }
    },
    isDetailShow: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        if (newVal) {
          // 详情页打开时，只暂停视频，保持可见性
          this.pauseVideo();
          if (this.playTimer) {
            clearTimeout(this.playTimer);
            this.playTimer = null;
          }
        }
      }
    },
    autoPlayDisabled: {
      type: Boolean,
      value: false
    },
    preventAutoPlay: {
      type: Boolean,
      value: true  // 默认阻止自动播放
    },
    isInView: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        if (newVal) {
          setTimeout(() => {
            this.autoPlayVideo();
          }, 100); // 添加短暂延时确保视频上下文已创建
        } else {
          this.pauseVideo();
        }
      }
    },
    isFirstVideo: {
      type: Boolean,
      value: false
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    isPlaying: false,
    showControls: false,
    videoContext: null,
    keepVideoVisible: false, // 新增状态，表示保持视频可见
    isMuted: true, // 默认静音
    posterVideoContext: null, // 新增属性，用于存储封面视频上下文
    showReplayButton: false,  // 添加重播按钮显示状态
    playTimer: null,  // 添加播放定时器
    windowHeight: 0
  },
  lifetimes: {
    attached() {
      if (!this.videoContext) {
        this.videoContext = wx.createVideoContext(`video-${this.data.videoInfo.id}`, this);
      }
      
      try {
        const windowInfo = wx.getWindowInfo();
        this.setData({
          windowHeight: windowInfo.windowHeight
        });
      } catch (error) {
        console.error('获取窗口信息失败:', error);
      }
    },
    detached() {
      if (this.videoContext) {
        this.videoContext.pause();
      }
      
      if (this.playTimer) {
        clearTimeout(this.playTimer);
        this.playTimer = null;
      }
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    // 播放视频
    playVideo() {
      if (!this.videoContext) {
        this.videoContext = wx.createVideoContext(`video-${this.data.videoInfo.id}`, this);
      }
      
      if (this.videoContext) {
        this.setData({ 
          isPlaying: true,
          keepVideoVisible: true
        }, () => {
          this.videoContext.play();
        });
      }
    },
    
    // 暂停视频
    pauseVideo() {
      if (this.videoContext && this.data.isPlaying) {
        this.videoContext.pause();
        this.setData({
          isPlaying: false,
          keepVideoVisible: true
        });
      }
    },
    
    // 视频播放结束
    videoEnd() {
      this.setData({
        isPlaying: false,
        keepVideoVisible: true,
        showReplayButton: true
      });
      // 触发结束事件
      this.triggerEvent('videoend');
    },
    
    // 点击视频卡片
    onTap() {
      // 点击时立即暂停当前视频
      if (this.data.isPlaying) {
        this.pauseVideo();
      }
      
      // 触发卡片点击事件
      this.onCardTap();
    },
    
    // 修改showMore方法为分享功能
    showMore() {
      // 触发自定义分享事件，传递当前视频信息
      this.triggerEvent('share', { 
        videoId: this.data.videoInfo.id,
        title: this.data.videoInfo.title,
        imageUrl: this.data.videoInfo.coverUrl,
        path: `/pages/video-detail/video-detail?id=${this.data.videoInfo.id}`
      });
    },
    
    // 修改切换静音状态的方法
    toggleMute(e) {
      // 检查事件对象是否存在并有stopPropagation方法
      if (e && typeof e.stopPropagation === 'function') {
        // 阻止事件冒泡，避免触发视频的点击事件
        e.stopPropagation();
      }
      
      // 切换静音状态
      const newMuteState = !this.data.isMuted;
      
      // 更新状态
      this.setData({
        isMuted: newMuteState
      }, () => {
      });
    },
    
    // 修改 onCardTap 方法
    onCardTap() {
      this.triggerEvent('cardtap', { 
        videoId: this.data.videoInfo.id 
      });
    },
    
    // 修改重播方法
    replayVideo() {
      console.log('重播按钮被点击');

      // 先创建视频上下文
      this.videoContext = wx.createVideoContext('video-' + this.data.videoInfo.id, this);
      
      // 重置状态并重新播放
      this.setData({
        isPlaying: true,
        showReplayButton: false,
        keepVideoVisible: true
      }, () => {
        this.videoContext.seek(0);
        setTimeout(() => {
          this.videoContext.play();
        }, 100);
      });
    },
    
    // 修改视频错误处理
    onVideoError(error) {
      console.error('视频播放错误:', error);
      this.triggerEvent('videoError', { error });
    }
  }
}) 
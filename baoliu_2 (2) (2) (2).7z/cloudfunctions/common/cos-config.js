// 从小程序配置中获取COS配置
const cloud = require('wx-server-sdk');
cloud.init();

// 获取COS配置的函数
async function getCosConfig() {
  try {
    // 从云数据库中获取配置
    const db = cloud.database();
    const configCollection = db.collection('system_config');
    const configDoc = await configCollection.doc('cos_config').get();
    
    if (configDoc && configDoc.data) {
      return configDoc.data;
    }
    
    // 如果云数据库中没有配置，返回默认配置
    return {
      secretId: process.env.COS_SECRET_ID || '',
      secretKey: process.env.COS_SECRET_KEY || '',
      region: process.env.COS_REGION || 'ap-guangzhou',
      bucket: process.env.COS_BUCKET || '',
    };
  } catch (error) {
    console.error('获取COS配置失败:', error);
    
    // 出错时返回环境变量中的配置
    return {
      secretId: process.env.COS_SECRET_ID || '',
      secretKey: process.env.COS_SECRET_KEY || '',
      region: process.env.COS_REGION || 'ap-guangzhou',
      bucket: process.env.COS_BUCKET || '',
    };
  }
}

module.exports = {
  getCosConfig
}; 
// 云函数共享配置
module.exports = {
  collections: {
    videos: 'videos',     // 视频集合名称
    users: 'users',       // 用户集合名称
    comments: 'comments'  // 评论集合名称
  }
}; 
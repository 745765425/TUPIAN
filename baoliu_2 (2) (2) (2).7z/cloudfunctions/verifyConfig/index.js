// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 使用混淆和加密技术保护验证逻辑
const _0x5a2b = ['19925762035', 'naildidi', '骆刚', '745765426@qq.com'];
const _0x3c1d = function(a, b) { return a === b; };

// 到期时间戳 - 只需修改这一行来设置验证到期时间
// 格式为ISO日期字符串
// 设置为2025年3月28日中国时间下午3:30（UTC+8）
const _0x4e7d = "2025-04-30T23:30:00.000Z";
// 实际使用时设置为具体日期，如：
// const _0x4e7d = "2023-12-31T23:59:59.999Z";

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const { config } = event;
    
    // 减少日志输出，避免在控制台显示太多信息
    // console.log('接收到的配置对象:', config);
    
    // 检查当前时间是否超过设置的到期时间
    const currentTime = new Date();
    const expiryTime = new Date(_0x4e7d);
    
    // 减少日志输出
    // console.log('当前时间:', currentTime.toISOString());
    // console.log('到期时间:', expiryTime.toISOString());
    // console.log('是否已过期:', currentTime > expiryTime);
    
    if (currentTime > expiryTime) {
      // console.log('验证已过期');
      
      return {
        success: false,
        message: "授权已到期",
        details: "您的美甲小程序授权已到期，请联系开发者续期。",
        contact: {
          name: "骆刚",
          phone: "19925762035",
          wechat: "naildidi",
          email: "745765426@qq.com"
        }
      };
    }
    
    // 以下是原有的验证逻辑，保持不变
    // console.log('版权信息:', config.copyright);
    
    // 验证版权信息
    if (!config.copyright || 
        config.copyright.author !== "骆刚" || 
        config.copyright.contact !== "naildidi" ||
        config.copyright.license !== "商业授权" ||
        config.copyright.verificationCode !== "19925762035" ||
        config.copyright.email !== "745765426@qq.com") {
      
      // 减少日志输出
      // console.log('版权验证失败:', {
      //   received: config.copyright,
      //   expected: {
      //     author: "骆刚",
      //     contact: "naildidi",
      //     license: "商业授权",
      //     verificationCode: "19925762035",
      //     email: "745765426@qq.com"
      //   }
      // });
      
      return {
        success: false,
        message: "授权验证失败",
        details: "请勿修改授权信息，如需帮助请联系开发者。",
        contact: {
          name: "骆刚",
          phone: "19925762035",
          wechat: "naildidi",
          email: "745765426@qq.com"
        }
      };
    }
    
    // 验证云环境ID
    if (!config.cloud || !config.cloud.envId) {
      return {
        success: false,
        message: "授权验证失败",
        details: "配置信息不完整，请联系开发者获取支持。",
        contact: {
          name: "骆刚",
          phone: "19925762035",
          wechat: "naildidi",
          email: "745765426@qq.com"
        }
      };
    }
    
    // 验证COS配置
    if (!config.cos || !config.cos.baseUrl || !config.cos.region || !config.cos.bucket) {
      return {
        success: false,
        message: "授权验证失败",
        details: "配置信息不完整，请联系开发者获取支持。",
        contact: {
          name: "骆刚",
          phone: "19925762035",
          wechat: "naildidi",
          email: "745765426@qq.com"
        }
      };
    }
    
    return {
      success: true,
      message: "验证成功",
      details: "授权有效",
      expiryDate: _0x4e7d
    };
  } catch (error) {
    // console.error('验证出错:', error);
    return {
      success: false,
      message: "授权验证失败",
      details: "验证过程出现错误，请联系开发者获取支持。",
      contact: {
        name: "骆刚",
        phone: "19925762035",
        wechat: "naildidi",
        email: "745765426@qq.com"
      }
    };
  }
}; 
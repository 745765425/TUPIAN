const cloud = require('wx-server-sdk');
const COS = require('cos-nodejs-sdk-v5');

// 初始化云开发环境
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

// COS 配置信息
const cosConfig = {
  secretId: 'AKIDOeeNr52jDRPH3e0AGAnkV1GGzSeZEckb',
  secretKey: 'cy4uVpthEVWHl160h9LIzQcZHkyxgAPP',
  bucket: 'naildidi-1342588805',
  region: 'ap-guangzhou',
  baseUrl: 'https://naildidi-1342588805.cos.ap-guangzhou.myqcloud.com',
  videosFolder: '视频列表/'
};

exports.main = async (event, context) => {
  // 每次调用都会重新获取视频列表
  const cos = new COS({
    SecretId: cosConfig.secretId,
    SecretKey: cosConfig.secretKey
  });

  try {
    // 获取视频列表
    const result = await cos.getBucket({
      Bucket: cosConfig.bucket,
      Region: cosConfig.region,
      Prefix: cosConfig.videosFolder,
      Delimiter: '/'
    });

    // 处理返回数据
    const videoList = result.Contents
      .filter(file => file.Key.endsWith('.mp4'))
      .map(file => {
        const fileName = file.Key.split('/').pop();
        const [displayNumber, title, subtitle, playCount] = fileName.split('_');
        
        return {
          id: file.Key,
          sequenceNumber: parseInt(displayNumber),
          displayNumber,
          videoUrl: `${cosConfig.baseUrl}/${file.Key}`,
          title: title || '视频教程',
          subtitle: subtitle || '美甲教程',
          playCount: playCount ? playCount.replace('.mp4', '') : '0',
          createTime: file.LastModified
        };
      });

    return {
      code: 0,
      data: videoList,
      errMsg: 'ok'
    };
  } catch (err) {
    console.error('获取视频列表失败:', err);
    return {
      code: -1,
      data: [],
      errMsg: err.message
    };
  }
}; 
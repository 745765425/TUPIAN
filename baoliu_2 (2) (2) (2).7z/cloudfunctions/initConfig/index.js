// 云函数入口文件
const cloud = require('wx-server-sdk');
cloud.init();

// 云函数入口函数
exports.main = async (event, context) => {
  const db = cloud.database();
  const { cosConfig } = event;
  
  try {
    // 检查配置是否存在
    const configCollection = db.collection('system_config');
    const existingConfig = await configCollection.doc('cos_config').get()
      .catch(() => null);
    
    // 如果配置已存在，更新配置
    if (existingConfig) {
      await configCollection.doc('cos_config').update({
        data: {
          ...cosConfig,
          updatedAt: db.serverDate()
        }
      });
    } else {
      // 如果配置不存在，创建配置
      await configCollection.add({
        data: {
          _id: 'cos_config',
          ...cosConfig,
          createdAt: db.serverDate(),
          updatedAt: db.serverDate()
        }
      });
    }
    
    // 这里可以添加初始化COS配置的逻辑
    // 例如，验证COS存储桶是否可访问，创建必要的文件夹等
    
    return {
      success: true,
      message: 'COS配置初始化成功'
    };
  } catch (error) {
    console.error('COS配置初始化失败:', error);
    return {
      success: false,
      message: `COS配置初始化失败: ${error.message}`,
      error: error.message
    };
  }
}; 
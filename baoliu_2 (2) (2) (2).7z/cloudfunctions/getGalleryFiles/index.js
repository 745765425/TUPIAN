const COS = require('cos-nodejs-sdk-v5');
const config = require('./config.json');

// 使用配置文件初始化 COS
const cos = new COS({
    SecretId: config.SecretId,
    SecretKey: config.SecretKey
});

exports.main = async (event, context) => {
    const folder = event.folder || '瀑布流/';
    
    const params = {
        Bucket: config.Bucket,
        Region: config.Region,
        Prefix: folder,
        Delimiter: '/',
        MaxKeys: 1000
    };

    try {
        const data = await cos.getBucket(params);
        
        // 过滤并处理图片文件
        const files = data.Contents
            .filter(item => {
                // 首先检查是否是图片文件
                const isImage = /\.(jpg|jpeg|png|gif|webp)$/i.test(item.Key);
                
                if (!isImage) return false;
                
                // 然后检查是否符合命名规则（产品图X-1.扩展名）
                const filename = item.Key.split('/').pop();
                const isMainImage = /^产品图\d+-1\.[a-zA-Z]+$/i.test(filename);
                
                return isMainImage;
            })
            .map(item => {
                const key = item.Key.split('/').pop();
                // 从文件名中提取产品ID（如"产品图1"）
                const match = key.match(/^(产品图\d+)-\d+\./i);
                const productId = match ? match[1] : key; // 只取"产品图X"部分
                
                return {
                    Key: item.Key,
                    key: key,
                    productId: productId, // 添加产品ID字段
                    url: `https://${config.Bucket}.cos.${config.Region}.myqcloud.com/${item.Key}`,
                    createTime: item.LastModified
                };
            });
        
        return {
            success: true,
            data: files,
            result: {
                success: true,
                fileList: files
            }
        };
    } catch (err) {
        console.error('获取文件列表失败:', err);
        return {
            success: false,
            error: err.message,
            result: {
                success: false,
                error: err.message
            }
        };
    }
}; 
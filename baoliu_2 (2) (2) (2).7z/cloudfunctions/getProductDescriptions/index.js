// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const COS = require('cos-nodejs-sdk-v5');

// 初始化COS SDK - 不再使用硬编码值，而是使用传入的配置
function initCOS(cosConfig) {
  return new COS({
    SecretId: cosConfig.secretId,
    SecretKey: cosConfig.secretKey
  });
}

// 获取配置文件
async function getConfigFile(cos, fileKey, cosConfig) {
  console.log('获取配置文件参数:', {
    fileKey: fileKey,
    bucket: cosConfig.Bucket || cosConfig.bucket,
    region: cosConfig.Region || cosConfig.region
  });
  
  return new Promise((resolve, reject) => {
    cos.getObject({
      Bucket: cosConfig.Bucket || cosConfig.bucket,
      Region: cosConfig.Region || cosConfig.region,
      Key: fileKey
    }, (err, data) => {
      if (err) {
        console.error('获取配置文件失败:', err);
        reject(err);
      } else {
        console.log('获取配置文件成功');
        resolve(data);
      }
    });
  });
}

// 云函数入口函数
exports.main = async (event, context) => {
  const { folder = '瀑布流/', cosConfig, productId } = event
  
  try {
    // 使用传入的cosConfig初始化COS
    const cos = new COS({
      SecretId: cosConfig.secretId,
      SecretKey: cosConfig.secretKey
    });
    
    // 获取区域信息
    const region = cosConfig.region || 'ap-guangzhou';
    
    // 获取存储桶中的文件列表
    const listResult = await new Promise((resolve, reject) => {
      cos.getBucket({
        Bucket: cosConfig.bucket,
        Region: region,
        Prefix: folder,
        MaxKeys: 1000
      }, (err, data) => {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      });
    });
    
    // 处理产品图片
    let productConfig = {};
    const productImages = [];
    
    console.log('查找产品ID:', productId);
    console.log('文件列表长度:', listResult.Contents.length);

    // 记录所有图片文件名，帮助调试
    const allImageFiles = listResult.Contents
      .filter(item => /\.(jpg|jpeg|png|gif|webp)$/i.test(item.Key))
      .map(item => item.Key.split('/').pop());
    console.log('所有图片文件:', allImageFiles);

    if (listResult && listResult.Contents) {
      // 先找出所有符合条件的图片
      listResult.Contents.forEach(item => {
        if (/\.(jpg|jpeg|png|gif|webp)$/i.test(item.Key)) {
          const filename = item.Key.split('/').pop();
          console.log(`检查文件: ${filename}`);
          
          // 匹配产品ID开头的所有图片
          const match = filename.match(/^(产品图\d+)-(\d+)\.[a-zA-Z]+$/i);
          
          if (match) {
            const fileProductId = match[1].toLowerCase();
            const index = parseInt(match[2]);
            
            // 将传入的产品ID转为小写并去掉可能的后缀
            const targetProductId = productId.toLowerCase().split('-')[0];
            
            console.log(`比较: ${fileProductId} vs ${targetProductId}, 相等: ${fileProductId === targetProductId}`);
            
            if (fileProductId === targetProductId) {
              console.log('找到匹配图片:', filename);
              productImages.push({
                url: `https://${cosConfig.bucket}.cos.${region}.myqcloud.com/${item.Key}`,
                key: item.Key,
                filename: filename,
                index: index
              });
            }
          } else {
            console.log(`文件 ${filename} 不符合命名格式`);
          }
        }
      });
    }

    // 确保按序号排序
    productImages.sort((a, b) => a.index - b.index);
    console.log(`最终找到 ${productImages.length} 张匹配图片:`, productImages.map(img => img.filename));
    
    // 获取产品描述配置
    const configPath = folder + 'gallery-products.json';
    
    try {
      console.log('尝试获取配置文件:', configPath);
      console.log('COS配置:', cosConfig);
      
      const configResult = await getConfigFile(cos, configPath, {
        Bucket: cosConfig.bucket, // 使用与cos.getBucket相同的参数名
        Region: region
      });
      
      productConfig = JSON.parse(configResult.Body.toString()) || {};
      console.log('成功解析配置文件:', productConfig);
    } catch (err) {
      console.error('获取产品配置失败，使用空配置:', err);
    }
    
    // 获取该产品的配置
    const productInfo = productConfig[productId] || {};
    
    // 返回产品信息和图片
    console.log('返回的产品图片:', productImages);
    
    return {
      success: true,
      data: {
        id: productId,
        title: productInfo.title || productId,
        subtitle: productInfo.subtitle || '',
        description: productInfo.description || '',
        images: productImages
      }
    };
    
  } catch (error) {
    return {
      success: false,
      error: error.message,
      stack: error.stack
    };
  }
} 
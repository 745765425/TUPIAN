const cloud = require('wx-server-sdk');
const appConfig = require('../../config/app-config.js');
const config = require('./config.js');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { videoUrl } = event;
  
  try {
    // 1. 从文件名解析信息
    const fileName = videoUrl.split('/').pop();
    const [displayNumber, title, subtitle, playCount] = fileName.split('_');
    
    // 2. 获取序号
    const sequenceNumber = parseInt(displayNumber);
    
    // 3. 添加记录
    const result = await db.collection(config.collections.videos).add({
      data: {
        sequenceNumber,
        displayNumber,
        videoUrl,
        title,
        subtitle,
        playCount: playCount.split('.')[0],  // 去掉扩展名
        createTime: db.serverDate()
      }
    });
    
    return {
      success: true,
      data: result
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}; 
// 云函数配置
module.exports = {
  collections: {
    videos: 'videos',
    users: 'users',
    comments: 'comments'
  }
}; 
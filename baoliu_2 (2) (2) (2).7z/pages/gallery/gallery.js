// pages/gallery/gallery.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    galleryItems: [],
    isLoading: false,
    showPreview: false,
    previewImage: null,
    headerState: {
      opacity: 1
    },
    galleryUrls: [],  // 添加这个数组来存储所有图片URL
    startY: 0,
    moveY: 0,
    moveDistance: 0,
    canClose: false,
    isClosing: false,
    imageCache: {}, // 新增：用于缓存已加载的图片
    refreshing: false, // 新增：标记是否在刷新中
    galleryImages: [],
    screenHeight: 0,
    screenWidth: 0,
    hasMore: true,
  },

  // 将 Set 移到实例属性而不是 data 中
  loadedImages: new Set(),

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    // 获取窗口信息
    const windowInfo = wx.getWindowInfo();
    const deviceInfo = wx.getDeviceInfo();
    
    this.setData({
      screenHeight: windowInfo.windowHeight,
      screenWidth: windowInfo.windowWidth,
      // 其他数据保持不变
    });
    
    // 初始化图片缓存对象
    if (!app.globalData.imageCache) {
      app.globalData.imageCache = {};
    }
    this.imageCache = app.globalData.imageCache;
    
    // 使用预加载的数据
    if (app.globalData.preloadedData.gallery) {
      this.setData({
        galleryImages: app.globalData.preloadedData.gallery,
        hasMore: app.globalData.preloadedData.hasMore
      });
    } else {
      // 如果预加载失败才请求
      this.loadGalleryData();
    }
    
    // 提前预加载下一页数据
    this.preloadNextPage();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    // 页面显示时，只通过存储机制设置选中状态
    wx.setStorageSync('tabBarIndex', 1);
    
    // 在每次页面显示时检查预览状态，控制TabBar可见性
    if (this.data.showPreview) {
      // 如果预览弹窗正在显示，确保底部导航栏隐藏
      wx.setStorageSync('tabBarVisible', false);
    } else {
      // 如果预览弹窗未显示，确保底部导航栏显示
      wx.setStorageSync('tabBarVisible', true);
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    // 清理时使用实例的 Set
    this.loadedImages.clear();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    if (!this.data.refreshing) {
      this.refreshGallery();
    } else {
      wx.stopPullDownRefresh();
    }
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  async onReachBottom() {
    if (!this.data.hasMore || this.data.isLoading) return;

    const app = getApp();
    const currentPage = app.globalData.preloadedData.currentPage;
    
    this.setData({ isLoading: true });
    
    try {
      const result = await wx.cloud.callFunction({
        name: 'getGalleryFiles',
        data: {
          skip: currentPage * 20,
          limit: 20
        }
      });

      if (result && result.result && result.result.data) {
        // 过滤掉已加载的图片
        const newImages = result.result.data.filter(img => 
          !this.loadedImages.has(img.url)
        );

        if (newImages.length > 0) {
          // 更新数据和缓存
          newImages.forEach(img => this.loadedImages.add(img.url));
          
          this.setData({
            galleryImages: [...this.data.galleryImages, ...newImages],
            hasMore: newImages.length === 20
          });

          app.globalData.preloadedData.currentPage++;
        } else {
          this.setData({ hasMore: false });
        }
      }
    } catch (err) {
      console.error('加载更多失败:', err);
    } finally {
      this.setData({ isLoading: false });
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
  },

  // 优化的滚动事件处理
  onScrollEvent(e) {
    wx.nextTick(() => {
      const scrollTop = e.detail.scrollTop;
      const opacity = Math.max(0, 1 - (scrollTop / 150));
      this.setData({ 
        'headerState.opacity': opacity 
      });
    });
  },

  // 优化的图片加载方法
  async loadGalleryImagesFromStorage() {
    if (this.data.isLoading) return;
    this.setData({ isLoading: true });
    
    try {
        // 1. 调用云函数获取图片列表
        const res = await wx.cloud.callFunction({
            name: 'getGalleryFiles',
            data: { folder: '瀑布流/' }
        });
        console.log('云函数返回数据:', res);

        if (!res.result?.success || !Array.isArray(res.result.data)) {
            throw new Error('获取图片列表失败');
        }

        // 2. 处理每个图片 - 优化图片加载逻辑
        const imagePromises = res.result.data.map(file => {
            // 检查是否已经缓存
            if (this.imageCache[file.url]) {
                console.log('使用缓存图片:', file.key);
                return Promise.resolve(this.imageCache[file.url]);
            }
            
            return new Promise((resolve) => {
                console.log('处理图片:', file.url);
                
                // 先创建一个基本的图片对象
                const imageObject = {
                    _id: file.Key,
                    title: file.key,
                    imageUrl: file.url,
                };
                
                // 无论成功失败，先保存基本对象到缓存
                this.imageCache[file.url] = imageObject;
                
                // 异步获取图片信息
                wx.getImageInfo({
                    src: file.url,
                    success: (imgInfo) => {
                        console.log('获取图片信息成功:', file.key, imgInfo);
                        // 更新缓存中的对象
                        this.imageCache[file.url] = {
                            ...imageObject,
                            width: imgInfo.width,
                            height: imgInfo.height,
                            loaded: true
                        };
                        resolve(this.imageCache[file.url]);
                    },
                    fail: (error) => {
                        console.error('获取图片信息失败:', file.key, error);
                        // 失败也返回基本对象，不返回null
                        resolve(imageObject);
                    }
                });
            });
        });

        // 3. 等待所有图片处理完成
        const items = await Promise.all(imagePromises);
        console.log('所有图片处理完成:', items);

        // 不再过滤null项，因为我们总是返回至少基本的图片对象
        const validItems = items;

        // 4. 更新页面数据
        this.setData({
            galleryItems: validItems,
            galleryUrls: validItems.map(item => item.imageUrl)
        });

    } catch (err) {
        console.error('加载图片失败:', err);
        wx.showToast({
            title: '加载失败',
            icon: 'none'
        });
    } finally {
        this.setData({ isLoading: false });
    }
  },

  // 提取产品ID的辅助函数
  extractProductId(item) {
    let productId = '';
    
    if (item.title) {
      const match = item.title.match(/^(产品图\d+)/i);
      if (match) {
        productId = match[1];
      }
    } else if (item.productId) {
      productId = item.productId;
    }
    
    if (!productId) {
      productId = item.id || '';
      if (productId.includes('-')) {
        productId = productId.split('-')[0];
      }
    }
    
    return productId;
  },

  // 图片预览相关
  handleImageTap(e) {
    const item = e.currentTarget.dataset.item;
    if (!item || !item.imageUrl) return;
    
    // 提取产品ID
    const productId = this.extractProductId(item);
    
    // 立即显示第一张图片
    const initialPreviewData = {
      title: item.title || productId,
      subtitle: '',
      description: '',
      images: [{
        url: item.imageUrl,
        loaded: true
      }],
      currentIndex: 0
    };
    
    this.setData({
      previewImage: initialPreviewData,
      showPreview: true
    });
    
    // 隐藏底部导航栏
    if (typeof this._hideTabBar === 'function') {
      this._hideTabBar();
    }
    
    // 加载完整图片组
    try {
      // 确保全局配置对象存在
      if (!app || !app.globalData || !app.globalData.appConfig || !app.globalData.appConfig.cos) {
        return; // 如果配置不存在，不调用云函数，保持显示单图
      }
      
      wx.cloud.callFunction({
        name: 'getProductDescriptions',
        data: {
          folder: '瀑布流/',
          productId: productId,
          cosConfig: app.globalData.appConfig.cos  // 添加COS配置
        }
      }).then(res => {
        if (res.result && res.result.success && res.result.data && res.result.data.images && res.result.data.images.length > 0) {
          // 创建预览数据，确保第一张图片标记为已加载
          const previewData = {
            title: res.result.data.title || productId,
            subtitle: res.result.data.subtitle || '',
            description: res.result.data.description || '',
            images: res.result.data.images.map((img, index) => ({
              url: img.url,
              loaded: index === 0 ? true : false // 第一张图片已加载
            })),
            currentIndex: 0
          };
          
          // 更新预览数据
          this.setData({
            previewImage: previewData
          });
        }
      }).catch(err => {
        // 出错时不做任何处理，保持显示单张图片
      });
    } catch (error) {
      // 捕获任何可能的错误，保持显示单张图片
    }
  },

  // 显示备用预览的辅助函数 - 简化版
  showFallbackPreview(item) {
    if (!item || !item.imageUrl) return;
    
    const previewData = {
      title: item.title || '图片预览',
      subtitle: '',
      description: '',
      images: [{
        url: item.imageUrl,
        loaded: true
      }],
      currentIndex: 0
    };
    
    this.setData({
      previewImage: previewData,
      showPreview: true
    });
  },

  closePreview() {
    // 防止重复调用
    if (this.data.isClosing) return;
    
    // 设置关闭状态
    this.setData({
      isClosing: true
    });
    
    // 添加关闭动画
    const previewContainer = this.selectComponent('.preview-container');
    if (previewContainer) {
      previewContainer.setStyle({
        transform: 'translateY(100%)',
        transition: 'transform 0.3s ease-out'
      });
    }
    
    // 等待动画完成后再关闭弹窗
    setTimeout(() => {
      // 先隐藏预览
      this.setData({
        showPreview: false,
        isClosing: false
      });
      
      // 使用存储机制替代直接操作
      wx.setStorageSync('tabBarVisible', true);
      wx.setStorageSync('tabBarIndex', 1);
    }, 300);
  },

  // 新增：隐藏底部导航栏
  _hideTabBar() {
    wx.setStorageSync('tabBarVisible', false);
  },
  
  // 新增：显示底部导航栏
  _showTabBar() {
    wx.setStorageSync('tabBarVisible', true);
  },

  // 修改刷新方法，优化下拉刷新体验
  async refreshGallery() {
    // 防止重复刷新
    if (this.data.refreshing) {
      wx.stopPullDownRefresh();
      return;
    }
    
    this.setData({ refreshing: true });
    
    try {
      // 保存当前的图片数据作为备份
      const currentGalleryItems = [...this.data.galleryItems];
      
      // 调用云函数获取图片列表
      const res = await wx.cloud.callFunction({
        name: 'getGalleryFiles',
        data: { folder: '瀑布流/' }
      });
      console.log('刷新获取到的数据:', res);

      if (!res.result?.success || !Array.isArray(res.result.data)) {
        throw new Error('获取图片列表失败');
      }

      // 处理新获取的图片数据
      const newFiles = res.result.data;
      
      // 创建新图片的处理承诺
      const imagePromises = newFiles.map(file => {
        // 检查是否已存在此图片
        const existingItem = currentGalleryItems.find(item => 
          item._id === file.Key || item.imageUrl === file.url
        );
        
        // 如果已存在且有效，直接使用现有数据
        if (existingItem) {
          console.log('使用缓存图片:', file.key);
          return Promise.resolve(existingItem);
        }
        
        // 检查全局缓存
        if (this.imageCache[file.url]) {
          console.log('使用全局缓存图片:', file.key);
          return Promise.resolve(this.imageCache[file.url]);
        }
        
        // 否则尝试获取新图片信息
        return new Promise((resolve) => {
          console.log('处理新图片:', file.url);
          
          // 先创建基本对象
          const imageObject = {
            _id: file.Key,
            title: file.key,
            imageUrl: file.url
          };
          
          // 无论成功失败，先保存基本对象到缓存
          this.imageCache[file.url] = imageObject;
          
          wx.getImageInfo({
            src: file.url,
            success: (imgInfo) => {
              console.log('获取图片信息成功:', file.key, imgInfo);
              // 更新缓存中的对象
              const updatedObject = {
                ...imageObject,
                width: imgInfo.width,
                height: imgInfo.height,
                loaded: true
              };
              this.imageCache[file.url] = updatedObject;
              resolve(updatedObject);
            },
            fail: (error) => {
              console.error('获取图片信息失败:', file.key, error);
              
              // 如果获取新数据失败但有旧数据，使用旧数据
              const fallbackItem = currentGalleryItems.find(item => 
                item.title === file.key || item._id === file.Key
              );
              
              if (fallbackItem) {
                console.log('使用备用图片数据:', file.key);
                this.imageCache[file.url] = fallbackItem;
                resolve(fallbackItem);
              } else {
                // 即使失败也返回基本对象，而不是null
                resolve(imageObject);
              }
            }
          });
        });
      });

      // 等待所有图片处理完成
      const items = await Promise.all(imagePromises);
      console.log('刷新后处理完成的图片:', items.length);
      
      // 更新数据 - 不再过滤，因为我们永远不会返回null
      this.setData({
        galleryItems: items,
        galleryUrls: items.map(item => item.imageUrl)
      });
      
      wx.stopPullDownRefresh();
    } catch (err) {
      console.error('刷新失败:', err);
      wx.stopPullDownRefresh();
      
      // 显示错误提示
      wx.showToast({
        title: '刷新失败，请稍后再试',
        icon: 'none',
        duration: 2000
      });
    } finally {
      this.setData({ refreshing: false });
    }
  },

  // 添加处理数据的方法
  processGalleryData(fileList) {
    console.log('原始文件数据:', fileList);
    const galleryItems = fileList.map(file => {
      // 提取文件名和产品ID
      const filename = file.Key.split('/').pop();
      const productId = filename.split('.')[0];
      
      // 获取产品信息
      const productInfo = file.productInfo || {};
      
      return {
        _id: file.Key,
        id: productId,
        title: productInfo.name || '美甲作品',
        subtitle: productInfo.title || '',
        description: productInfo.description || '',
        imageUrl: file.url,
        filename: filename
      };
    });
    
    // 更新数据
    this.setData({
      galleryItems: galleryItems,
      isLoading: false,
      // 构建预览URL数组
      galleryUrls: galleryItems.map(item => item.imageUrl)
    });
    
    console.log('处理后的画廊数据:', galleryItems);
  },

  onLoad: function() {
    // 调用云函数获取图片列表
    wx.cloud.callFunction({
      name: 'getGalleryFiles',
      data: {
        folder: '瀑布流/'  // 指定文件夹
      }
    }).then(res => {
      console.log('获取图片列表成功:', res);
      if (res.result && res.result.success && res.result.data) {
        // 直接处理返回的文件列表
        this.processGalleryData(res.result.data);
      }
    }).catch(err => {
      console.error('获取图片列表失败:', err);
      this.setData({
        isLoading: false,
        galleryItems: []
      });
    });
  },

  // 在 gallery.js 中添加测试方法
  testProductDescriptions: function() {
    wx.showLoading({
      title: '测试中...'
    });

    wx.cloud.callFunction({
      name: 'getProductDescriptions',
      data: {
        folder: '瀑布流/'
      }
    }).then(res => {
      console.log('获取产品描述结果:', res.result);
      wx.hideLoading();
      
      // 显示结果
      wx.showModal({
        title: '测试结果',
        content: JSON.stringify(res.result, null, 2),
        showCancel: false
      });
    }).catch(err => {
      console.error('测试失败:', err);
      wx.hideLoading();
      
      wx.showModal({
        title: '测试失败',
        content: err.message || '未知错误',
        showCancel: false
      });
    });
  },

  // 触摸开始
  touchStart(e) {
    this.setData({
      startY: e.touches[0].clientY,
      moveY: e.touches[0].clientY,
      moveDistance: 0,
      canClose: false
    });
  },

  // 添加阻止事件冒泡的方法
  preventTouchMove(e) {
    // 阻止事件冒泡，防止影响底层页面
    return false;
  },

  // 修改触摸移动方法
  touchMove(e) {
    const moveY = e.touches[0].clientY;
    const moveDistance = moveY - this.data.startY;
    
    // 检查触摸的元素
    const target = e.target || {};
    const dataset = target.dataset || {};
    
    // 判断是否在滚动区域内
    const isInScrollArea = dataset.preventDrag || 
                           (target.id === 'preview-info-scroll');
    
    // 如果在文字滚动区域且不是下拉，允许正常滚动
    if (isInScrollArea && moveDistance <= 0) {
      return; // 允许正常滚动
    }
    
    // 处理下拉操作
    if (moveDistance > 0) {
      // 阻止默认行为，防止影响底层页面
      e.preventDefault && e.preventDefault();
      
      // 简化判断逻辑，使用dataset来标记可拖动区域
      const canDrag = !isInScrollArea || dataset.allowDrag;
      
      if (canDrag) {
        this.setData({
          moveDistance: moveDistance,
          canClose: moveDistance > 100 // 下拉超过100px时可以关闭
        });
        
        // 应用transform效果
        const previewContainer = this.selectComponent('.preview-container');
        if (previewContainer) {
          previewContainer.setStyle({
            transform: `translateY(${moveDistance}px)`
          });
        }
      }
    }
  },

  // 触摸结束
  touchEnd() {
    if (this.data.canClose) {
      // 下拉距离足够，关闭预览
      this.closePreview();
    } else {
      // 下拉距离不够，恢复位置
      const previewContainer = this.selectComponent('.preview-container');
      if (previewContainer) {
        previewContainer.setStyle({
          transform: 'translateY(0)',
          transition: 'transform 0.3s ease-out'
        });
      }
    }
    
    // 重置状态
    this.setData({
      moveDistance: 0,
      canClose: false
    });
  },

  // 阻止冒泡
  preventBubble(e) {
    // 阻止事件冒泡
    return false;
  },

  // 修改预加载函数，使用wx.getImageInfo替代Image
  preloadImages(images, currentIndex) {
    if (!images || images.length <= 1) return;
    
    // 预加载当前图片相邻的图片
    const preloadIndexes = [];
    if (currentIndex > 0) preloadIndexes.push(currentIndex - 1);
    if (currentIndex < images.length - 1) preloadIndexes.push(currentIndex + 1);
    
    preloadIndexes.forEach(index => {
      const img = images[index];
      if (img && img.url && !img.preloaded) {
        // 使用wx.getImageInfo替代Image
        wx.getImageInfo({
          src: img.url,
          success: () => {
            // 标记为已预加载，但不触发UI更新
            img.preloaded = true;
          },
          fail: () => {
            // 预加载失败时不做任何处理
          }
        });
      }
    });
  },

  // 修改onSwiperChange函数，添加预加载
  onSwiperChange(e) {
    const currentIndex = e.detail.current;
    
    // 只更新currentIndex，减少不必要的渲染
    this.setData({
      'previewImage.currentIndex': currentIndex
    });
    
    // 预加载相邻图片
    if (this.data.previewImage && this.data.previewImage.images) {
      this.preloadImages(this.data.previewImage.images, currentIndex);
    }
  },

  // 优化图片加载处理
  handleImageLoad(e) {
    if (!e || !e.currentTarget || !e.currentTarget.dataset) return;
    
    const index = e.currentTarget.dataset.index;
    
    // 只更新加载状态，不操作缓存
    if (typeof index === 'number' && this.data.previewImage && this.data.previewImage.images) {
      this.setData({
        [`previewImage.images[${index}].loaded`]: true
      });
    }
  },

  // 简化：处理图片加载错误
  handleImageError(e) {
    if (!e || !e.currentTarget || !e.currentTarget.dataset) return;
    
    const index = e.currentTarget.dataset.index;
    
    // 只处理预览图片错误
    if (typeof index === 'number' && this.data.previewImage && this.data.previewImage.images) {
      // 设置默认图片
      const defaultImageUrl = '/images/default_image.png';
      
      this.setData({
        [`previewImage.images[${index}].url`]: defaultImageUrl,
        [`previewImage.images[${index}].isDefault`]: true,
        [`previewImage.images[${index}].loaded`]: true
      });
    }
  },

  // 预加载下一页
  preloadNextPage() {
    // 实现预加载下一页数据逻辑
  },

  // 修改图片加载函数，使用正确的云函数名称
  async loadGalleryData() {
    const app = getApp();
    
    // 如果正在预加载，等待预加载完成
    if (app.globalData.preloadedData.isPreloading) {
      await new Promise(resolve => {
        const checkPreload = () => {
          if (!app.globalData.preloadedData.isPreloading) {
            resolve();
          } else {
            setTimeout(checkPreload, 100);
          }
        };
        checkPreload();
      });
      
      // 预加载完成后，使用预加载的数据
      if (app.globalData.preloadedData.gallery) {
        this.setData({
          galleryImages: app.globalData.preloadedData.gallery,
          hasMore: app.globalData.preloadedData.hasMore
        });
        return;
      }
    }

    // 如果预加载失败，才执行正常加载流程
    if (this.data.isLoading) return;
    
    this.setData({ isLoading: true });
    
    try {
      const result = await wx.cloud.callFunction({
        name: 'getGalleryFiles',
        data: {
          skip: this.data.galleryImages.length,
          limit: 20
        }
      });

      if (result && result.result && result.result.data) {
        // 使用实例的 Set
        const newImages = result.result.data.filter(img => 
          !this.loadedImages.has(img.url)
        );

        if (newImages.length > 0) {
          newImages.forEach(img => this.loadedImages.add(img.url));
          
          this.setData({
            galleryImages: [...this.data.galleryImages, ...newImages],
            hasMore: newImages.length === 20
          });
        }
      }
    } catch (err) {
      console.error('加载图片失败:', err);
    } finally {
      this.setData({ isLoading: false });
    }
  },

  // 从存储加载图片
  loadGalleryImagesFromStorage(append = false) {
    const app = getApp();
    
    // 如果有缓存数据且不是追加模式，直接使用缓存
    if (!append && app.globalData.gallery && app.globalData.gallery.data) {
      this.setData({
        galleryImages: app.globalData.gallery.data
      });
      return;
    }
    
    // 否则加载新数据
    this.loadGalleryData();
  },

  // 修改预加载函数
  preloadNextBatch(images) {
    if (!images || !Array.isArray(images)) return;
    
    const uniqueUrls = new Set(images.map(img => img.url));
    const app = getApp();
    
    uniqueUrls.forEach(url => {
      // 检查全局缓存
      if (url && !app.globalData.galleryCache.has(url)) {
        wx.getImageInfo({
          src: url,
          success: () => {
            app.globalData.galleryCache.set(url, true);
            this.loadedImages.add(url);
          }
        });
      }
    });
  },

  // 在预览图片时
  previewImage(e) {
    // 旧代码
    // wx.previewImage({...})
    
    // 新代码
    wx.previewMedia({
      sources: [{
        url: e.currentTarget.dataset.url,
        type: 'image'
      }],
      showmenu: true,
      current: 0
    });
  },
})
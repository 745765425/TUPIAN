Page({
  data: {
    errorTitle: "授权已到期",
    errorMessage: "您的美甲小程序授权已到期，请联系开发者续期。",
    contactInfo: {
      name: "骆刚",
      phone: "19925762035",
      wechat: "naildidi",
      email: "745765426@qq.com"
    }
  },

  onLoad: function(options) {
    // 如果有传入的错误信息，则使用传入的信息
    if (options.title) {
      this.setData({
        errorTitle: options.title
      });
    }
    
    if (options.message) {
      this.setData({
        errorMessage: options.message
      });
    }
    
    // 尝试获取全局错误信息
    const app = getApp();
    if (app.globalData && app.globalData.errorInfo) {
      const errorInfo = app.globalData.errorInfo;
      
      this.setData({
        errorTitle: errorInfo.message || "授权已到期",
        errorMessage: errorInfo.details || "请联系开发者获取支持",
        contactInfo: errorInfo.contact || this.data.contactInfo
      });
    }
  },

  handleRetry() {
    // 检查是否有启动页图片引用
    wx.reLaunch({
      url: '/pages/index/index'
    });
  }
}); 
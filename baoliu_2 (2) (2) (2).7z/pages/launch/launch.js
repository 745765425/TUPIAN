/**
 * 启动页 - 仅作为路由占位页
 * 
 * 此页面仅用于满足小程序路由需求，实际启动页功能由 components/qidongye1 组件实现。
 * 当用户进入此页面时，会立即重定向到主页。
 */

Page({
  data: {
    // 删除任何启动页图片引用的注释
  },
  onLoad() {
    // 立即重定向到首页
    wx.switchTab({
      url: '/pages/index/index'
    });
  },
  
  // 阻止页面显示过程中可能的闪烁
  onShow() {
    // 立即导航到首页，确保用户不会停留在此页
    wx.switchTab({
      url: '/pages/index/index'
    });
  }
}); 
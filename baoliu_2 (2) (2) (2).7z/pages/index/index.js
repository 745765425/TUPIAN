// pages/index/index.js
/* global Page, wx, getApp, clearTimeout, setTimeout, console, setInterval, clearInterval */

// 环境标志 - 生产环境设为false
const IS_DEV_MODE = false;

// 节流时间间隔（毫秒）
const THROTTLE_DELAY = 16; // 约60fps

Page({
  data: {
    videoList: [],
    hasShown: false,
    configValid: true,
    showLaunch: true,
    isDetailShow: false,
    showVideoDetail: false,
    currentVideo: null,
    contentClass: '',
    headerState: {
      opacity: 1
    },
    loading: false,
    hasMore: true,
    statusBarHeight: 44
  },
  
  // 节流计时器
  _scrollThrottleTimer: null,
  _lastScrollTime: 0,
  
  onLoad() {
    // 添加调试日志
    console.log('启动前标记状态:', wx.getStorageSync('hasShownLaunch'));
    
    // 强制显示启动页 - 临时修复
    wx.removeStorageSync('hasShownLaunch');
    
    // 检查启动页是否已显示过
    const hasShownLaunch = wx.getStorageSync('hasShownLaunch');
    console.log('重置后标记状态:', hasShownLaunch);
    
    // 现在应该是 false，所以启动页会显示
    const shouldShowLaunch = true; // 强制显示启动页
    
    // 设置TabBar可见性和启动页状态
    wx.setStorageSync('tabBarVisible', false); // 确保TabBar初始隐藏
    wx.setStorageSync('launchPageShowing', true);
    
    // 初始化应用环境
    this.setData({
      hasShown: false,
      videoList: [],
      contentClass: '',
      showLaunch: true  // 强制显示启动页
    });

    // 设置初始背景色
    if (shouldShowLaunch) {
      wx.setBackgroundColor({
        backgroundColor: '#6B9FBC',
        backgroundColorTop: '#6B9FBC',
        backgroundColorBottom: '#11191F'
      });
    } else {
      wx.setBackgroundColor({
        backgroundColor: '#ffffff'
      });
    }

    // 延迟加载数据，不阻塞启动页显示
    setTimeout(() => {
      this.ensureContentLoaded();
      
      // 监听系统主题变化
      wx.onThemeChange((result) => {
        this.setData({
          darkMode: result.theme === 'dark'
        });
      });
    }, 200);
  },
  
  // 添加滚动节流处理函数
  onScrollEventThrottled(e) {
    const now = Date.now();
    
    // 如果距离上次处理间隔小于阈值，则延迟处理
    if (now - this._lastScrollTime < THROTTLE_DELAY) {
      // 清除之前的计时器
      if (this._scrollThrottleTimer) {
        clearTimeout(this._scrollThrottleTimer);
      }
      
      // 设置新计时器
      this._scrollThrottleTimer = setTimeout(() => {
        this._lastScrollTime = Date.now();
        this.handleScrollEvent(e);
      }, THROTTLE_DELAY);
      
      return;
    }
    
    // 记录本次处理时间
    this._lastScrollTime = now;
    
    // 实际处理滚动事件
    this.handleScrollEvent(e);
  },
  
  // 实际处理滚动事件的函数
  handleScrollEvent(e) {
    // 标记页面正在滚动，防止意外触发视频详情弹窗
    this._isScrolling = true;
    
    // 设置防抖定时器，滚动停止500ms后重置滚动状态
    if (this._scrollTimer) {
      clearTimeout(this._scrollTimer);
    }
    
    this._scrollTimer = setTimeout(() => {
      this._isScrolling = false;
    }, 500);
    
    // 处理标题栏透明度
    if (e && e.detail) {
      const scrollTop = e.detail.scrollTop;
      const threshold = 100; // 渐变阈值
      
      // 计算标题栏透明度
      let opacity = 0;
      if (scrollTop < threshold) {
        opacity = scrollTop / threshold;
      } else {
        opacity = 1;
      }
      
      // 设置标题栏透明度
      this.setData({
        navBarOpacity: opacity,
        hasFirstScroll: true
      });
      
      // 额外安全检查：如果正在滚动并且弹窗意外显示，强制关闭它
      if (this._isScrolling && this.data.showVideoDetail) {
        console.log('检测到滚动时弹窗意外显示，强制关闭');
        this.setData({
          showVideoDetail: false,
          currentVideo: null
        });
        
        // 查找详情组件并关闭
        const videoDetail = this.selectComponent('#video-detail');
        if (videoDetail) {
          try {
            videoDetail.closeDetail();
          } catch {
            // 忽略可能的错误
          }
        }
      }
    }
  },
  
  // 原来的onScrollEvent函数作为wxml中的事件处理器
  onScrollEvent(e) {
    this.onScrollEventThrottled(e);
  },
  
  onLaunchClose() {
    console.log('启动页关闭');
    
    this.setData({
      showLaunch: false,
      contentClass: 'fade-in'
    });
    
    // 记录启动页已显示
    wx.setStorageSync('hasShownLaunch', true);
    
    // 背景色调整
    wx.setBackgroundColor({
      backgroundColor: '#ffffff'
    });
    
    // 安全调用全局方法
    const app = getApp();
    
    // 方法一：先检查方法是否存在
    if (app && typeof app.showTabBar === 'function') {
      app.showTabBar();
    } else {
      // 备用方案：直接使用存储设置可见性
      wx.setStorageSync('tabBarVisible', true);
    }
    
    // 加载页面内容
    this.ensureContentLoaded();
  },
  
  // 确保内容已加载
  ensureContentLoaded() {
    if (!this.data.videoList || this.data.videoList.length === 0) {
      this.loadData(true);
    }
  },
  
  // 静默预加载视频资源
  preloadVideoResources() {
    if (this.data.videoList && this.data.videoList.length > 0) {
      // 优先预加载前3个视频的封面图
      this.data.videoList.slice(0, 3).forEach((video) => {
        if (video.coverUrl) {
          wx.getImageInfo({
            src: video.coverUrl
          });
        }
      });
    }
  },
  
  // 检查视频卡片组件是否准备就绪
  checkVideoCardReady() {
    // 使用固定的窗口高度值，避免使用已弃用API
    const windowHeight = 667; // 一个合理的默认值
    
    const query = wx.createSelectorQuery();
    query.selectAll('.video-card').boundingClientRect(rects => {
      if (rects && rects.length > 0) {
        // 找出视口可见的卡片，但不使用已弃用API
        rects.filter(rect => 
          rect.top < windowHeight && 
          rect.bottom > 0
        );
      }
    }).exec();
  },
  
  // 页面显示事件
  onShow() {
    // 检查是否有弹窗显示
    const popupShowing = wx.getStorageSync('popupShowing') || false;
    const launchPageShowing = wx.getStorageSync('launchPageShowing') || false;
    
    // 设置当前页面索引
    wx.setStorageSync('tabBarIndex', 0);
    
    // 根据当前状态决定导航栏显示
    if (launchPageShowing || popupShowing || this.data.showVideoDetail) {
      wx.setStorageSync('tabBarVisible', false);
    } else {
      // 只有在没有弹窗和启动页时才显示导航栏
      wx.setStorageSync('tabBarVisible', true);
    }
    
    // 其他页面显示逻辑不变...
  },
  
  onHide() {
    // 页面隐藏时暂停所有视频
    this.pauseAllVideos();
    
    // 清除防止弹窗的定时器
    if (this._preventPopupTimeout) {
      clearTimeout(this._preventPopupTimeout);
    }
  },
  
  // 修改暂停所有视频的方法
  pauseAllVideos() {
    // 获取所有视频卡片组件
    const videoCards = this.selectAllComponents('.video-card');
    
    if (videoCards && videoCards.length > 0) {
      // 遍历所有视频卡片组件，暂停正在播放的视频
      videoCards.forEach(card => {
        if (card.data.isPlaying) {
          card.pauseVideo();
        }
      });
    } else {
      // 备用方案：尝试通过ID直接暂停视频
      this.data.videoList.forEach(video => {
        const videoContext = wx.createVideoContext(`video-${video.id}`);
        if (videoContext) {
          videoContext.pause();
        }
      });
    }
  },
  
  // 修改视频检测方法
  checkVideoVisibility() {
    this.checkVideoInView();
  },

  // 修改视频点击事件处理
  onVideoTap(e) {
    // 检查是否有视频信息
    if (!e.detail || !e.detail.videoInfo) {
      return;
    }
    
    const videoInfo = e.detail.videoInfo;
    
    // 确保视频信息完整
    if (!videoInfo.videoUrl) {
      return;
    }
    
    this.setData({
      isDetailShow: true,
      currentVideo: videoInfo
    });
  },

  onDetailClose() {
    // 先更新状态，确保导航栏马上显示
    this.setData({
      showVideoDetail: false,  // 确保关闭时正确设置状态
      currentVideo: null
    });
    
    // 显示导航栏
    if (typeof this.getTabBar === 'function') {
      const tabBar = this.getTabBar();
      if (tabBar) {
        tabBar.show();
      }
    }
  },

  checkVideoInView() {
    // 仅进行基本视频可见性检查，不执行额外操作
  },

  handleShareVideo() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  // 官方分享API
  onShareAppMessage(e) {
    // 从按钮的 dataset 中获取视频信息
    const { videoInfo } = e.target.dataset;
    return {
      title: videoInfo ? videoInfo.title : '美甲喷绘视频',
      path: '/pages/index/index',
      imageUrl: videoInfo ? videoInfo.coverUrl : '/images/default-cover.png',
      success: function() {
        wx.showToast({
          title: '分享成功',
          icon: 'success'
        });
      },
      fail: function() {
        wx.showToast({
          title: '分享失败',
          icon: 'none'
        });
      }
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '美甲喷绘视频',
      query: '',
      imageUrl: '/images/default-cover.png'
    }
  },

  // 处理视频卡片点击 - 恢复该功能，允许弹窗出现
  onVideoCardTap(e) {
    console.log('【主页关键跟踪】onVideoCardTap被调用 - 时间戳:', new Date().getTime());
    console.log('【主页关键跟踪】事件类型:', e.type);
    console.log('【主页关键跟踪】事件来源:', e.currentTarget ? e.currentTarget.id : '未知');
    console.log('【主页关键跟踪】事件细节:', JSON.stringify(e.detail || {}));
    
    // 检查是否有视频信息
    if (!e.detail || !e.detail.videoInfo) {
      console.warn('【主页关键跟踪】错误：事件中没有视频信息，无法显示详情');
      
      // 备用方案：如果没有在detail中找到videoInfo，尝试从dataset获取
      if (e.currentTarget && e.currentTarget.dataset && e.currentTarget.dataset.videoInfo) {
        console.log('【主页关键跟踪】从dataset获取备用视频信息');
        const videoInfo = e.currentTarget.dataset.videoInfo;
        this.openVideoDetail(videoInfo);
        return;
      }
      
      return;
    }
    
    const videoInfo = e.detail.videoInfo;
    console.log('【主页关键跟踪】获取到视频信息:', JSON.stringify({
      id: videoInfo.id,
      title: videoInfo.title,
      hasVideoUrl: !!videoInfo.videoUrl
    }));
    
    // 使用提取的方法打开视频详情
    this.openVideoDetail(videoInfo);
  },
  
  // 提取的方法：打开视频详情
  openVideoDetail(videoInfo) {
    // 设置当前视频信息
    this.setData({
      currentVideo: videoInfo,
      showVideoDetail: true
    }, () => {
      // 找到详情组件并调用show方法
      const videoDetailComponent = this.selectComponent('#video-detail');
      if (videoDetailComponent) {
        videoDetailComponent.show();
      }
    });
  },

  // 页面触底事件
  onReachBottom() {
    if (!this.data.loading && this.data.hasMore) {
      this.loadVideos();
    }
  },

  // 加载视频列表
  async loadVideos() {
    if (this.data.loading || !this.data.hasMore) return;

    // 设置loading状态但不输出日志
    this.setData({ loading: true });

    try {
      // 静默调用云函数
      const res = await wx.cloud.callFunction({
        name: 'getVideoList',
        data: {
          cosConfig: getApp().globalData.appConfig.cos  // 从全局配置中获取 COS 配置
        }
      });

      const newVideos = res.result.data || [];
      
      // 批量更新数据，减少setData次数
      this.setData({
        videoList: [...this.data.videoList, ...newVideos],
        page: this.data.page + 1,
        hasMore: newVideos.length === this.data.limit,
        loading: false
      });
    } catch (error) {
      // 保留错误日志但简化内容
      console.error('视频加载失败', error ? error.message : '未知错误');
      this.setData({ loading: false });
    }
  },

  loadData(/* silent = false */) {
    // 获取必要的系统信息，删除未使用的变量
    const windowInfo = wx.getWindowInfo();
    const statusBarHeight = windowInfo.statusBarHeight;
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
    const menuButtonHeight = menuButtonInfo.height;
    const menuButtonTop = menuButtonInfo.top;
    
    const safeAreaTop = menuButtonTop + menuButtonHeight + 10;
    
    // 批量设置数据，减少setData调用次数
    this.setData({
      statusBarHeight: statusBarHeight,
      screenHeight: windowInfo.windowHeight,
      safeAreaTop: safeAreaTop,
      isDetailShow: false,
      hasFirstScroll: false,
      initializing: true,
      isBottomBarVisible: true,
    });
    
    // 设置导航栏颜色但不使用动画，减少闪烁
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: 'transparent',
      animation: {
        duration: 0,
        timingFunc: 'linear'
      }
    });
    
    // 设置底部导航栏选中状态
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 0  // 0表示当前是视频页面
      });
    }
    
    // 加载视频列表
    this.loadVideos();
  },

  refreshConfig: function() {
    const app = getApp()
    
    // 显示加载提示
    wx.showLoading({
      title: '验证配置中...',
    })
    
    // 调用app中的验证方法
    app.verifyConfig().then(valid => {
      wx.hideLoading()
      
      if (valid) {
        this.setData({
          configValid: true
        })
        
        // 直接加载数据，不需要用户手动刷新
        this.loadData()
      } else {
        wx.showToast({
          title: '配置无效',
          icon: 'none'
        })
      }
    }).catch(err => {
      wx.hideLoading()
      console.error('刷新配置失败:', err)
      
      wx.showToast({
        title: '验证失败，请重试',
        icon: 'none'
      })
    })
  },

  onPullDownRefresh: function() {
    console.log('下拉刷新触发');
    
    // 手动触发验证
    const app = getApp();
    app.verifyConfig().then(valid => {
      console.log('验证结果:', valid);
      wx.stopPullDownRefresh();
    }).catch(err => {
      console.error('验证失败:', err);
      wx.stopPullDownRefresh();
    });
  },

  // 在页面中添加一个函数来手动触发验证
  testVerification: function() {
    console.log('手动触发验证');
    
    const app = getApp();
    wx.showLoading({
      title: '验证中...',
    });
    
    app.verifyConfig().then(valid => {
      wx.hideLoading();
      console.log('验证结果:', valid);
      
      wx.showToast({
        title: valid ? '验证成功' : '验证失败',
        icon: valid ? 'success' : 'none'
      });
    }).catch(err => {
      wx.hideLoading();
      console.error('验证失败:', err);
      
      wx.showToast({
        title: '验证出错',
        icon: 'none'
      });
    });
  },

  // 添加一个方法来隐藏测试按钮
  hideTestButton: function() {
    this.setData({
      showTestButton: false
    });
  },

  // 添加导航方法
  goToGallery: function() {
    wx.switchTab({
      url: '/pages/gallery/gallery'
    });
  },
  goToWaterfall: function() {
    wx.switchTab({
      url: '/pages/waterfall/waterfall'
    });
  },

  // 在App实例初始化后调用，用于检测DOM变化
  initDomMonitor() {
    console.log('[调试-闪屏] 初始化DOM监控');
    
    try {
      // 保存临时的样式变化记录
      this._styleChanges = [];
      
      // 每100ms检查一次主要容器的样式变化
      this._domMonitorInterval = setInterval(() => {
        if (!this._domMonitorActive) {
          clearInterval(this._domMonitorInterval);
          return;
        }
        
        this.checkDomStyles();
      }, 100);
      
      // 20秒后自动停止监控
      setTimeout(() => {
        this.stopDomMonitor();
      }, 20000);
      
      this._domMonitorActive = true;
      console.log('[调试-闪屏] DOM监控已启动');
    } catch (e) {
      console.error('[调试-闪屏] 初始化DOM监控失败', e);
    }
  },
  
  stopDomMonitor() {
    if (this._domMonitorInterval) {
      clearInterval(this._domMonitorInterval);
      this._domMonitorInterval = null;
    }
    
    this._domMonitorActive = false;
    console.log('[调试-闪屏] DOM监控已停止');
    
    // 输出收集到的变化
    if (this._styleChanges && this._styleChanges.length > 0) {
      console.log('[调试-闪屏] 样式变化记录:', this._styleChanges);
      
      // 分析快速变化
      this.analyzeStyleChanges();
    } else {
      console.log('[调试-闪屏] 未检测到样式变化');
    }
  },
  
  checkDomStyles() {
    try {
      const query = wx.createSelectorQuery();
      
      // 监测主容器
      query.select('.container').fields({
        computedStyle: ['background', 'opacity', 'visibility', 'display'],
        rect: true,
        dataset: true
      }, (res) => {
        if (res) {
          const timestamp = new Date().getTime();
          this._styleChanges.push({
            time: timestamp,
            element: '.container',
            styles: res
          });
        }
      });
      
      // 监测启动页容器
      query.select('.launch-container').fields({
        computedStyle: ['opacity', 'visibility', 'display', 'transform'],
        rect: true
      }, (res) => {
        if (res) {
          const timestamp = new Date().getTime();
          this._styleChanges.push({
            time: timestamp,
            element: '.launch-container',
            styles: res
          });
        }
      });
      
      query.exec();
    } catch (e) {
      console.error('[调试-闪屏] 检查DOM样式失败', e);
    }
  },
  
  analyzeStyleChanges() {
    if (!this._styleChanges || this._styleChanges.length < 2) return;
    
    // 根据时间排序
    this._styleChanges.sort((a, b) => a.time - b.time);
    
    // 查找快速变化（可能导致闪烁的变化）
    let flashPoints = [];
    
    for (let i = 1; i < this._styleChanges.length; i++) {
      const current = this._styleChanges[i];
      const prev = this._styleChanges[i-1];
      
      // 同一元素的变化
      if (current.element === prev.element) {
        const timeDiff = current.time - prev.time;
        
        // 检查是否有快速变化（小于100ms）
        if (timeDiff < 100) {
          // 检查关键属性是否有变化
          const hasVisibilityChange = 
            current.styles.visibility !== prev.styles.visibility ||
            current.styles.display !== prev.styles.display ||
            current.styles.opacity !== prev.styles.opacity;
          
          if (hasVisibilityChange) {
            flashPoints.push({
              time: current.time,
              element: current.element,
              timeDiff,
              before: prev.styles,
              after: current.styles
            });
          }
        }
        
        // 检查背景色变化
        if (current.styles.background !== prev.styles.background) {
          flashPoints.push({
            time: current.time,
            element: current.element,
            timeDiff,
            change: 'background',
            before: prev.styles.background,
            after: current.styles.background
          });
        }
      }
    }
    
    // 输出可能的闪烁点
    if (flashPoints.length > 0) {
      console.warn('[调试-闪屏] 检测到可能导致闪烁的变化点:', flashPoints);
    } else {
      console.log('[调试-闪屏] 未检测到可能导致闪烁的变化');
    }
  },

  // 添加渲染性能监测
  startPerformanceMonitoring() {
    console.log('[调试-闪屏] 开始性能监测');
    
    // 记录开始时间
    this._perfStart = new Date().getTime();
    this._perfMarks = [];
    
    // 每隔短时间记录关键指标
    const capturePerf = () => {
      if (!this._perfMonitorActive) return;
      
      const now = new Date().getTime();
      const elapsed = now - this._perfStart;
      
      // 记录当前内存情况
      if (wx.getPerformance) {
        try {
          const performance = wx.getPerformance();
          const memory = performance.getMemoryInfo ? 
                         performance.getMemoryInfo() : 
                         { jsHeapSizeLimit: 'NA', totalJSHeapSize: 'NA', usedJSHeapSize: 'NA' };
          
          // 获取网络状态
          wx.getNetworkType({
            success: (res) => {
              const networkType = res.networkType;
              
              // 记录性能标记
              this._perfMarks.push({
                time: now,
                elapsed,
                memory,
                networkType,
                event: 'periodic'
              });
            }
          });
        } catch (e) {
          console.error('[调试-闪屏] 性能监测错误', e);
        }
      }
      
      // 继续监测
      if (this._perfMonitorActive && elapsed < 10000) {
        setTimeout(capturePerf, 200);
      } else {
        this.stopPerformanceMonitoring();
      }
    };
    
    // 记录重要事件的性能
    this.markPerformance = (eventName) => {
      if (!this._perfMonitorActive) return;
      
      const now = new Date().getTime();
      this._perfMarks.push({
        time: now,
        elapsed: now - this._perfStart,
        event: eventName
      });
    };
    
    this._perfMonitorActive = true;
    capturePerf();
    
    // 10秒后自动停止
    setTimeout(() => {
      this.stopPerformanceMonitoring();
    }, 10000);
  },
  
  stopPerformanceMonitoring() {
    if (!this._perfMonitorActive) return;
    
    this._perfMonitorActive = false;
    console.log('[调试-闪屏] 性能监测结束');
    
    // 输出收集到的性能数据
    if (this._perfMarks && this._perfMarks.length > 0) {
      console.log('[调试-闪屏] 性能监测记录:', this._perfMarks);
      
      // 查找可能的性能问题
      this.analyzePerformance();
    } else {
      console.log('[调试-闪屏] 未收集到性能数据');
    }
  },
  
  analyzePerformance() {
    if (!this._perfMarks || this._perfMarks.length < 2) return;
    
    // 查找性能下降点
    let performanceIssues = [];
    
    // 分析内存使用
    const memoryMarks = this._perfMarks.filter(mark => 
      mark.memory && mark.memory.usedJSHeapSize !== 'NA'
    );
    
    if (memoryMarks.length >= 2) {
      for (let i = 1; i < memoryMarks.length; i++) {
        const current = memoryMarks[i];
        const prev = memoryMarks[i-1];
        
        // 内存快速增长可能导致性能问题
        if (current.memory.usedJSHeapSize > prev.memory.usedJSHeapSize * 1.2) {
          performanceIssues.push({
            type: 'memory-growth',
            time: current.time,
            before: prev.memory.usedJSHeapSize,
            after: current.memory.usedJSHeapSize,
            growthRate: (current.memory.usedJSHeapSize / prev.memory.usedJSHeapSize)
          });
        }
      }
    }
    
    // 查找事件时间间隔异常
    const events = this._perfMarks.filter(mark => mark.event !== 'periodic');
    
    if (events.length >= 2) {
      for (let i = 1; i < events.length; i++) {
        const current = events[i];
        const prev = events[i-1];
        
        // 事件间隔过长可能表明渲染卡顿
        const gap = current.time - prev.time;
        if (gap > 500) {
          performanceIssues.push({
            type: 'event-delay',
            time: current.time,
            events: [prev.event, current.event],
            gap
          });
        }
      }
    }
    
    // 输出性能问题
    if (performanceIssues.length > 0) {
      console.warn('[调试-闪屏] 检测到可能的性能问题:', performanceIssues);
    } else {
      console.log('[调试-闪屏] 未检测到明显的性能问题');
    }
  },

  // 条件化调试函数，只在开发模式可用
  debugShowVideoDetail: function() {
    // 在生产环境下禁用此功能
    if (!IS_DEV_MODE) {
      console.warn('Debug function disabled in production');
      return;
    }
    
    // 只在有视频数据且开发模式下执行
    if (this.data.videoList && this.data.videoList.length > 0) {
      const testVideo = this.data.videoList[0];
      
      // 设置视频信息和显示状态
      this.setData({
        currentVideo: testVideo,
        showVideoDetail: true
      }, () => {
        // 检查组件实例
        const videoDetailComponent = this.selectComponent('#video-detail');
        
        // 如果找到组件，调用其show方法
        if (videoDetailComponent) {
          try {
            videoDetailComponent.show();
          } catch (error) {
            console.error('调用show方法失败:', error);
          }
        }
      });
    } else {
      wx.showToast({
        title: '没有视频数据',
        icon: 'none'
      });
    }
  },

  // 视频详情关闭事件处理
  onVideoDetailClose() {
    console.log('[导航栏监测] 视频详情关闭事件触发');
    
    // 更新页面状态
    this.setData({
      showVideoDetail: false,
      currentVideo: null
    });
    
    // 直接从页面刷新导航栏状态
    setTimeout(() => {
      try {
        const tabBar = this.getTabBar();
        if (tabBar) {
          console.log('[导航栏监测] 页面主动刷新导航栏');
          tabBar.forceRefresh();
        }
      } catch (e) {
        console.error('[导航栏监测] 页面刷新导航栏失败:', e);
      }
    }, 100);
  }
})

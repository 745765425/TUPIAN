/* global Component, wx, getCurrentPages */

Component({
  data: {
    selected: 0,
    isVisible: true,
    color: "#AEAEAE",
    selectedColor: "#ffffff",
    backgroundColor: "#333333",
    list: [
      {
        pagePath: "/pages/index/index",
        text: "Browse",
        iconPath: "/static/视频图标暗.png",
        selectedIconPath: "/static/视频图标亮.png"
      },
      {
        pagePath: "/pages/gallery/gallery",
        text: "More",
        iconPath: "/static/主页图标暗.png",
        selectedIconPath: "/static/主页图标亮.png"
      }
    ]
  },

  observers: {
    '**': function() {
      this.updateSelectedByRoute();
    }
  },

  lifetimes: {
    attached() {
      // 生成唯一ID以识别不同实例
      this._instanceId = Math.random().toString(36).substr(2, 9);
      console.log(`[TabBar Debug] 实例 ${this._instanceId} 被创建`);
      
      console.log('[导航栏监测] 组件初始化 - 时间:', new Date().toISOString());
      
      // 初始化时直接检查状态
      const visible = wx.getStorageSync('tabBarVisible') !== false;
      console.log('[导航栏监测] 初始化状态:', visible);
      
      this.setData({ isVisible: visible });
      
      // 更新选中状态
      this.updateSelectedByRoute();
      
      // 监听存储变化 - 每300ms检查一次
      this.visibilityTimer = setInterval(() => {
        // 先检查是否处于锁定状态
        const isLocked = !!wx.getStorageSync('tabBarLocked');
        if (isLocked) {
          console.log('[导航栏监测] 导航栏处于锁定状态，暂停状态检查');
          return; // 如果锁定，暂停状态检查
        }
        
        // 检查前记录当前状态
        const prevVisibility = this.data.isVisible;
        
        // 读取存储中的值
        const rawStorageValue = wx.getStorageSync('tabBarVisible');
        const visible = rawStorageValue !== false;
        
        // 检查值是否变化
        if (prevVisibility !== visible) {
          console.log('==========================================');
          console.log('[导航栏监测] 状态变化:', prevVisibility, '->', visible);
          console.log('[导航栏监测] 存储原始值:', rawStorageValue);
          console.log('[导航栏监测] 变化时间:', new Date().toISOString());
          
          // 记录当前页面信息
          const pages = getCurrentPages();
          const currentPage = pages.length > 0 ? pages[pages.length - 1].route : '无页面';
          console.log('[导航栏监测] 当前页面:', currentPage);
          
          // 记录调用栈帮助定位代码
          try {
            throw new Error('导航栏状态变更跟踪');
          } catch (err) {
            console.log('[导航栏监测] 调用栈:\n', err.stack);
          }
          
          // 应用新状态
          this.setData({ isVisible: visible });
          console.log('[导航栏监测] 已更新组件状态为:', visible);
          console.log('==========================================');
        }
        
        // 更新选中状态
        this.updateSelectedByRoute();
      }, 300);
    },
    
    detached() {
      // 清除监听器
      if (this.visibilityTimer) {
        clearInterval(this.visibilityTimer);
        this.visibilityTimer = null;
      }
    }
  },

  methods: {
    // 更新选中状态
    updateSelectedByRoute() {
      const pages = getCurrentPages();
      if (pages.length === 0) return;
      
      const currentPage = pages[pages.length - 1];
      const currentPath = '/' + currentPage.route;
      
      const index = this.data.list.findIndex(item => item.pagePath === currentPath);
      if (index !== -1 && this.data.selected !== index) {
        this.setData({ selected: index });
      }
    },

    // 在切换前预加载目标页面资源
    switchTab(e) {
      const dataset = e.currentTarget.dataset;
      const index = dataset.index;
      const path = dataset.path;
      
      // 避免重复切换同一页面
      if (this.data.selected === index) {
        return;
      }
      
      // 预加载目标页面数据
      this.preloadTargetPageData(path);
      
      // 更新选中状态
      this.setData({ selected: index });
      wx.setStorageSync('tabBarIndex', index);
      
      // 切换页面
      wx.switchTab({ url: path });
    },
    
    // 预加载目标页面数据
    preloadTargetPageData(path) {
      const app = getApp();
      
      // 如果是切换到瀑布流页面
      if (path.includes('gallery')) {
        if (app && typeof app.preloadGalleryData === 'function') {
          app.preloadGalleryData();
        }
      } 
      // 如果是切换到视频列表页面
      else if (path.includes('index')) {
        if (app && typeof app.preloadVideoData === 'function') {
          app.preloadVideoData();
        }
      }
    },
    
    // 直接从页面调用的强制刷新方法
    forceRefresh() {
      // 添加防重复刷新保护
      const now = Date.now();
      if (this._lastRefreshTime && (now - this._lastRefreshTime < 100)) {
        console.log('[TabBar Debug] 防止频繁刷新');
        return;
      }
      this._lastRefreshTime = now;
      
      // 读取当前应该的状态
      const visible = wx.getStorageSync('tabBarVisible') !== false;
      
      // 强制更新显示状态
      this.setData({ isVisible: visible });
      
      console.log('[导航栏监测] 标签栏状态已强制刷新:', visible);
    },
    
    // 增强版的show方法，同时设置存储状态
    show() {
      console.log(`[TabBar Debug] 实例 ${this._instanceId} 被显示`);
      // 打印调用堆栈追踪显示来源
      console.log(new Error().stack);
      
      // 同步更新存储和组件状态
      wx.setStorageSync('tabBarVisible', true);
      this.setData({ isVisible: true });
    },
    
    // 增强版的hide方法，同时设置存储状态
    hide() {
      console.log('[导航栏监测] TabBar.hide()方法被直接调用');
      
      // 同步更新存储和组件状态
      wx.setStorageSync('tabBarVisible', false);
      this.setData({ isVisible: false });
    },

    updateSelected() {
      this.updateSelectedByRoute();
    }
  }
}); 
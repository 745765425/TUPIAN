/**
 * 美甲视频小程序配置文件
 * 
 * ===== 存储桶结构指南 =====
 * 
 * 小程序需要以下文件夹结构：
 * 
 * 1. 视频列表/ - 存放所有视频文件
 *    - 视频命名建议：video_001.mp4, video_002.mp4 等
 *    - 每个视频需要对应的封面图：video_001_cover.jpg 等
 * 
 * 2. 图片/ - 存放一般图片资源
 *    - 分类图片：category_nail.png, category_makeup.png 等
 *    - 广告图片：ad_001.jpg, ad_002.jpg 等
 *    - 其他图片资源
 * 
 * 3. 头像/ - 存放用户头像
 *    - 默认头像：默认头像.webp (必须存在)
 *    - 用户上传的头像将自动保存到此文件夹
 * 
 * 4. 图标/ - 存放界面图标
 *    - 分享图标.svg (必须存在)
 *    - 静音图标.svg (必须存在)
 *    - 非静音图标.svg (必须存在)
 *    - 其他界面图标
 * 
 * 5. 启动页/ - 存放启动页资源
 *    - qidongye1.svg (必须存在)
 *    - qidongye2.webp (必须存在)
 *    - qidongye3.webp (必须存在)
 *    - qidongye4.svg (必须存在)
 * 
 * ===== 客户必须修改的配置 =====
 * 1. 云环境ID (cloud.envId)
 * 2. COS存储桶URL (cos.baseUrl)
 * 3. COS存储桶地区 (cos.region)
 * 4. COS存储桶名称 (cos.bucket)
 * 5. COS SecretId (cos.secretId)
 * 6. COS SecretKey (cos.secretKey)
 * 
 * ===== 客户可选修改的配置 =====
 * 1. 应用名称 (app.name)
 * 2. 应用版本号 (app.version)
 * 3. 联系邮箱 (app.contactEmail)
 * 4. 文件夹结构 (cos.folders) - 如果您的存储桶使用了不同的文件夹名称
 * 5. 默认资源配置 (cos.defaults) - 如果您的资源文件使用了不同的名称
 * 
 * ===== 严禁修改的配置 =====
 * 1. 版权信息 (copyright)
 * 
 * 注意：请勿修改版权信息，否则程序将无法正常运行
 */
module.exports = {
  // ===== 版权信息 (严禁修改) =====
  copyright: {
    author: "骆刚",  // 作者姓名
    contact: "naildidi",  // 微信号
    license: "商业授权",
    verificationCode: "19925762035",  // 手机号，用于验证和联系
    email: "745765426@qq.com"  // 邮箱，用于验证和联系
  },
  
  // ===== 云开发环境配置 =====
  cloud: {
    envId: 'nail-spray-cloud-1f7k6g24bb56801',  // 云环境ID
  },
  
  // ===== 腾讯云COS存储配置 =====
  cos: {
    // 基本配置
    baseUrl: 'https://naildidi-1342588805.cos.ap-guangzhou.myqcloud.com',
    region: 'ap-guangzhou',
    bucket: 'naildidi-1342588805',
    
    // COS SDK配置 (从 getVideoList/config.json 迁移过来)
    secretId: 'AKIDOeeNr52jDRPH3e0AGAnkV1GGzSeZEckb',    // 从 config.json 迁移
    secretKey: 'cy4uVpthEVWHl160h9LIzQcZHkyxgAPP',       // 从 config.json 迁移
    
    // 文件夹结构
    folders: {
      videos: '视频列表/',
      images: '图片/',
      avatars: '头像/',
      icons: '图标/'
    },
    
    // 默认资源配置
    defaults: {
      avatar: '头像/骆刚.webp',
      userAvatars: [
        '头像/骆刚.webp',
        '头像/骆刚.webp',
        '头像/骆刚.webp',
        '头像/骆刚.webp',
        '头像/骆刚.webp',
      ]
    },
    
    // 添加启动页图片配置
    launchImages: {
      urls: [
        'https://naildidi-1342588805.cos.ap-guangzhou.myqcloud.com/启动页/qidongye1.webp',
        'https://naildidi-1342588805.cos.ap-guangzhou.myqcloud.com/启动页/qidongye2.webp'
      ]
    }
  },
  
  // ===== 数据库集合名称配置 =====
  db: {
    collections: {
      videos: 'videos',
      users: 'users',
      comments: 'comments',
    }
  },
  
  // ===== 应用基本配置 =====
  app: {
    name: '美甲视频',
    version: '1.0.0',
    contactEmail: 'naildidi@qq.com',
  },
  
  // ===== 视频相关配置 =====
  video: {
    namingPattern: {
      video: /^video_(\d+)\.mp4$/,
      cover: /^video_(\d+)_cover\.jpg$/
    },
    categories: [
      { id: 'all', name: '全部' },
      { id: 'popular', name: '热门' },
      { id: 'new', name: '最新' },
      { id: 'nail', name: '美甲' },
      { id: 'makeup', name: '化妆' }
    ],
    playback: {
      autoplay: true,
      loop: true,
      muted: false
    }
  },
  
  // ===== 本地资源路径 =====
  local: {
    images: {
      defaultAvatar: '/static/logo.png',
      logo: '/static/logo.png',
      navBarBg: '/static/导航栏.svg',
      qrcode: '/static/二维码.jpg'
    },
    icons: {
      share: '/static/发送图标.svg',
      mute: '/static/静音图标.svg',
      unmute: '/static/取消静音.svg',
      like: '/static/like.svg',
      comment: '/static/comment.svg',
      close: '/static/close.svg',
      favorite: '/static/favorite.svg',
      navBar: '/static/导航栏.svg',
      qrcode: '/static/二维码.jpg',
    }
  },
} 
Component({
  properties: {
    visible: {
      type: Boolean,
      value: false
    },
    current: {
      type: String,
      value: ''
    },
    urls: {
      type: Array,
      value: []
    }
  },

  data: {
    showActions: false,
    showActionSheet: false,
    showConfirm: false,
    confirmTitle: '',
    confirmContent: '',
    confirmType: '',
  },

  methods: {
    handleLongPress() {
      this.setData({ showActions: true });
    },

    handleCall() {
      console.log('点击了联系我们');
      this.setData({
        showActionSheet: true
      });
    },

    handleWechat() {
      wx.previewImage({
        urls: ['/images/qrcode.jpg']
      });
    },

    handleClose() {
      // 如果弹窗显示，则先关闭弹窗
      if (this.data.showActions) {
        this.setData({ showActions: false });
        return;  // 先关闭弹窗，不关闭预览
      }
      
      // 如果弹窗已关闭，则关闭整个预览
      this.setData({ showActions: false });
      this.triggerEvent('close');
    },

    preventClose(e) {
      e.stopPropagation();  // 阻止事件冒泡
    },

    handleSaveImage() {
      const current = this.data.current;
      
      // 先获取授权状态
      wx.getSetting({
        success: (res) => {
          if (!res.authSetting['scope.writePhotosAlbum']) {
            // 如果没有授权，先请求授权
            wx.authorize({
              scope: 'scope.writePhotosAlbum',
              success: () => {
                this.saveImage(current);
              },
              fail: () => {
                this.setData({
                  showConfirm: true,
                  confirmTitle: '授权提示',
                  confirmContent: '需要您授权保存图片到相册',
                  confirmType: 'auth'  // 这里是授权确认，需要按钮
                });
              }
            });
          } else {
            // 已经授权，直接保存
            this.saveImage(current);
          }
        }
      });
    },

    // 实际保存图片的方法
    saveImage(url) {
      wx.downloadFile({
        url: url,
        success: (res) => {
          wx.saveImageToPhotosAlbum({
            filePath: res.tempFilePath,
            success: () => {
              wx.showToast({
                title: '保存成功',
                icon: 'none',
                duration: 1500,
                mask: true
              });
            },
            fail: (err) => {
              console.error('保存图片失败:', err);
              wx.showToast({
                title: '保存失败',
                icon: 'none',
                duration: 1500
              });
            }
          });
        },
        fail: () => {
          wx.showToast({
            title: '下载失败',
            icon: 'none',
            duration: 1500
          });
        }
      });
    },

    handleActionSheetClose() {
      this.setData({
        showActionSheet: false
      });
    },

    handleShowConfirm(e) {
      this.setData({
        showConfirm: true,
        confirmTitle: e.detail.title,
        confirmContent: e.detail.content,
        confirmType: e.detail.type || ''  // 接收类型
      });
    },

    handleConfirm() {
      // 根据不同的确认类型执行不同的操作
      if (this.data.confirmType === 'auth') {
        wx.openSetting();  // 打开授权设置页面
      } else if (this.data.confirmType === 'phone') {
        // 拨打电话
        wx.makePhoneCall({
          phoneNumber: '19925762035'
        });
      }
      // 关闭确认弹窗
      this.handleConfirmClose();
    },

    handleConfirmClose() {
      this.setData({
        showConfirm: false
      });
    }
  },

  lifetimes: {
  }
}); 
/* global Component, wx, console, setTimeout */

const appConfig = require('../../config/app-config.js');

Component({
  options: {
    pureDataPattern: /^_/, // 优化数据更新性能
    styleIsolation: 'shared', // 优化样式性能
  },

  properties: {
    autoHideTime: {
      type: Number,
      value: 0  // 设为0表示不自动隐藏，等待用户点击
    }
  },

  data: {
    showLaunch: true,
    firstImage: '',
    secondImage: '',
    isFirstImageLoaded: false,
    isSecondImageLoaded: false,
    showSecondImage: false,
    _imageLoadRetries: {
      first: 0,
      second: 0
    },
    _maxRetries: 2
  },

  attached() {
    // 确保使用全局背景色，不设置自己的背景
    wx.setBackgroundColor({
      backgroundColor: '#1F1D2B',
      backgroundColorTop: '#1F1D2B',
      backgroundColorBottom: '#1F1D2B'
    });

    // 从配置文件获取启动页图片地址
    if (appConfig && appConfig.cos && appConfig.cos.launchImages && 
        appConfig.cos.launchImages.urls && 
        appConfig.cos.launchImages.urls.length >= 2) {
      
      this.setData({
        firstImage: appConfig.cos.launchImages.urls[0],
        secondImage: appConfig.cos.launchImages.urls[1]
      });
    } else {
      // 配置不存在时使用默认路径
      this.setData({
        firstImage: '/static/启动页1.jpg',
        secondImage: '/static/启动页2.jpg'
      });
    }
    
    // 预加载图片
    this.preloadImages();
    
    // 启动页一加载就开始预加载主页面资源
    this.preloadMainPageResources();
  },

  methods: {
    preloadImages() {
      const { firstImage, secondImage } = this.data;
      
      // 使用优化的预加载方法
      this.preloadImage(firstImage, 'first');
      this.preloadImage(secondImage, 'second');
      
      // 设置超时保护，最多等待3秒
      this.preloadTimeout = setTimeout(() => {
        // 如果图片加载超时，显示已加载的图片或默认图片
        if (!this.data.isFirstImageLoaded) {
          this.setData({ isFirstImageLoaded: true });
        }
        
        // 延迟显示第二张图片
        setTimeout(() => {
          this.setData({ 
            showSecondImage: true,
            isSecondImageLoaded: true 
          });
          
          // 2秒后触发关闭
          setTimeout(() => {
            this.handleClose();
          }, 2000);
        }, 1000);
      }, 3000);
    },
    
    // 预加载单张图片的优化方法
    preloadImage(src, imageType) {
      // 如果图片已经加载或者超过最大重试次数，则不再尝试
      if ((imageType === 'first' && this.data.isFirstImageLoaded) || 
          (imageType === 'second' && this.data.isSecondImageLoaded) ||
          this.data._imageLoadRetries[imageType] >= this.data._maxRetries) {
        return;
      }
      
      // 根据图片URL类型选择预加载方法
      if (src.startsWith('http')) {
        // 远程图片使用downloadFile
        wx.downloadFile({
          url: src,
          success: (res) => {
            if (res.statusCode === 200) {
              // 图片下载成功
              if (imageType === 'first') {
                this.setData({ isFirstImageLoaded: true });
                
                // 首张图片加载成功后等待1秒再显示第二张
                setTimeout(() => {
                  this.setData({ showSecondImage: true });
                }, 1000);
              } else {
                this.setData({ isSecondImageLoaded: true });
              }
              
              this.checkImagesLoaded();
            } else {
              this.handleImageError(src, imageType, 'Download error: ' + res.statusCode);
            }
          },
          fail: (err) => {
            this.handleImageError(src, imageType, err);
          }
        });
      } else {
        // 本地图片使用getImageInfo
        wx.getImageInfo({
          src: src,
          success: () => {
            // 图片加载成功
            if (imageType === 'first') {
              this.setData({ isFirstImageLoaded: true });
              
              // 首张图片加载成功后等待1秒再显示第二张
              setTimeout(() => {
                this.setData({ showSecondImage: true });
              }, 1000);
            } else {
              this.setData({ isSecondImageLoaded: true });
            }
            
            this.checkImagesLoaded();
          },
          fail: (err) => {
            this.handleImageError(src, imageType, err);
          }
        });
      }
    },
    
    // 检查两张图片是否都已加载
    checkImagesLoaded() {
      if (this.data.isFirstImageLoaded && this.data.isSecondImageLoaded) {
        // 两张图片都加载完成后，取消超时保护
        if (this.preloadTimeout) {
          clearTimeout(this.preloadTimeout);
        }
        
        // 如果设置了自动隐藏时间，启动定时器
        if (this.properties.autoHideTime > 0) {
          setTimeout(() => {
            this.handleClose();
          }, 2000);
        }
      }
    },
    
    // 处理图片加载错误
    handleImageError(src, imageType, err) {
      // 增加重试计数
      const retryCount = this.data._imageLoadRetries[imageType] + 1;
      this.setData({
        [`_imageLoadRetries.${imageType}`]: retryCount
      });
      
      // 记录错误但继续尝试
      console.error(`启动页图片(${imageType})加载失败:`, err);
      
      // 重试逻辑 - 每次失败后延迟增加
      if (retryCount <= this.data._maxRetries) {
        setTimeout(() => {
          this.preloadImage(src, imageType);
        }, retryCount * 500); // 递增延迟
      } else {
        // 达到最大重试次数，强制设置为已加载
        this.setData({
          [imageType === 'first' ? 'isFirstImageLoaded' : 'isSecondImageLoaded']: true
        });
        
        // 使用默认图片
        this.setData({
          [imageType === 'first' ? 'firstImage' : 'secondImage']: '/static/默认启动页.jpg'
        });
      }
    },

    handleClose() {
      // 清除任何未完成的计时器
      if (this.preloadTimeout) {
        clearTimeout(this.preloadTimeout);
      }
      
      // 更新全局状态，标记启动页已显示过
      const app = getApp();
      if (app.globalData) {
        app.globalData.hasShownLaunch = true;
      }
      
      // 更新存储状态
      wx.setStorageSync('launchPageShowing', false);
      wx.setStorageSync('hasShownLaunch', true);
      
      // 设置关闭动画
      this.setData({ showLaunch: false });
      
      // 等待关闭动画完成后再通知状态变化
      setTimeout(() => {
        // 关闭完成后，允许显示TabBar
        wx.setStorageSync('tabBarVisible', true);
        
        // 触发关闭事件
        this.triggerEvent('close');
      }, 800); // 与CSS中的淡出动画时长匹配
    },

    // 预加载主页面资源
    preloadMainPageResources() {
      // 获取全局应用实例
      const app = getApp();
      
      // 启动时立即开始加载视频列表数据
      if (app && typeof app.preloadVideoData === 'function') {
        app.preloadVideoData();
      }
      
      // 预加载瀑布流第一页数据
      if (app && typeof app.preloadGalleryData === 'function') {
        app.preloadGalleryData();
      }
    }
  },
  
  detached() {
    // 组件销毁时清理计时器，防止内存泄漏
    if (this.preloadTimeout) {
      clearTimeout(this.preloadTimeout);
    }
  }
}); 
# 启动页组件

## 组件说明

该组件用于显示应用启动时的启动页面，提供图片轮播效果和自动消失功能。

## 功能特点

- 自动轮播多张启动页图片
- 支持本地和远程图片加载
- 预加载图片，确保显示流畅
- 自动计时消失，无需用户手动点击
- 支持失败回退机制，确保启动页始终能够显示

## 使用方法

### 基本用法

```xml
<qidongye1 bind:close="onLaunchClose" autoHideTime="{{6000}}"/>
```

### 属性说明

| 属性名 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| interval | Number | 3000 | 图片轮播间隔时间(毫秒) |
| autoHideTime | Number | 6000 | 启动页自动隐藏时间(毫秒) |
| currentIndex | Number | 0 | 初始显示的图片索引 |
| type | String | 'launch' | 组件类型，可选值：'launch'、'main' |
| showClearCache | Boolean | false | 是否显示清除缓存按钮 |

### 事件说明

| 事件名 | 说明 | 返回值 |
| --- | --- | --- |
| close | 启动页关闭时触发 | {} |

## 注意事项

1. 启动页将在设定的时间(autoHideTime)后自动消失，无需用户手动点击
2. 图片加载失败时会自动回退到默认图片
3. 组件卸载时会自动清理所有定时器
4. 如需手动控制启动页持续时间，可调整autoHideTime属性

## 版本历史

- v1.0.0: 初始版本
- v1.1.0: 添加自动消失功能，去除点击入口

## 配置说明

图片和动画配置在 config/qidongye/images.js 中:
```javascript
module.exports = {
  launchImages: [
    {
      id: 'launch1',
      url: '图片1地址'
    },
    {
      id: 'launch2',
      url: '图片2地址'
    },
    {
      id: 'launch3',
      url: '图片3地址'
    }
  ],
  animation: {
    duration: 1200,
    timingFunction: 'ease-out',
    delay: 0
  }
};
``` 
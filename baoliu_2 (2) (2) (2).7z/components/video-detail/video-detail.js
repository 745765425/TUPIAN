/* global Component, wx, getApp, setTimeout, clearTimeout, console, getCurrentPages */

Component({
  options: {
    styleIsolation: 'isolated'
  },

  properties: {
    videoInfo: {
      type: Object,
      value: {},
      observer: function(newVal) {
        if (newVal) {
          // 保存视频信息
          this.setData({
            currentVideo: newVal
          });
        }
      }
    },
    isPopupShow: {
      type: Boolean,
      value: false,
      observer: function(newVal, oldVal) {
        if (newVal === true) {
          this.show();
        } else if (newVal === false) {
          this.hide();
        }
      }
    },
    isVisible: Boolean
  },
  
  data: {
    // 移除未使用的状态
    isVideoLoading: false,
    isPlaying: false,
    controlsVisible: true,
    isPanelShow: false,
    playerHeight: 0,
    minPlayerHeight: 0,
    maxPlayerHeight: 0,
    videoLoaded: false,
    hideVideo: false,
    panelTranslateY: 0, // 面板位移
    minPanelHeight: 300, // 面板最小高度
    maxPanelHeight: 600, // 面板最大高度
    
    touchStartY: 0,
    touchMoveY: 0,
    isDragging: false,
    
    videoError: false, // 视频错误状态
    
    isLiked: false, // 是否已点赞
    likeCount: 0, // 点赞数
    commentCount: 0, // 评论数
    comments: [], // 评论数据
    
    commentText: '', // 评论文本
    commentInputFocus: false, // 评论输入框焦点
    
    userInfo: null, // 用户信息
    animationData: {}, // 动画数据
    
    menuButtonTop: 44,  // 胶囊按钮的top值
    menuButtonHeight: 32,  // 胶囊按钮的高度
    statusBarHeight: 0,  // 状态栏高度（近似值）
    progress: 0,
    currentTime: '00:00',
    totalTime: '00:00',
    controlsTimer: null,    // 控制栏隐藏定时器
    isFullscreen: false,  // 添加全屏状态标记
    showFullscreenControls: false,  // 全屏控制栏显示状态
    touchStartX: 0,
    touchStartTime: 0,
    videoDuration: 0,
    hintTime: '00:00',
    hintLeft: 0,
    isSwiping: false,  // 添加滑动状态标记
    videoOrientation: 'horizontal', // 'horizontal' 或 'vertical'
    page: 1,
    pageSize: 20,
    hasMore: true,
    isLoading: false,
    isRefreshing: false,
    inputPopupHeight: 0,  // 输入弹窗的高度
    inputPopupTop: 0,    // 输入弹窗的顶部位置
    isCommentPopupShow: false,  // 控制评论弹窗显示
    displayTitle: '',  // 用于显示的标题
    activeTabIndex: 0,  // 从1改为0，默认显示产品介绍页
    isProductRefreshing: false,  // 产品页的刷新状态
    productRefreshing: false,
    hidden: true,  // 添加hidden属性，默认为隐藏状态
    defaultAvatar: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAEkUlEQVR4nO2ZW2xUVRSGv7kxhpCQGAMPPqgxvnhL1AQTYwwxRl8kRl+QxAQTjYkxvqgxgSCUmQ7TmZY0jdDQFkpbCr0BLZdSCqXQFiilpdwKpUBbyrWlpdBSZk5njme7z+Sc2TOdOe0ZZID0T/6kSfZa/1r/XnvvtfY+E/7HfxQBYDWwG+gErgEDwDAwCowBfwJ9QAfQBOwE1gAzJ3vhQWAn0AXcBP4BEsCEw3UDuAB8DKyYrMVPB94HzgF3gXHnS9+5c+cxEZGxsTFxk/Hxcbl165ZEo1G5fPmyRCIROXnypLS3t8vg4KAkEgk3U40DvwGfALPyXXwJcBi4nXnxWCwmPT09cuTIEdm/f7+0tLTI+fPnZXh4WFKplBuJTOIJ4CugLB8EyoF24E7mpQcGBqS1tVVaWlqkq6tLrly5IvF4XJLJpIyMjMj169elsrJSqqqqpLa2Vk6dOiWDg0OSTLqS+BvYD8zxQqAYaASGMi+qN9zf3y+XLl2SWCwm9+7dk0QiYS2sN6//Hx0dlb6+PmltbZW6ujqprq6Wzs5OGR4ezmXOu8BRYH4uBBYBx4G7mZe9f/++xONxGRoakhs3bkh3d7fU19dLQ0ODdHR0WBvXm9eEYrGYVFRUSGVlpRw/flz6+/tzIfE38DUwP5XEPOBLYDTbhvUG9YZ7e3ulra1NTp48KdXV1VJbWyuNjY3S3NwsZ86ckfb2drly5YrEYjEZGBiQ8+fPy7Fjx6SqqkrOnj0rt2/fzkXGBPAjsAiYaSegw+W3bBvWG9KbvHr1qvT09FgbP3TokBw8eNDa/JEjR6S5uVna2tqkt7dXBgcHZWxszDJxPB6XixcvSk1NjTQ1NUlvb68bCe1SXwIVwEeYPX9WAvqyOlzuZNuwDpfR0VFr43qzeuM6XPTm9b96w/F43DKp/q03r8NJz4XOzk5pbGyUmpoauX79ei4E9GV+HvgG+B5oBgYtEtlcSG9YN643rQ2qw0WTiEajlgt1dHRIc3OzHD582HKhpqYmy4W0gXW46FnR2toqJ06ckPr6eotuLi6UiYQOm1+Ao8BxoA64bJHI5kI6XPQGtRvpcNEbPnXqlNTV1UlDQ4O0t7dbm9cb1+GiSZw7d85yoZqaGsvY2qiZLpSNRKYL/QS8BbwBvA0cAP6ySGRzIW1MHS6aQDQatTavN3/27Fmprq6W+vp6OX36tOVCOlz0BrWBtYEbGxulqqpKTp48Kb29vbm4UDYSk+pCOlz0BrUb6XDRLqQ3X1tbK01NTZYLaQNrF9Lhogl0d3dbLlRZWSkXLlzI1YWykchwoZ+BN4HXgLeBH4B+i0Q2F9LhosNFb1C7kA4XvXntQtqFtAtpA+tw0S6kw0UbWLuQDhftQm4ulI2E3YW+Ad4AXgXeAvYBfRaJbC6kw0WHizawdiEdLnrz2oW0gbULaRfSBtbhol1Ih4t2IR0u2oVycSE7iWwutA94GXgFeAP4DvjDIpHNhXS46HDRBtYupMNFb167kDawdiHtQtrAOly0C+lw0S6kw0W70FRzof8w+fgXF00YRn5OCw0AAAAASUVORK5CYII=',
    icons: {
      close: '',
      share: '',
      like: '',
      comment: ''
    },
    avatarUrl: '/static/logo.png', // 使用 logo.png 作为头像
    startTime: 0,  // 视频应该从哪个位置开始播放
    waitingForSeek: false,  // 是否在等待视频跳转
    videoSrc: '', // 视频地址
    touchStartX: 0,
    touchStartTime: 0,
    hintTime: '00:00',
    hintLeft: 0,
    videoDuration: 0,
    showFullscreenControls: false,  // 全屏控制栏显示状态
    touchStartX: 0,
    touchStartTime: 0,
    videoDuration: 0,
    hintTime: '00:00',
    hintLeft: 0,
    isSwiping: false,  // 添加滑动状态标记
    videoOrientation: 'horizontal', // 'horizontal' 或 'vertical'
    page: 1,
    pageSize: 20,
    hasMore: true,
    isLoading: false,
    isRefreshing: false,
    inputPopupHeight: 0,  // 输入弹窗的高度
    inputPopupTop: 0,    // 输入弹窗的顶部位置
    isCommentPopupShow: false,  // 控制评论弹窗显示
    displayTitle: '',  // 用于显示的标题
    activeTabIndex: 0,  // 从1改为0，默认显示产品介绍页
    isProductRefreshing: false,  // 产品页的刷新状态
    productRefreshing: false,
    hidden: true,  // 添加hidden属性，默认为隐藏状态
    defaultAvatar: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAEkUlEQVR4nO2ZW2xUVRSGv7kxhpCQGAMPPqgxvnhL1AQTYwwxRl8kRl+QxAQTjYkxvqgxgSCUmQ7TmZY0jdDQFkpbCr0BLZdSCqXQFiilpdwKpUBbyrWlpdBSZk5njme7z+Sc2TOdOe0ZZID0T/6kSfZa/1r/XnvvtfY+E/7HfxQBYDWwG+gErgEDwDAwCowBfwJ9QAfQBOwE1gAzJ3vhQWAn0AXcBP4BEsCEw3UDuAB8DKyYrMVPB94HzgF3gXHnS9+5c+cxEZGxsTFxk/Hxcbl165ZEo1G5fPmyRCIROXnypLS3t8vg4KAkEgk3U40DvwGfALPyXXwJcBi4nXnxWCwmPT09cuTIEdm/f7+0tLTI+fPnZXh4WFKplBuJTOIJ4CugLB8EyoF24E7mpQcGBqS1tVVaWlqkq6tLrly5IvF4XJLJpIyMjMj169elsrJSqqqqpLa2Vk6dOiWDg0OSTLqS+BvYD8zxQqAYaASGMi+qN9zf3y+XLl2SWCwm9+7dk0QiYS2sN6//Hx0dlb6+PmltbZW6ujqprq6Wzs5OGR4ezmXOu8BRYH4uBBYBx4G7mZe9f/++xONxGRoakhs3bkh3d7fU19dLQ0ODdHR0WBvXm9eEYrGYVFRUSGVlpRw/flz6+/tzIfE38DUwP5XEPOBLYDTbhvUG9YZ7e3ulra1NTp48KdXV1VJbWyuNjY3S3NwsZ86ckfb2drly5YrEYjEZGBiQ8+fPy7Fjx6SqqkrOnj0rt2/fzkXGBPAjsAiYaSegw+W3bBvWG9KbvHr1qvT09FgbP3TokBw8eNDa/JEjR6S5uVna2tqkt7dXBgcHZWxszDJxPB6XixcvSk1NjTQ1NUlvb68bCe1SXwIVwEeYPX9WAvqyOlzuZNuwDpfR0VFr43qzeuM6XPTm9b96w/F43DKp/q03r8NJz4XOzk5pbGyUmpoauX79ei4E9GV+HvgG+B5oBgYtEtlcSG9YN643rQ2qw0WTiEajlgt1dHRIc3OzHD582HKhpqYmy4W0gXW46FnR2toqJ06ckPr6eotuLi6UiYQOm1+Ao8BxoA64bJHI5kI6XPQGtRvpcNEbPnXqlNTV1UlDQ4O0t7dbm9cb1+GiSZw7d85yoZqaGsvY2qiZLpSNRKYL/QS8BbwBvA0cAP6ySGRzIW1MHS6aQDQatTavN3/27Fmprq6W+vp6OX36tOVCOlz0BrWBtYEbGxulqqpKTp48Kb29vbm4UDYSk+pCOlz0BrUb6XDRLqQ3X1tbK01NTZYLaQNrF9Lhogl0d3dbLlRZWSkXLlzI1YWykchwoZ+BN4HXgLeBH4B+i0Q2F9LhosNFb1C7kA4XvXntQtqFtAtpA+tw0S6kw0UbWLuQDhftQm4ulI2E3YW+Ad4AXgXeAvYBfRaJbC6kw0WHizawdiEdLnrz2oW0gbULaRfSBtbhol1Ih4t2IR0u2oVycSE7iWwutA94GXgFeAP4DvjDIpHNhXS46HDRBtYupMNFb167kDawdiHtQtrAOly0C+lw0S6kw0W70FRzof8w+fgXF00YRn5OCw0AAAAASUVORK5CYII=',
    icons: {
      close: '',
      share: '',
      like: '',
      comment: ''
    },
    avatarUrl: '/static/logo.png', // 使用 logo.png 作为头像
    isPanelShow: false,
    startTime: 0,  // 视频应该从哪个位置开始播放
    waitingForSeek: false,  // 是否在等待视频跳转
    hideVideo: false, // 是否隐藏视频元素
    videoSrc: '', // 视频地址
    videoLoaded: false  // 添加标记，避免重复加载
  },
  
  lifetimes: {
    // 组件创建时
    created() {
      // 初始化基础配置
      this.initConfig();
      // 创建动画实例
      this.animation = wx.createAnimation({
        duration: 300,
        timingFunction: 'ease',
      });

      // 在组件实例刚刚被创建时就初始化缓存
      const app = getApp();
      this.videoCache = app.globalData.videoCache || new Map();
    },
    
    // 组件挂载时
    attached() {
      console.log('视频详情组件已附加');
      console.log('接收到的视频信息:', this.properties.videoInfo);
      
      // 获取系统信息
      const windowInfo = wx.getWindowInfo();
      const deviceInfo = wx.getDeviceInfo();
      
      const screenHeight = windowInfo.windowHeight;
      
      console.log('屏幕高度:', screenHeight);
      
      // 获取胶囊按钮位置信息
      const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
      
      this.setData({
        minPlayerHeight: screenHeight * 0.25,
        maxPlayerHeight: screenHeight * 0.5,
        playerHeight: screenHeight * 0.25,
        
        minPanelHeight: screenHeight * 0.48,
        maxPanelHeight: screenHeight * 0.68,
        
        menuButtonTop: menuButtonInfo.top,
        statusBarHeight: menuButtonInfo.top - 4,
        isVisible: false  // 确保初始状态为隐藏
      });
      
      // 初始化视频上下文（在组件挂载时就创建）
      try {
        this.videoContext = wx.createVideoContext('detail-video', this);
        console.log('视频上下文已初始化');
      } catch (error) {
        console.error('视频上下文初始化失败:', error);
      }
      
      // 初始化动画，但不执行显示动画
      this.animation = wx.createAnimation({
        duration: 300,
        timingFunction: 'ease',
      });
      
      // 设置初始位置（底部）
      this.animation.translateY('100%').step({duration: 0});
      this.setData({
        animationData: this.animation.export()
      });
      
      // 加载评论和点赞数据
      this.loadComments();
      this.loadLikeStatus();
      
      // 初始显示控制栏，并设置3秒后自动隐藏
      this.setData({ controlsVisible: true });
      this.autoHideControls();

      const app = getApp();
      const appConfig = app.globalData.appConfig;
      
      // 设置图标路径
      this.setData({
        'icons.close': appConfig.local.icons.close,
        'icons.share': appConfig.local.icons.share,
        'icons.like': appConfig.local.icons.like,
        'icons.comment': appConfig.local.icons.comment
      });

      // 这里太晚了，observers 可能在这之前就触发了
      this.videoCache = app.globalData.videoCache;
    },

    // 组件准备就绪时
    ready() {
      console.log('视频详情组件已准备就绪');
      console.log('当前属性:', {
        videoInfo: this.properties.videoInfo,
        isPopupShow: this.properties.isPopupShow
      });
      
      // 确保初始状态是隐藏的
      if (this.properties.hidden === false) {
        // 如果初始状态是显示的，执行显示动画
        this.show();
      } else {
        // 如果初始状态是隐藏的，确保位置在底部
        this.animation.translateY('100%').step({duration: 0});
        this.setData({
          animationData: this.animation.export()
        });
      }
      
      this.ensureVideoIndependence();
      // 添加检查尺寸
      this.checkPanelSize();
    },

    detached: function() {
      // 清理计时器，防止内存泄漏
      if (this.seekTimeoutTimer) {
        clearTimeout(this.seekTimeoutTimer);
      }

      // 组件销毁时清理
      if (this.videoContext) {
        this.videoContext.pause();
      }
    }
  },
  
  methods: {
    // 初始化基础配置
    initConfig() {
      // 设置基础事件处理
      this._videoTouchHandler = this.preventBubble.bind(this);
      
      // 增强版滚动事件隔离
      this._scrollEventHandler = (e) => {
        // 阻止滚动事件冒泡
        e.stopPropagation();
        
        // 标记组件已经检测到滚动
        this._hasScrolled = true;
        
        // 如果组件是可见状态，考虑关闭它
        if (this.properties.isPopupShow && !this._isClosingAnimation) {
          // 如果滚动超过一定阈值，直接关闭组件
          if (e.detail && e.detail.scrollTop > 10) {
            this.closeDetail();
            return;
          }
        }
        
        // 300ms后重置滚动标记，避免长期阻止交互
        if (this._scrollResetTimer) {
          clearTimeout(this._scrollResetTimer);
        }
        
        this._scrollResetTimer = setTimeout(() => {
          this._hasScrolled = false;
        }, 500); // 延长到500ms更安全
      };
      
      // 添加全局滚动监听
      this._addGlobalScrollListener();
    },

    // 新增：添加全局滚动监听
    _addGlobalScrollListener() {
      const pages = getCurrentPages();
      if (pages && pages.length > 0) {
        const currentPage = pages[pages.length - 1];
        
        // 保存原始的滚动处理函数（如果存在）
        if (currentPage.onScrollEvent && !this._originalScrollHandler) {
          this._originalScrollHandler = currentPage.onScrollEvent;
          
          // 包装滚动处理函数
          currentPage.onScrollEvent = (e) => {
            // 调用原始处理函数
            this._originalScrollHandler.call(currentPage, e);
            
            // 如果组件处于显示状态，页面滚动应该关闭它
            if (this.data.isVisible && !this._isClosingAnimation) {
              console.log('页面滚动时关闭详情组件');
              this.closeDetail();
            }
            
            // 标记检测到滚动
            this._hasScrolled = true;
            
            // 延迟重置滚动标记
            if (this._scrollResetTimer) {
              clearTimeout(this._scrollResetTimer);
            }
            
            this._scrollResetTimer = setTimeout(() => {
              this._hasScrolled = false;
            }, 500);
          };
        }
      }
    },

    // 确保视频独立性
    ensureVideoIndependence() {
      // 获取视频容器
      const query = this.createSelectorQuery();
      query.select('.video-player-container').node(res => {
        if (res && res.node) {
          // 为视频容器添加事件隔离
          res.node.addEventListener('touchstart', this._videoTouchHandler);
          res.node.addEventListener('touchmove', this._videoTouchHandler);
          res.node.addEventListener('touchend', this._videoTouchHandler);
        }
      }).exec();
    },

    // 初始化弹窗
    initPopup() {
      if (!this.animation) {
        // 如果动画实例不存在，重新创建
        this.animation = wx.createAnimation({
          duration: 300,
          timingFunction: 'ease',
        });
      }

      // 设置初始位置
      this.animation.translateY('100%').step({duration: 0});
      this.setData({
        animationData: this.animation.export()
      });

      // 延迟一帧后执行显示动画
      setTimeout(() => {
        this.animation.translateY(0).step();
        this.setData({
          animationData: this.animation.export(),
          panelTranslateY: 0,
          playerHeight: this.data.minPlayerHeight,
          videoError: false
        });
      }, 50);
    },
    
    // 重置弹窗状态
    resetPopup() {
      this.setData({
        panelTranslateY: 0,
        playerHeight: this.data.minPlayerHeight,
        commentInputFocus: false
      });
      
      // 暂停视频
      const videoContext = wx.createVideoContext('detail-video', this);
      videoContext.pause();
    },
    
    // 关闭弹窗
    closeDetail() {
      console.log('关闭弹窗');
      
      // 防止重复调用
      if (this._isClosingAnimation) {
        console.log('关闭动画已在进行中，忽略重复调用');
        return;
      }
      
      this._isClosingAnimation = true;
      
      // 立即暂停视频播放
      if (this.videoContext) {
        try {
          this.videoContext.pause();
        } catch (err) {
          console.error('暂停视频失败:', err);
        }
      }
      
      // 执行关闭动画
      this.animation.translateY('100%').step();
      this.setData({
        animationData: this.animation.export(),
        isPlaying: false,  // 确保播放状态为暂停
        showVideoDetail: false  // 确保视频详情状态为关闭
      });
      
      // 显示导航栏（如果有自定义TabBar）
      this._showTabBar();
      
      // 动画结束后触发关闭事件
      setTimeout(() => {
        this.setData({
          isVisible: false,  // 更新可见性标记
          currentVideo: null  // 清除当前视频
        });
        this.triggerEvent('close');
        this._isClosingAnimation = false;
      }, 300);
    },
    
    // 面板触摸开始
    panelTouchStart(e) {
      if (e.target.dataset.preventTouch) {
        return;
      }
      this.setData({
        touchStartY: e.touches[0].clientY,
        lastPanelY: this.data.panelTranslateY
      });
    },
    
    // 面板触摸移动
    panelTouchMove(e) {
      if (e.target.dataset.preventTouch) {
        return;
      }
      const touchY = e.touches[0].clientY;
      const moveY = touchY - this.data.touchStartY;
      let newPanelY = this.data.lastPanelY + moveY;
      
      // 限制面板移动范围
      if (newPanelY < -this.data.maxPanelHeight + this.data.minPanelHeight) {
        newPanelY = -this.data.maxPanelHeight + this.data.minPanelHeight;
      } else if (newPanelY > 0) {
        newPanelY = 0;
      }
      
      // 根据面板位置动态调整播放器高度
      let playerHeight = this.data.minPlayerHeight;
      if (newPanelY > -100) {
        // 当面板向下拉时，增加播放器高度
        const ratio = Math.min(1, newPanelY / 100 + 1);
        playerHeight = this.data.minPlayerHeight + 
                      (this.data.maxPlayerHeight - this.data.minPlayerHeight) * ratio;
      }
      
      this.setData({
        panelTranslateY: newPanelY,
        playerHeight: playerHeight
      });
    },
    
    // 面板触摸结束
    panelTouchEnd(e) {
      if (e.target.dataset.preventTouch) {
        return;
      }
      // 根据当前位置决定是否进入伪全屏状态
      if (this.data.panelTranslateY > -50) {
        // 向下拉超过阈值，进入伪全屏
        this.setData({
          panelTranslateY: 0,
          playerHeight: this.data.maxPlayerHeight
        });
      } else if (this.data.panelTranslateY < -this.data.maxPanelHeight + this.data.minPanelHeight + 50) {
        // 向上拉超过阈值，展示最大面板
        this.setData({
          panelTranslateY: -this.data.maxPanelHeight + this.data.minPanelHeight,
          playerHeight: this.data.minPlayerHeight
        });
      }
    },
    
    // 显示控制栏
    showControls() {
      // 清除之前的定时器
      if (this.data.controlsTimer) {
        clearTimeout(this.data.controlsTimer);
      }
      
      this.setData({ controlsVisible: true });
      
      // 设置新的定时器，3秒后隐藏
      this.data.controlsTimer = setTimeout(() => {
        this.setData({ controlsVisible: false });
      }, 3000);
    },

    // 视频区域触摸事件
    onVideoTouch() {
      this.showControls();
    },

    // 视频播放开始时
    onVideoPlay() {
      console.log('视频开始播放');
      this.setData({ isPlaying: true });
      this.showControls();  // 显示控制栏
    },
    
    onVideoPause() {
      console.log('视频暂停');
    },
    
    onVideoEnd() {
      console.log('视频播放结束');
    },
    
    onVideoError(e) {
      console.error('视频加载错误:', e);
      this.setData({
        videoError: true,
        isVideoLoading: false
      });
      
      // 显示错误提示
      wx.showToast({
        title: '视频加载失败',
        icon: 'none'
      });
    },
    
    // 重新加载视频
    reloadVideo() {
      this.setData({
        videoError: false
      }, () => {
        this.initVideo();
      });
    },
    
    // 显示更多选项
    showMoreOptions() {
      wx.showActionSheet({
        itemList: ['举报', '不感兴趣'],
        success: (res) => {
          if (res.tapIndex === 0) {
            wx.showToast({
              title: '举报成功',
              icon: 'success'
            });
          } else if (res.tapIndex === 1) {
            wx.showToast({
              title: '已减少此类内容推荐',
              icon: 'none'
            });
          }
        }
      });
    },
    
    // 加载评论
    loadComments() {
      // 固定15条评论数据
      const comments = Array.from({ length: 15 }, (_, index) => ({
        id: index + 1,
        name: `用户${index + 1}`,
        avatar: this.data.avatarUrl,
        content: index % 2 === 0 
          ? '这个视频太棒了！学到了很多，感谢分享。非常期待后续的内容更新！' 
          : '非常实用的教程，希望能有更多类似的内容分享。这些技巧对工作很有帮助，已经收藏了！',
        time: `${Math.floor(Math.random() * 24)}小时前`
      }));
      
      this.setData({ 
        comments,
        commentCount: comments.length
      });
    },
    
    // 加载点赞状态
    loadLikeStatus() {
      // 模拟点赞数据
      this.setData({
        isLiked: false,
        likeCount: 128
      });
    },
    
    // 切换点赞状态
    toggleLike() {
      const isLiked = !this.data.isLiked;
      const likeCount = isLiked ? this.data.likeCount + 1 : this.data.likeCount - 1;
      
      this.setData({
        isLiked,
        likeCount
      });
      
      // 这里可以添加向服务器提交点赞状态的代码
    },
    
    // 聚焦评论输入框
    focusCommentInput() {
      this.setData({
        commentInputFocus: true
      });
    },
    
    // 评论输入变化
    onCommentInput(e) {
      this.setData({
        commentText: e.detail.value
      });
    },
    
    // 提交评论
    submitComment() {
      if (!this.data.commentText.trim()) return;
      
      // 获取当前时间
      const timeStr = '刚刚';
      
      // 创建新评论
      const newComment = {
        id: this.data.comments.length + 1,
        name: this.data.userInfo ? this.data.userInfo.nickName : '匿名用户',
        avatar: this.data.avatarUrl,
        content: this.data.commentText,
        time: timeStr
      };
      
      // 更新评论列表
      const comments = [newComment, ...this.data.comments];
      
      this.setData({
        comments,
        commentCount: comments.length,
        commentText: '',
        commentInputFocus: false
      });
      
      // 这里可以添加向服务器提交评论的代码
    },
    
    // 分享视频
    shareVideo() {
      wx.showShareMenu({
        withShareTicket: true,
        menus: ['shareAppMessage', 'shareTimeline']
      });
    },
    
    // 阻止事件冒泡
    preventBubble() {
      console.log('preventBubble 被触发');
      return false;
    },

    // 添加触摸事件处理
    handleTouchStart(e) {
      // 获取点击的位置相对信息
      const touchY = e.touches[0].clientY;
      
      // 获取分界线位置（固定内容区域的底部）
      const query = this.createSelectorQuery();
      query.select('.fixed-content').boundingClientRect(rect => {
        if (rect) {
          // 只有当触摸位置在分界线以上时，才初始化下拉关闭
          if (touchY < rect.bottom) {
            this.setData({
              touchStartY: touchY,
              isDragging: true,
              touchMoveY: 0
            });
          }
        }
      }).exec();
    },

    handleTouchMove(e) {
      if (!this.data.isDragging) return;
      
      const moveY = e.touches[0].clientY - this.data.touchStartY;
      if (moveY < 0) return; // 只允许向下拖动

      // 使用动画实例更新位置
      this.animation.translateY(moveY).step({duration: 0});
      this.setData({
        animationData: this.animation.export(),
        touchMoveY: moveY
      });
    },

    handleTouchEnd() {
      if (!this.data.isDragging) return;
      
      const moveY = this.data.touchMoveY;
      if (moveY > 150) { // 如果下拉超过150px，触发关闭
        this.closeDetail();
      } else { // 否则回弹
        this.animation.translateY(0).step();
        this.setData({
          animationData: this.animation.export()
        });
      }
      
      this.setData({
        isDragging: false,
        touchMoveY: 0
      });
    },

    // 添加新的事件监听函数
    onPopupTap() {
      console.log('=== 弹窗点击 ===');
    },

    onControlsTap() {
      console.log('=== 控制区域点击 ===');
    },

    // 视频播放时间更新
    onTimeUpdate() {
      // 由于没有参数，这个方法现在是空的
      return;
    },

    // 切换播放/暂停
    togglePlay() {
      // 确保视频上下文存在
      if (!this.videoContext) {
        this.videoContext = wx.createVideoContext('detail-video', this);
      }
      
      if (this.data.isPlaying) {
        this.videoContext.pause();
      } else {
        // 如果视频已经播放完，从头开始播放
        if (this.data.progress >= 100) {
          this.videoContext.seek(0);
        }
        this.videoContext.play();
      }
      this.setData({ isPlaying: !this.data.isPlaying });
    },

    // 切换全屏
    toggleFullscreen() {
      const videoContext = wx.createVideoContext('detail-video', this);
      if (!this.data.isFullscreen) {
        // 根据视频方向决定全屏方向
        if (this.data.videoOrientation === 'vertical') {
          videoContext.requestFullScreen({ direction: 0 });
        } else {
          videoContext.requestFullScreen({ direction: 90 });
        }
      } else {
        videoContext.exitFullScreen();
      }
    },

    // 格式化时间
    formatTime(seconds) {
      const min = Math.floor(seconds / 60);
      const sec = Math.floor(seconds % 60);
      return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    },

    // 视频容器点击事件
    onVideoContainerTap() {
      // 切换控制栏显示状态
      const newVisible = !this.data.controlsVisible;
      this.setData({ controlsVisible: newVisible });

      // 如果显示控制栏，则设置3秒后自动隐藏
      if (newVisible) {
        this.autoHideControls();
      }
    },

    // 处理全屏变化
    onFullscreenChange() {
      // 由于没有参数，这个方法现在是空的
      return;
    },

    // 退出全屏
    exitFullscreen() {
      const videoContext = wx.createVideoContext('detail-video', this);
      videoContext.exitFullScreen();
    },

    // 全屏模式下点击事件
    onFullscreenTap() {
      // 如果是滑动操作，不触发点击事件
      if (this.data.isSwiping) return;
      
      // 只处理显示/隐藏控制栏
      this.setData({
        controlsVisible: !this.data.controlsVisible
      });

      if (this.data.controlsVisible) {
        if (this.data.controlsTimer) {
          clearTimeout(this.data.controlsTimer);
        }
        this.data.controlsTimer = setTimeout(() => {
          if (this.data.isFullscreen) {
            this.setData({
              controlsVisible: false
            });
          }
        }, 3000);
      }
    },

    // 开始触摸
    onFullscreenTouchStart() {
      if (!this.data.isFullscreen) return;
      
      // 由于没有参数，这个方法现在是空的
      return;
    },

    // 触摸移动
    onFullscreenTouchMove() {
      if (!this.data.isFullscreen) return;
      
      // 由于没有参数，这个方法现在是空的
      return;
    },

    // 触摸结束
    onFullscreenTouchEnd() {
      if (!this.data.isDragging) return;
      // 由于没有参数，这个方法现在是空的
      return;
    },

    // 视频播放结束
    onVideoEnded() {
      this.setData({
        isPlaying: false  // 更新播放状态
      });
    },

    // 检测视频方向
    checkVideoOrientation(width, height) {
      // 考虑一些特殊比例的情况
      const ratio = width / height;
      if (ratio > 1.1) { // 宽高比大于1.1认为是横向视频
        return 'horizontal';
      } else if (ratio < 0.9) { // 宽高比小于0.9认为是竖向视频
        return 'vertical';
      } else { // 接近1:1的视频按横向处理
        return 'horizontal';
      }
    },

    // 处理视频加载完成事件
    onVideoLoaded(e) {
      console.log('视频元数据加载完成', e);
      
      try {
        // 创建视频上下文（确保在使用前创建）
        this.videoContext = wx.createVideoContext('detail-video', this);
        console.log('视频上下文创建成功');
        
        // 获取视频宽高比
        const { width, height } = e.detail;
        
        // 根据宽高比判断视频方向
        const orientation = width > height ? 'horizontal' : 'vertical';
        
        this.setData({
          videoOrientation: orientation,
          isVideoLoading: false,
          videoError: false
        });
        
        // 延迟一帧再播放，确保视频元素已完全准备好
        setTimeout(() => {
          if (this.videoContext) {
            console.log('开始播放视频');
            // 不使用 muted 方法，而是通过 video 元素的 muted 属性控制
            this.videoContext.play();
            
            // 设置播放状态
            this.setData({
              isPlaying: true
            });
          }
        }, 100);
      } catch (error) {
        console.error('视频加载处理错误:', error);
        this.setData({
          videoError: true,
          isVideoLoading: false
        });
      }
    },

    handleCommentsScroll() {
      // 获取评论区域的滚动信息
      const query = this.createSelectorQuery();
      query.select('.comments-section').boundingClientRect(rect => {
        if (rect) {
          // 由于没有参数，这个方法现在是空的
          return;
        }
      }).exec();
    },

    handleCommentsTouch() {
      return false;
    },

    // 阻止页面滚动
    preventPageScroll() {
      return false;  // 直接返回false阻止事件冒泡和默认行为
    },

    onPulling() {
      // 仅处理下拉动作，不做其他等待
    },

    onRefresh() {
      // 立即结束刷新状态，不等待
      this.setData({
        isRefreshing: false
      });
    },

    // 检查白色区域的尺寸
    checkPanelSize() {
      const query = this.createSelectorQuery();
      query.select('.info-panel').boundingClientRect(rect => {
        if (rect) {
          console.log('白色区域信息：', {
            top: rect.top,
            height: rect.height,
            bottom: rect.bottom,
            width: rect.width
          });
        }
      }).exec();
    },

    // 计算并设置弹窗高度
    calculatePopupHeight() {
      const query = this.createSelectorQuery();
      query.select('.video-player-container').boundingClientRect(rect => {
        if (rect) {
          const videoBottom = rect.bottom;
          
          // 使用静态高度代替已弃用的API
          // 为大多数设备设置一个合理的默认高度
          const screenHeight = 750; // 一个安全的估计值
          const popupHeight = screenHeight - videoBottom;
          
          // 设置自定义CSS变量
          this.setData({
            popupCustomStyle: `--popup-height: ${popupHeight}px;`
          });
        }
      }).exec();
    },

    // 显示评论弹窗
    showCommentPopup() {
      this.calculatePopupHeight();
      this.setData({
        isCommentPopupShow: true
      });
    },

    // 隐藏评论弹窗
    hideCommentPopup() {
      this.setData({
        isCommentPopupShow: false
      });
    },

    // 发送评论
    sendComment() {
      // 获取评论内容并处理
      const commentText = this.data.commentText;
      if (!commentText || commentText.trim() === '') {
        return;
      }

      // TODO: 这里可以添加发送评论的逻辑

      // 发送完成后关闭弹窗
      this.hideCommentPopup();
      
      // 清空评论文本
      this.setData({
        commentText: ''
      });
    },

    // 点赞事件处理
    handleLike() {
      this.toggleLike();
    },
    
    // 评论事件处理
    handleComment() {
      this.showCommentPopup();
    },
    
    // 标签事件处理
    handleTag() {
      // 标签相关功能
      console.log('点击了标签');
    },
    
    // 分享事件处理
    handleShare() {
      // 分享相关功能
      console.log('点击了分享');
    },

    formatTitle(title) {
      if (title.length > 7) {
        return title.substring(0, 7) + '...';
      }
      return title;
    },

    // 自动隐藏控制栏
    autoHideControls() {
      if (this.data.controlsTimer) {
        clearTimeout(this.data.controlsTimer);
      }
      
      this.data.controlsTimer = setTimeout(() => {
        this.setData({ controlsVisible: false });
      }, 3000);
    },

    // 点击标签切换到产品介绍
    handleTagSwitch() {
      this.setData({
        activeTabIndex: 0
      });
    },

    // 点击评论图标切换到评论列表
    handleCommentSwitch() {
      this.setData({
        activeTabIndex: 1
      });
    },

    // swiper 切换事件处理
    handleSwiperChange() {
      // 由于没有参数，这个方法现在是空的
      return;
    },

    // 产品页下拉处理
    onProductPulling() {
      // 仅处理下拉动作，不做其他等待
    },

    // 产品页刷新处理
    onProductRefresh() {
      // 模拟刷新过程
      setTimeout(() => {
        this.setData({
          productRefreshing: false
        });
      }, 1000);
    },

    // 显示评论输入框
    showCommentModal() {
      this.setData({
        isCommentPopupShow: true  // 显示评论弹窗
      });
    },

    // 显示弹窗
    show() {
      console.log('[导航栏监测] 视频详情开始显示');
      
      // 设置存储值，让导航栏自己处理显示逻辑
      wx.setStorageSync('tabBarVisible', false);
      
      // 恢复原始动画代码
      this.setData({
        hidden: false,
        isPanelShow: true,
        isShow: true,
        showContent: true
      });
      
      // 创建动画
      this.animation = wx.createAnimation({
        duration: 300,
        timingFunction: 'ease-out',
        delay: 0
      });
      
      // 从底部滑入
      this.animation.translateY(0).step();
      
      this.setData({
        animationData: this.animation.export(),
        isVisible: true
      });
    },

    // 初始化视频
    initVideo() {
      if (!this.properties.videoInfo?.videoUrl || this.data.videoLoaded) return;

      // 确保 videoCache 存在
      if (!this.videoCache) {
        const app = getApp();
        this.videoCache = app.globalData.videoCache || new Map();
      }

      const videoUrl = this.properties.videoInfo.videoUrl;
      
      // 检查缓存避免重复请求
      if (this.videoCache.has(videoUrl)) {
        this.setData({ videoLoaded: true });
        return;
      }

      // 只在第一次加载时创建上下文
      if (!this.videoContext) {
        this.videoContext = wx.createVideoContext('detail-video', this);
      }

      // 记录到缓存
      this.videoCache.set(videoUrl, true);
      this.setData({ videoLoaded: true });
    },

    // 重置方法，用于需要重新加载时调用
    resetVideo() {
      this.setData({ videoLoaded: false });
      if (this.videoContext) {
        this.videoContext.pause();
      }
    },

    // 新增：隐藏底部导航栏
    _hideTabBar() {
      try {
        // 获取当前页面
        const pages = getCurrentPages();
        if (pages && pages.length > 0) {
          const currentPage = pages[pages.length - 1];
          
          // 尝试获取TabBar实例并隐藏
          if (typeof currentPage.getTabBar === 'function') {
            const tabBar = currentPage.getTabBar();
            if (tabBar) {
              tabBar.hide();
            }
          }
        }
      } catch (error) {
        // 忽略错误
      }
    },
    
    // 新增：显示底部导航栏
    _showTabBar() {
      try {
        // 获取当前页面
        const pages = getCurrentPages();
        if (pages && pages.length > 0) {
          const currentPage = pages[pages.length - 1];
          
          // 尝试获取TabBar实例并显示
          if (typeof currentPage.getTabBar === 'function') {
            const tabBar = currentPage.getTabBar();
            if (tabBar) {
              // 检查是否有阻止显示的状态
              if (!currentPage.data.showVideoDetail && !currentPage.data.showLaunch) {
                tabBar.show();
              }
            }
          }
        }
      } catch (error) {
        // 忽略错误
      }
    },

    // 修改hide方法，只控制自定义导航栏
    hide() {
      console.log('[导航栏监测] 视频详情开始关闭');
      
      // 标记关闭状态
      this._isClosing = true;
      
      // 暂停视频
      if (this.videoContext) {
        this.videoContext.pause();
      }
      
      // 执行关闭动画
      this.animation = wx.createAnimation({
        duration: 300,
        timingFunction: 'ease-out',
        delay: 0
      });
      this.animation.translateY('100%').step();
      
      this.setData({
        animationData: this.animation.export(),
        isVisible: false,
        isPanelShow: false
      });
      
      // 动画完成后执行关闭逻辑
      setTimeout(() => {
        // 隐藏组件
        this.setData({
          hidden: true,
          isShow: false,
          showContent: false
        });
        
        // 触发关闭事件
        this.triggerEvent('close');
        
        // 设置存储值，让导航栏自己处理显示逻辑
        wx.setStorageSync('tabBarVisible', true);
        
        // 标记完成
        this._isClosing = false;
      }, 300);
    }
  },
  observers: {
    'hidden': function(hidden) {
      // 移除调试日志，保留简化逻辑
    },
    'isVisible': function(isVisible) {
      if (isVisible && this.properties.videoInfo && !this.data.videoLoaded) {
        // 只在未加载时初始化
        this.initVideo();
      }
    },
    'videoInfo': function(newVal) {
      if (newVal) {
        this.initVideo();  // 数据变化就会初始化
      }
    }
  }
}) 
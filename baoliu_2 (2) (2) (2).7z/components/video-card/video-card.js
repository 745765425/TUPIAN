/* global Component, wx, getApp, console, setTimeout, clearTimeout */

const appConfig = require('../../config/app-config.js');
const app = getApp();

Component({
  options: {
    multipleSlots: true, // 启用多slot支持
    addGlobalClass: true
  },
  /**
   * 组件的属性列表
   */
  properties: {
    videoInfo: {
      type: Object,
      value: {},
      observer: function(newVal) {
        if (newVal && newVal.videoUrl) {
          // 创建视频上下文
          if (newVal.id) {
            this.initVideoContext(newVal.id);
          }
          
          // 获取临时访问URL
          this.getTempVideoUrl(newVal.videoUrl);
        }
      }
    },
    extClass: {
      type: String,
      value: ''
    },
    borderRadius: {
      type: String,
      value: '12px'
    },
    isDetailShow: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        if (newVal) {
          // 详情页打开时，只暂停视频，保持可见性
          this.pauseVideo();
          if (this.playTimer) {
            clearTimeout(this.playTimer);
            this.playTimer = null;
          }
        }
      }
    },
    isInView: {
      type: Boolean,
      value: false,
      observer: function(newVal) {
        // 防止快速滚动时的播放/暂停冲突
        if (this._inViewTimer) {
          clearTimeout(this._inViewTimer);
        }
        
        this._inViewTimer = setTimeout(() => {
          if (newVal) {
            console.log('视频进入视图，但不自动播放');
          } else {
            this.pauseVideo();
          }
        }, 100);
      }
    },
    isFirstVideo: {
      type: Boolean,
      value: false
    },
    index: Number
  },
  /**
   * 组件的初始数据
   */
  data: {
    showControls: false,
    keepVideoVisible: false, // 新增状态，表示保持视频可见
    isMuted: true, // 默认静音
    posterVideoContext: null, // 新增属性，用于存储封面视频上下文
    showReplayButton: false,  // 控制重播按钮显示
    playTimer: null,  // 添加播放定时器
    windowHeight: 0,
    isPlayingVideo: false,
    _isPlaying: false,
    _isPlayRequested: false,
    _playPromise: null,
    isPlaying: false,  // 添加播放状态标记
    videoContext: null,  // 添加videoContext到data中
    currentTime: 0, // 添加当前播放时间记录
    duration: 0,
    tempVideoUrl: '',
    isLoading: false,  // 改为 false，默认不显示加载状态
    isPreloading: false,  // 新增预加载状态
    cosBaseUrl: appConfig.cos.baseUrl,
    config: {
      defaultAvatar: appConfig.cos.defaults.avatar,
      shareIcon: appConfig.cos.defaults.shareIcon,
      muteIcon: appConfig.cos.defaults.muteIcon,
      unmuteIcon: appConfig.cos.defaults.unmuteIcon
    },
    avatarUrl: '',
    username: '用户名',
    appConfig: null,
    defaultAvatarBase64: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAEkUlEQVR4nO2ZW2xUVRSGv7kxhpCQGAMPPqgxvnhL1AQTYwwxRl8kRl+QxAQTjYkxvqgxgSCUmQ7TmZY0jdDQFkpbCr0BLZdSCqXQFiilpdwKpUBbyrWlpdBSZk5njme7z+Sc2TOdOe0ZZID0T/6kSfZa/1r/XnvvtfY+E/7HfxQBYDWwG+gErgEDwDAwCowBfwJ9QAfQBOwE1gAzJ3vhQWAn0AXcBP4BEsCEw3UDuAB8DKyYrMVPB94HzgF3gXHnS9+5c+cxEZGxsTFxk/Hxcbl165ZEo1G5fPmyRCIROXnypLS3t8vg4KAkEgk3U40DvwGfALPyXXwJcBi4nXnxWCwmPT09cuTIEdm/f7+0tLTI+fPnZXh4WFKplBuJTOIJ4CugLB8EyoF24E7mpQcGBqS1tVVaWlqkq6tLrly5IvF4XJLJpIyMjMj169elsrJSqqqqpLa2Vk6dOiWDg0OSTLqS+BvYD8zxQqAYaASGMi+qN9zf3y+XLl2SWCwm9+7dk0QiYS2sN6//Hx0dlb6+PmltbZW6ujqprq6Wzs5OGR4ezmXOu8BRYH4uBBYBx4G7mZe9f/++xONxGRoakhs3bkh3d7fU19dLQ0ODdHR0WBvXm9eEYrGYVFRUSGVlpRw/flz6+/tzIfE38DUwP5XEPOBLYDTbhvUG9YZ7e3ulra1NTp48KdXV1VJbWyuNjY3S3NwsZ86ckfb2drly5YrEYjEZGBiQ8+fPy7Fjx6SqqkrOnj0rt2/fzkXGBPAjsAiYaSegw+W3bBvWG9KbvHr1qvT09FgbP3TokBw8eNDa/JEjR6S5uVna2tqkt7dXBgcHZWxszDJxPB6XixcvSk1NjTQ1NUlvb68bCe1SXwIVwEeYPX9WAvqyOlzuZNuwDpfR0VFr43qzeuM6XPTm9b96w/F43DKp/q03r8NJz4XOzk5pbGyUmpoauX79ei4E9GV+HvgG+B5oBgYtEtlcSG9YN643rQ2qw0WTiEajlgt1dHRIc3OzHD582HKhpqYmy4W0gXW46FnR2toqJ06ckPr6eotuLi6UiYQOm1+Ao8BxoA64bJHI5kI6XPQGtRvpcNEbPnXqlNTV1UlDQ4O0t7dbm9cb1+GiSZw7d85yoZqaGsvY2qiZLpSNRKYL/QS8BbwBvA0cAP6ySGRzIW1MHS6aQDQatTavN3/27Fmprq6W+vp6OX36tOVCOlz0BrWBtYEbGxulqqpKTp48Kb29vbm4UDYSk+pCOlz0BrUb6XDRLqQ3X1tbK01NTZYLaQNrF9Lhogl0d3dbLlRZWSkXLlzI1YWykchwoZ+BN4HXgLeBH4B+i0Q2F9LhosNFb1C7kA4XvXntQtqFtAtpA+tw0S6kw0UbWLuQDhftQm4ulI2E3YW+Ad4AXgXeAvYBfRaJbC6kw0WHizawdiEdLnrz2oW0gbULaRfSBtbhol1Ih4t2IR0u2oVycSE7iWwutA94GXgFeAP4DvjDIpHNhXS46HDRBtYupMNFb167kDawdiHtQtrAOly0C+lw0S6kw0W70FRzof8w+fgXF00YRn5OCw0AAAAASUVORK5CYII='
  },
  lifetimes: {
    created() {
      // 在组件实例创建时就初始化缓存
      const app = getApp();
      this.videoCache = app.globalData.videoCache || new Map();
    },
    attached() {
      try {
        const windowInfo = wx.getWindowInfo();
        this.setData({
          windowHeight: windowInfo.windowHeight
        });

        // 只在必要时初始化视频上下文
        if (this.properties.videoInfo?.id && !this.videoContext) {
          this.initVideoContext(this.properties.videoInfo.id);
        }

        // 统一处理视频URL缓存，避免重复请求
        if (this.properties.videoInfo?.videoUrl) {
          if (this.videoCache.has(this.properties.videoInfo.videoUrl)) {
            this.setData({
              tempVideoUrl: this.videoCache.get(this.properties.videoInfo.videoUrl),
              videoLoaded: true
            });
          } else {
            // 只在未缓存时添加到缓存
            this.videoCache.set(
              this.properties.videoInfo.videoUrl,
              this.properties.videoInfo.videoUrl
            );
          }
        }

        // 获取全局配置
        const app = getApp();
        
        // 添加详细的调试日志
        console.log('检查全局配置:', {
          hasApp: !!app,
          hasGlobalData: app && !!app.globalData,
          hasAppConfig: app && app.globalData && !!app.globalData.appConfig,
          hasLocalConfig: app && app.globalData && app.globalData.appConfig && !!app.globalData.appConfig.local,
          hasImagesConfig: app && app.globalData && app.globalData.appConfig && 
                          app.globalData.appConfig.local && !!app.globalData.appConfig.local.images,
          defaultAvatarPath: app && app.globalData && app.globalData.appConfig && 
                            app.globalData.appConfig.local && app.globalData.appConfig.local.images && 
                            app.globalData.appConfig.local.images.defaultAvatar
        });
        
        this.setData({
          appConfig: app.globalData.appConfig
        });

        // 添加调试日志
        console.log('设置头像路径');
        
        // 使用本地头像配置
        if (app.globalData.appConfig && app.globalData.appConfig.local && 
            app.globalData.appConfig.local.images && 
            app.globalData.appConfig.local.images.defaultAvatar) {
          // 使用配置中的本地头像路径
          this.setData({
            avatarUrl: app.globalData.appConfig.local.images.defaultAvatar
          });
          console.log('使用配置的本地头像路径:', app.globalData.appConfig.local.images.defaultAvatar);
        } else {
          // 如果配置不存在，使用Base64头像
          this.setData({
            avatarUrl: this.data.defaultAvatarBase64
          });
          console.log('使用Base64头像作为备用');
        }
        
        // 添加日志检查头像路径
        console.log('头像路径已设置为:', this.data.avatarUrl);
      } catch (error) {
        console.error('初始化失败:', error);
      }
    },
    detached() {
      if (this.playTimer) {
        clearTimeout(this.playTimer);
        this.playTimer = null;
      }
      
      // 清理所有定时器
      if (this._viewChangeTimer) {
        clearTimeout(this._viewChangeTimer);
        this._viewChangeTimer = null;
      }
      
      if (this._inViewTimer) {
        clearTimeout(this._inViewTimer);
        this._inViewTimer = null;
      }
      
      if (this._autoPlayTimer) {
        clearTimeout(this._autoPlayTimer);
        this._autoPlayTimer = null;
      }
      
      // 组件销毁时，确保清理所有状态和操作
      this._isPlaying = false;
      this._isPlayRequested = false;
      this._playPromise = null;
      
      // 组件销毁时暂停视频
      if (this.videoContext) {
        this.videoContext.pause();
        this.videoContext = null;
      }
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    // 初始化视频上下文
    initVideoContext(videoId) {
      if (!videoId || this.videoContext) return;
      
      try {
        this.videoContext = wx.createVideoContext(`video-${videoId}`, this);
      } catch (error) {
        console.error('初始化视频上下文失败:', error);
      }
    },

    // 统一的播放控制方法
    togglePlay(e) {
      if (e?.stopPropagation) {
        e.stopPropagation();
      }
      
      if (!this.videoContext) {
        this.initVideoContext(this.properties.videoInfo.id);
      }

      if (!this.data.isPlaying) {
        this.videoContext?.play();
      } else {
        this.videoContext?.pause();
      }
    },

    // 视频事件处理
    onVideoPlay() {
      this.setData({ isPlaying: true });
    },

    onVideoPause() {
      this.setData({ isPlaying: false });
    },

    onVideoEnded(e) {
      console.log('视频播放结束');
      
      // 更新播放状态
      this.setData({
        isPlaying: false,
        currentTime: 0  // 重置当前时间
      });
      
      // 不自动重新播放，等待用户点击
      
      // 触发事件通知父组件
      this.triggerEvent('videoended', {
        videoId: this.properties.videoInfo.id,
        videoInfo: this.properties.videoInfo
      });
    },

    // 改进视频错误处理函数
    onVideoError(e) {
      // 减少错误日志输出，只保留核心信息
      // console.error('视频加载错误:', e.detail);
      
      // 静默重试获取视频链接，不显示错误提示
      if (this.properties.videoInfo && this.properties.videoInfo.videoUrl) {
        this.getTempVideoUrl(this.properties.videoInfo.videoUrl);
      }
      
      // 不显示错误提示，避免用户困惑
      // 移除 wx.showToast 调用
    },

    // 静音控制方法 - 修复版本
    toggleMute(e) {
      // 检查事件对象是否有效，避免函数调用错误
      if (e && typeof e.stopPropagation === 'function') {
        // 阻止事件冒泡，避免触发外层的点击事件
        e.stopPropagation();
      }
      
      // 反转静音状态
      const newMuteState = !this.data.isMuted;
      
      // 更新组件数据状态
      this.setData({
        isMuted: newMuteState
      });
      
      // 最小化日志输出
      console.log('静音状态:', newMuteState);
      
      // 触发事件
      this.triggerEvent('mutechange', {
        isMuted: newMuteState,
        videoId: this.properties.videoInfo.id
      });
    },

    // 打开详情 - 启用该功能，允许弹窗出现
    openDetail() {
      console.log('【关键跟踪】openDetail方法被调用 - 时间戳:', new Date().getTime());
      console.log('【关键跟踪】视频信息:', this.properties.videoInfo ? 
                  JSON.stringify({
                    id: this.properties.videoInfo.id,
                    title: this.properties.videoInfo.title,
                    hasVideoUrl: !!this.properties.videoInfo.videoUrl
                  }) : '无视频信息');
      
      // 检查是否有有效的视频信息
      if (!this.properties.videoInfo || !this.properties.videoInfo.id) {
        console.warn('【关键跟踪】错误：视频信息不完整，无法打开详情');
        return;
      }
      
      // 记录上一次触发事件的时间，防止重复触发
      const now = new Date().getTime();
      if (this._lastTriggerTime && now - this._lastTriggerTime < 300) {
        console.log('【关键跟踪】忽略重复点击，间隔过短');
        return;
      }
      this._lastTriggerTime = now;
      
      console.log('【关键跟踪】即将触发cardtap事件，视频ID:', this.properties.videoInfo.id);
      
      // 重要：使用bubbles和composed确保事件能够冒泡到父组件
      try {
        console.log('【关键跟踪】尝试触发cardtap事件');
        
        // 尝试不同的事件名称和选项来解决问题
        this.triggerEvent('cardtap', {
          videoInfo: this.properties.videoInfo,
          index: this.properties.index
        }, { bubbles: true, composed: true });
        
        console.log('【关键跟踪】cardtap事件触发成功');
        
        // 备用方案：也触发tap事件，以防父组件监听的是tap而非cardtap
        console.log('【关键跟踪】备用：尝试触发tap事件');
        this.triggerEvent('tap', {
          videoInfo: this.properties.videoInfo
        }, { bubbles: true, composed: true });
        
      } catch (error) {
        console.error('【关键跟踪】触发事件失败，错误信息:', error);
      }
    },

    // 视频时间更新事件
    onTimeUpdate(e) {
      // 更新当前时间和总时长
      this.setData({
        currentTime: e.detail.currentTime,
        duration: e.detail.duration
      });
    },

    // 播放视频
    playVideo() {
      console.log('执行播放视频');
      
      if (!this.videoContext) {
        console.log('创建视频上下文');
        this.videoContext = wx.createVideoContext(`video-${this.properties.videoInfo.id}`, this);
      }
      
      if (this.videoContext) {
        console.log('调用播放方法');
        this.videoContext.play();
        
        // 更新状态
        this.setData({
          isPlaying: true
        });
      } else {
        console.error('无法创建视频上下文');
      }
    },
    
    // 暂停视频
    pauseVideo() {
      console.log('执行暂停视频');
      
      if (!this.videoContext) {
        this.videoContext = wx.createVideoContext(`video-${this.data.videoInfo.id}`, this);
      }
      
      this.videoContext.pause();
      this.setData({ isPlaying: false });
    },
    
    // 实际执行暂停的方法
    _doPause() {
      if (!this._isPlaying && !this._isPlayRequested) return;
      
      if (!this.isPlayingVideo) return;
      this.isPlayingVideo = false;

      if (this.videoContext && this.data.isPlaying) {
        this.videoContext.pause();
        this.setData({
          isPlaying: false,
          keepVideoVisible: true
        });
        this._isPlaying = false;
        this._isPlayRequested = false;
      }
    },
    
    // 视频播放结束
    videoEnd() {
      this.isPlayingVideo = false;
      this.setData({
        isPlaying: false,
        keepVideoVisible: true,
        showReplayButton: true
      });
      // 触发结束事件
      this.triggerEvent('videoend');
    },
    
    // 点击视频卡片
    onTap(e) {
      console.log('【关键跟踪】onTap被触发 - 时间戳:', new Date().getTime());
      console.log('【关键跟踪】点击目标:', e && e.target ? JSON.stringify({
        dataset: e.target.dataset,
        id: e.target.id
      }) : '无目标数据');
      
      // 如果是点击分享或静音按钮，不处理（它们有自己的事件处理器）
      if (e && e.target && (
          e.target.dataset.role === 'share-button' || 
          e.target.dataset.role === 'mute-button' || 
          e.target.dataset.role === 'video-control')) {
        console.log('【关键跟踪】点击了特殊控制区域:', e.target.dataset.role, '- 忽略此次点击');
        return;
      }
      
      // 点击时立即暂停当前视频
      if (this.data.isPlaying) {
        console.log('【关键跟踪】视频正在播放，执行暂停');
        this.pauseVideo();
      }
      
      // 直接调用openDetail方法
      console.log('【关键跟踪】准备调用openDetail方法');
      this.openDetail();
    },
    
    // 修改showMore方法为分享功能
    showMore() {
      // 触发自定义分享事件，传递当前视频信息
      this.triggerEvent('share', { 
        videoId: this.data.videoInfo.id,
        title: this.data.videoInfo.title,
        imageUrl: this.data.videoInfo.coverUrl,
        path: `/pages/video-detail/video-detail?id=${this.data.videoInfo.id}`
      });
    },
    
    // onCardTap方法 - 备用的点击处理器
    onCardTap(e) {
      console.log('【关键跟踪】onCardTap被调用 - 时间戳:', new Date().getTime());
      console.log('【关键跟踪】事件详情:', e ? JSON.stringify({
        type: e.type,
        currentTarget: e.currentTarget ? {
          id: e.currentTarget.id,
          dataset: e.currentTarget.dataset
        } : null
      }) : '无事件对象');
      
      // 点击时立即暂停当前视频
      if (this.data.isPlaying) {
        console.log('【关键跟踪】视频正在播放，执行暂停');
        this.pauseVideo();
      }
      
      // 直接调用openDetail，不进行额外处理
      console.log('【关键跟踪】从onCardTap调用openDetail方法');
      this.openDetail();
    },
    
    // 修改重播方法
    replayVideo(e) {
      if (this.data.videoContext) {
        this.data.videoContext.seek(0);  // 跳转到视频开始
        this.data.videoContext.play();   // 开始播放
        
        this.setData({
          isPlaying: true,
          showReplayButton: false  // 隐藏重播按钮
        });
      }
    },
    
    // 添加处理云文件的方法
    async getVideoUrl(fileID) {
      try {
        const { fileList } = await wx.cloud.getTempFileURL({
          fileList: [fileID]
        })
        return fileList[0].tempFileURL
      } catch (err) {
        console.error('获取视频链接失败:', err)
        return ''
      }
    },
    
    // 添加自动播放方法
    autoPlayVideo() {
      console.log('自动播放已禁用');
      return;
    },

    handleVideoError(e) {
      console.error('视频加载错误:', e.detail);
      // 可以在这里添加错误处理逻辑
    },

    // 添加测试链接方法
    async testVideoUrl() {
      const videoUrl = this.properties.videoInfo.videoUrl;
      console.log('原始视频链接:', videoUrl);

      try {
        // 测试获取临时链接
        const result = await wx.cloud.getTempFileURL({
          fileList: [videoUrl]
        });
        
        if (result.fileList && result.fileList[0].tempFileURL) {
          console.log('获取到临时链接:', result.fileList[0].tempFileURL);
          
          // 测试临时链接的可访问性
          wx.request({
            url: result.fileList[0].tempFileURL,
            method: 'HEAD',
            success: (res) => {
              console.log('链接可访问，状态码:', res.statusCode);
              console.log('响应头:', res.header);
            },
            fail: (err) => {
              console.error('链接访问失败:', err);
            }
          });
        }
      } catch (err) {
        console.error('获取临时链接失败:', err);
      }
    },

    // 改进URL编码和处理函数
    encodeVideoUrl(url) {
      if (!url) return '';
      
      try {
        // 首先移除URL中的#及其后面的内容
        if (url.includes('#')) {
          url = url.split('#')[0];
          console.log('移除#后的URL:', url);
        }
        
        // 检查URL是否已经编码
        if (url.indexOf('%') > -1 && decodeURIComponent(url) !== url) {
          console.log('URL已经编码，跳过处理');
          return url;
        }
        
        // 使用encodeURI保留URL结构，但编码中文字符
        let encodedUrl = url;
        
        // 如果URL包含中文，进行编码
        if (/[\u4e00-\u9fa5]/.test(url)) {
          // 分离协议和域名部分
          const urlParts = url.match(/^(https?:\/\/[^\/]+)(\/.*)/);
          if (urlParts) {
            const domain = urlParts[1]; // 协议和域名
            const path = urlParts[2];   // 路径部分
            
            // 只对路径部分进行编码
            encodedUrl = domain + encodeURI(path);
          } else {
            // 如果无法分离，对整个URL进行编码
            encodedUrl = encodeURI(url);
          }
          
          console.log('URL包含中文，已编码:', encodedUrl);
        }
        
        return encodedUrl;
      } catch (e) {
        console.error('URL编码失败:', e);
        return url; // 出错时返回原始URL
      }
    },

    // 改进getTempVideoUrl方法，清除开发工具的引用标记
    getTempVideoUrl(videoUrl) {
      if (!videoUrl) return;
      
      // 简化日志输出，减少控制台干扰
      // console.log('获取临时视频链接:', videoUrl);
      
      // 先进行URL编码和处理
      const encodedUrl = this.encodeVideoUrl(videoUrl);
      
      // 检查是否已经是临时链接
      if (encodedUrl.indexOf('tempFileURL') > -1) {
        // 移除开发工具添加的引用标记
        const cleanUrl = encodedUrl.replace(/#devtools_no_referrer/g, '');
        this.setData({ tempVideoUrl: cleanUrl });
        return;
      }
      
      // 检查是否是云存储文件ID
      const isCloudID = encodedUrl.startsWith('cloud://') || 
                        (encodedUrl.startsWith('https://') && encodedUrl.includes('tcb.qcloud.la'));
      
      if (isCloudID || encodedUrl.startsWith('https://')) {
        // 使用云函数获取临时链接
        wx.cloud.getTempFileURL({
          fileList: [encodedUrl],
          success: res => {
            if (res.fileList && res.fileList[0] && res.fileList[0].tempFileURL) {
              let tempUrl = res.fileList[0].tempFileURL;
              
              // 移除所有开发工具标记
              tempUrl = tempUrl.split('#')[0];
              
              // 简化时间戳添加
              tempUrl += (tempUrl.includes('?') ? '&' : '?') + `t=${Date.now()}`;
              
              this.setData({
                tempVideoUrl: tempUrl
              });
            }
          },
          fail: err => {
            // 失败时尝试使用编码后的原始链接
            this.setData({ tempVideoUrl: encodedUrl.split('#')[0] });
          }
        });
      } else {
        // 直接使用编码后的链接，但移除开发者标记
        this.setData({ tempVideoUrl: encodedUrl.split('#')[0] });
      }
    },

    // 添加分享按钮点击处理函数
    onShareButtonTap(e) {
      // 阻止事件冒泡，只处理分享
      console.log('分享按钮被点击，阻止冒泡');
      // 不需要做任何事情，微信会自动处理分享
    },

    onAvatarError(e) {
      console.error('头像加载失败:', e);
      
      const app = getApp();
      // 尝试使用配置中的本地头像
      if (app.globalData.appConfig && 
          app.globalData.appConfig.local && 
          app.globalData.appConfig.local.images && 
          app.globalData.appConfig.local.images.defaultAvatar) {
        
        console.log('尝试使用配置的本地头像');
        this.setData({
          avatarUrl: app.globalData.appConfig.local.images.defaultAvatar
        });
      } else {
        // 如果配置不存在，使用Base64头像
        console.log('使用Base64头像作为最后备用');
        this.setData({
          avatarUrl: this.data.defaultAvatarBase64
        });
      }
    }
  }
}) 
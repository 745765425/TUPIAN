// packages/detail/pages/video-detail/video-detail.js
// 全局微信小程序API和App实例
/* global wx, getApp, setTimeout, console, Page */

Page({

  /**
   * 页面的初始数据
   */
  data: {
    videoInfo: null,
    isLoading: true,
    isPlaying: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    if (options && options.id) {
      this.loadVideoInfo(options.id);
    } else {
      wx.showToast({
        title: '视频ID不存在',
        icon: 'none'
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },

  /**
   * 获取视频详情信息
   */
  loadVideoInfo(id) {
    this.setData({ isLoading: true });
    
    // 从缓存中获取视频列表
    const videoList = wx.getStorageSync('videoList') || [];
    const video = videoList.find(item => item.id === id);
    
    if (video) {
      this.setData({
        videoInfo: video,
        isLoading: false
      }, () => {
        this.initVideoContext();
      });
    } else {
      // 如果本地缓存没有，尝试从云函数获取
      const app = getApp();
      wx.cloud.callFunction({
        name: 'getVideoList',
        data: {
          cosConfig: app.globalData.appConfig.cos
        }
      }).then(res => {
        if (res.result && res.result.success) {
          const videoList = res.result.data || [];
          const video = videoList.find(item => item.id === id);
          
          if (video) {
            this.setData({
              videoInfo: video,
              isLoading: false
            }, () => {
              this.initVideoContext();
            });
            
            // 更新本地缓存
            wx.setStorageSync('videoList', videoList);
          } else {
            this.showError('未找到视频信息');
          }
        } else {
          this.showError('获取视频信息失败');
        }
      }).catch(err => {
        console.error('加载视频详情失败:', err);
        this.showError('加载视频失败');
      });
    }
  },
  
  /**
   * 初始化视频上下文
   */
  initVideoContext() {
    this.videoContext = wx.createVideoContext('video-player');
  },
  
  /**
   * 播放视频
   */
  playVideo() {
    if (this.videoContext) {
      this.videoContext.play();
      this.setData({ isPlaying: true });
    }
  },
  
  /**
   * 暂停视频
   */
  pauseVideo() {
    if (this.videoContext) {
      this.videoContext.pause();
      this.setData({ isPlaying: false });
    }
  },
  
  /**
   * 视频播放事件处理
   */
  onVideoPlay() {
    this.setData({ isPlaying: true });
  },
  
  /**
   * 视频暂停事件处理
   */
  onVideoPause() {
    this.setData({ isPlaying: false });
  },
  
  /**
   * 视频结束事件处理
   */
  onVideoEnded() {
    this.setData({ isPlaying: false });
    // 可以在这里添加视频播放完成后的逻辑，比如显示相关推荐
  },
  
  /**
   * 视频播放错误处理
   */
  onVideoError(e) {
    console.error('视频播放错误:', e.detail);
    this.showError('视频播放出错');
  },
  
  /**
   * 显示错误提示
   */
  showError(message) {
    this.setData({ isLoading: false });
    wx.showToast({
      title: message,
      icon: 'none'
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    // 页面渲染完成后播放视频
    if (this.data.videoInfo && !this.data.isPlaying) {
      this.playVideo();
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    // 页面显示时恢复播放
    if (this.data.videoInfo && this.videoContext) {
      this.playVideo();
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
    // 页面隐藏时暂停播放
    if (this.videoContext) {
      this.pauseVideo();
    }
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    // 页面卸载时停止播放并释放资源
    if (this.videoContext) {
      this.pauseVideo();
      this.videoContext = null;
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    const { videoInfo } = this.data;
    if (videoInfo) {
      return {
        title: videoInfo.title || '美甲视频教程',
        path: `/packages/detail/pages/video-detail/video-detail?id=${videoInfo.id}`,
        imageUrl: videoInfo.coverUrl || '/static/分享图标.png'
      };
    }
    return {
      title: '美甲视频教程',
      path: '/pages/index/index',
      imageUrl: '/static/分享图标.png'
    };
  }
})
// app.js
// var unusedVar = 123;   // 使用 var 而不是 let/const
// function emptyFunc() { }  // 空函数
// function duplicateFunc() { }
// function duplicateFunc() { }  // 重复的函数声明

// 添加日志控制功能
const DEBUG_MODE = false; // 设置为false可以禁用大多数日志

// 保存原始console方法
const originalConsole = {
  log: console.log,
  warn: console.warn,
  error: console.error,
  info: console.info,
  debug: console.debug
};

// 重写console方法，仅在DEBUG_MODE为true时输出非错误日志
console.log = function(...args) {
  if (DEBUG_MODE) {
    originalConsole.log.apply(console, args);
  }
};

console.info = function(...args) {
  if (DEBUG_MODE) {
    originalConsole.info.apply(console, args);
  }
};

console.debug = function(...args) {
  if (DEBUG_MODE) {
    originalConsole.debug.apply(console, args);
  }
};

// 警告和错误始终保留，以便于排查问题
console.warn = originalConsole.warn;
console.error = originalConsole.error;

const originalShowToast = wx.showToast;
const originalShowLoading = wx.showLoading;
const originalShowModal = wx.showModal;

// 拦截Toast，使用官方方法立即隐藏
wx.showToast = function(options) {
  // 调用原始方法
  const result = originalShowToast.call(this, options);
  
  // 立即隐藏，使用官方API
  wx.hideToast();
  
  return result;
};

// 拦截Loading，使用官方方法立即隐藏
wx.showLoading = function(options) {
  // 调用原始方法
  const result = originalShowLoading.call(this, options);
  
  // 立即隐藏，使用官方API
  wx.hideLoading();
  
  return result;
};

// 重写微信的showModal方法，避免某些频繁的弹窗对用户造成干扰
wx.showModal = function (options) {
  // 配置无效时提示用户
  if (options && options.title === "授权已到期" || options && options.title === "授权验证" || 
      options && options.content && options.content.includes("授权")) {
    return {errMsg: "showModal:ok"};
  }
  
  // 其他所有弹窗都不显示，直接返回成功
  if (options && options.success) {
    setTimeout(() => options.success({confirm: true, cancel: false}), 0);
  }
  return {errMsg: "showModal:ok"};
};

const appConfig = require('./config/app-config.js');

/* global wx, console, setTimeout, setInterval, App, MutationObserver, document */

// 在App对象外部提前定义背景色设置函数
function setInitialBackgroundColor() {
  // 立即设置背景色，确保在应用启动前就应用
  try {
    wx.setBackgroundColor({
      backgroundColor: '#6B9FBC',
      backgroundColorTop: '#6B9FBC',
      backgroundColorBottom: '#11191F'
    });
  /* eslint-disable-next-line no-unused-vars */
  } catch (error) {
    // 捕获可能的异常但不处理，避免影响启动流程
  }
}

// 立即执行背景色设置，确保在应用初始化之前
setInitialBackgroundColor();

// 正则表达式检查是否为国内IP（1.0.0.0-126.255.255.255）
// const isChineseIPRegex = /^(?:[1-9]|[1-9][0-9]|1[0-1][0-9]|12[0-6])(?:\.(?:\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])){3}$/;

App({
  globalData: {
    // 数据存储
    gallery: {
      data: null,
      isComplete: false,
      hasMore: false    // 替代 hasMoreGalleryImages
    },
    
    // 用户信息
    userInfo: null,
    isAdmin: false,
    isPreloading: false,  // 移到顶层
    launchImagesPreloaded: false,
    configValid: false,
    appConfig: {
      local: {
        images: {
          // 移除 launchImages 配置
        }
      }
    },
    errorInfo: null,
    useOldLaunchPage: false,
    imageCache: {}, // 用于缓存图片
    productCache: {}, // 用于缓存产品信息
    launchImagePaths: [],
    launchImageCache: {},
    showLaunch: true, // 标记启动页是否显示
    networkType: 'unknown',
    // 配置相关功能标记
    configFlags: {
      verified: false,
      lastVerifyTime: 0,
      pendingVerify: false
    },
    // 预加载标志
    preloadFlags: {
      videosLoaded: false,
      galleryLoaded: false,
      cloudFunctionsReady: false
    },
    // 开关状态
    featureFlags: {
      enableTestVerification: false, // 是否启用测试验证
      enableVideoDetails: true,      // 是否启用视频详情页
      enableGallery: true,           // 是否启用图库页面
      enableLocalImages: true,       // 是否优先使用本地图片
      enableCloudFunctions: true,    // 是否启用云函数
      enableDebugMode: false,        // 是否启用调试模式
      enablePerformanceMonitoring: false, // 是否启用性能监控
      enableNetworkMonitoring: false  // 是否启用网络监控
    },
    remoteConfig: null,
    hostInfo: {
      name: null,
      version: null
    },
    systemInfo: null,
    zIndexLevels: {
      base: 1,
      content: 50,
      navbar: 100,
      fixed: 150,
      popup: 500,
      modal: 800,
      actionsheet: 900,
      dialog: 950,
      launch: 1000,
      toast: 1100
    },
    popupShowing: false,
    tabBarVisible: false, // 默认隐藏，等待启动页结束
    videoCache: new Map(),    // 视频缓存
    galleryCache: new Map(),  // 瀑布流缓存
    preloadedData: {
      videos: null,
      gallery: null,
      currentPage: 0,
      hasMore: true,
      isPreloading: false  // 防止重复预加载
    }
  },

  // 验证版权信息 - 移到App对象内部
  async verifyConfig() {
    try {
      // 不显示任何UI提示
      const result = await wx.cloud.callFunction({
        name: 'verifyConfig',
        data: {
          config: this.globalData.appConfig
        }
      });
      
      if (!result.result || !result.result.success) {
        this.globalData.configValid = false;
        showPersistentExpiredModal();
        return false;
      }
      
      this.globalData.configValid = true;
      return true;
    } catch {
      // 捕获到错误但忽略错误对象
      console.error('验证过程出错，允许继续使用');
      return true; // 出错时允许继续使用
    }
  },

  async onLaunch() {
    // 这里可能需要立即设置背景色
    wx.setBackgroundColor({
      backgroundColor: '#1F1D2B',  // 应该与最终背景色一致
      backgroundColorTop: '#1F1D2B',
      backgroundColorBottom: '#1F1D2B'
    });
    
    // 使用自定义导航栏控制
    wx.setStorageSync('tabBarVisible', false);
    
    // 立即隐藏所有可能的提示
    wx.hideToast();
    wx.hideLoading();
    
    // 设置全局标志，确保不会尝试加载旧的启动页
    this.globalData.useOldLaunchPage = false;
    
    // 并行初始化云环境和应用
    const initPromises = [];
    
    // 初始化云环境
    if (wx.cloud) {
      initPromises.push(new Promise((resolve) => {
        wx.cloud.init({
          env: appConfig.cloud.envId,
          traceUser: true,
          success: resolve,
          fail: resolve // 即使失败也继续
        });
      }));
    }
    
    // 将配置保存到全局数据
    this.globalData.appConfig = appConfig;
    
    // 启动应用初始化
    initPromises.push(this.initApp());
    
    // 启动页图片预加载
    this.preloadLaunchImages();
    
    // 添加全局层级变量
    this.globalData.zIndexLevels = {
      base: 1,
      content: 50,
      navbar: 100,
      fixed: 150,
      popup: 500,
      modal: 800,
      actionsheet: 900,
      dialog: 950,
      launch: 1000,
      toast: 1100
    };
    
    // 初始化全局状态
    this.globalData.showLaunch = true;
    this.globalData.popupShowing = false;
    
    // 判断是否是当天第一次启动
    const today = new Date().toDateString();
    const lastLaunchDate = wx.getStorageSync('lastLaunchDate');
    
    if (today !== lastLaunchDate) {
      // 如果是新的一天，重置启动页状态，让它再次显示
      wx.setStorageSync('hasShownLaunch', false);
      wx.setStorageSync('lastLaunchDate', today);
    }
    
    // 强制重置启动页显示标记
    wx.removeStorageSync('hasShownLaunch'); // 清除标记，确保启动页会显示
    wx.setStorageSync('launchPageShowing', true);
    
    // 启动时预加载所有数据
    await this.preloadAllData();
    
    // 延迟验证，在后台静默进行
    setTimeout(() => {
      this.silentVerify();
    }, 1000);

    // 新代码
    const windowInfo = wx.getWindowInfo();
    const appBaseInfo = wx.getAppBaseInfo();
    const deviceInfo = wx.getDeviceInfo();
    
    this.globalData.systemInfo = {
      windowHeight: windowInfo.windowHeight,
      windowWidth: windowInfo.windowWidth,
      pixelRatio: windowInfo.pixelRatio,
      platform: appBaseInfo.platform,
      brand: deviceInfo.brand,
      model: deviceInfo.model
    };
  },
  
  // 将原来的初始化逻辑移到单独的方法中
  async initApp() {
    // 原来onLaunch中的其他初始化代码
    console.log('初始化应用...');
    
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: res => {
              this.globalData.userInfo = res.userInfo
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
    
    // 初始化COS配置
    try {
      console.log('初始化COS配置...');
      const cosConfig = {
        secretId: appConfig.cos.secretId,
        secretKey: appConfig.cos.secretKey,
        region: appConfig.cos.region,
        bucket: appConfig.cos.bucket,
        baseUrl: appConfig.cos.baseUrl,
        folders: appConfig.cos.folders
      };
      
      const result = await wx.cloud.callFunction({
        name: 'initConfig',
        data: {
          cosConfig
        }
      });
      
      console.log('COS配置初始化结果:', result);
    } catch (error) {
      console.error('初始化COS配置失败:', error);
    }
    
    // 初始化本地资源配置
    console.log('初始化本地资源配置...');
    
    // 检查图标配置
    const localIcons = appConfig.local.icons;
    for (const key in localIcons) {
      const path = localIcons[key];
      console.log(`本地图标: ${key} => ${path}`);
    }
    
    // 添加这段代码，检查图片配置
    const localImages = appConfig.local.images;
    for (const key in localImages) {
      const path = localImages[key];
      console.log(`本地图片: ${key} => ${path}`);
    }
    
    // 其他初始化代码...
    
    // 启动定期验证
    this.startPeriodicVerification();
  },
  
  // 修改 onShow 方法
  onShow: function() {
    console.log('===== 应用显示 =====');
    
    // 延迟检查，确保页面已经渲染
    setTimeout(() => {
      // 检查当前页面的背景色
      const query = wx.createSelectorQuery();
      query.select('page').fields({
        computedStyle: ['background', 'backgroundColor']
      }, function(res) {
        console.log('页面显示时的背景色:', res);
      });
      query.exec();
    }, 100);
  },
  
  // 检查用户是否为管理员
  checkAdmin: function(callback) {
    wx.cloud.callFunction({
      name: 'checkAdmin',
      success: res => {
        console.log('检查管理员结果:', res.result)
        const isAdmin = res.result && res.result.isAdmin === true ? true : false
        this.globalData.isAdmin = isAdmin
        if (callback) callback(isAdmin)
      },
      fail: err => {
        console.error('检查管理员权限失败', err)
        this.globalData.isAdmin = false
        if (callback) callback(false)
      }
    })
  },

  // 添加全局图片工具
  imageUtil: {
    // 分析图片尺寸并返回布局信息
    analyzeImageSize(url) {
      return new Promise((resolve) => {
        wx.getImageInfo({
          src: url,
          success: (res) => {
            const { width, height } = res;
            const ratio = height / width;
            
            // 根据图片比例决定布局方式
            const layoutInfo = {
              isVertical: ratio > 1.2,  // 高宽比大于1.2认为是竖图
              isHorizontal: ratio < 0.8,  // 高宽比小于0.8认为是横图
              isSquare: ratio >= 0.8 && ratio <= 1.2,  // 接近正方形
              ratio: ratio,
              originalWidth: width,
              originalHeight: height
            };
            
            resolve(layoutInfo);
          },
          fail: (err) => this.handleError(err, 'analyzeImageSize')
        });
      });
    }
  },

  // 预加载方法
  async startPreload() {
    if (this.globalData.isPreloading) return;
    this.globalData.isPreloading = true;

    try {
      await this.preloadGallery();  // 只预加载图片
    } catch (err) {
      console.error('预加载失败:', err);
    } finally {
      this.globalData.isPreloading = false;
    }
  },

  // 添加完整的数据清理方法
  clearAllData() {
    // 清除本地存储
    try {
      wx.clearStorageSync();
    } catch(e) {
      console.error('清除存储失败:', e);
    }
  },

  // 获取系统信息的兼容方法，避免使用已弃用API
  getSystemInfo() {
    const systemInfo = {};
    try {
      // 获取设备信息
      const deviceInfo = wx.getDeviceInfo();
      // 获取窗口信息
      const windowInfo = wx.getWindowInfo();
      // 获取应用基本信息
      const appBaseInfo = wx.getAppBaseInfo();
      
      // 合并所有信息，保持与旧API兼容
      Object.assign(systemInfo, deviceInfo, windowInfo, appBaseInfo);
    } catch (e) {
      console.error('获取系统信息失败:', e);
      // 如果新API不可用，回退到旧API
      try {
        const legacyInfo = wx.getSystemInfoSync();
        Object.assign(systemInfo, legacyInfo);
      } catch (e) {
        console.error('获取系统信息完全失败:', e);
      }
    }
    return systemInfo;
  },

  // 添加统一的错误处理方法
  handleError: function(error, context) {
    console.error(`[${context}]错误:`, error);
    return null;
  },

  // 添加静默验证方法
  silentVerify: async function() {
    try {
      const result = await wx.cloud.callFunction({
        name: 'verifyConfig',
        data: {
          config: this.globalData.appConfig
        }
      });
      
      if (!result.result || !result.result.success) {
        this.globalData.configValid = false;
        
        // 只在授权到期时显示弹窗
        if (result.result && result.result.message === "授权已到期") {
          // 使用原始的showModal函数显示授权到期弹窗
          originalShowModal({
            title: '授权已到期',
            content: '您的美甲小程序授权已到期，请联系开发者续期。\n开发者: 骆刚\n微信: naildidi\n电话: 19925762035\n邮箱: 745765426@qq.com',
            showCancel: false,
            success: (res) => {
              if (res.confirm) {
                setTimeout(() => this.silentVerify(), 10000);
              }
            }
          });
        }
        return false;
      }
      
      this.globalData.configValid = true;
      return true;
    } catch {
      // 捕获错误但不使用错误对象
      console.error('静默验证过程出错，暂时允许继续使用');
      return true; // 出错时暂时允许继续使用
    }
  },

  // 启动定期验证，但不显示任何UI
  startPeriodicVerification() {
    // 每10分钟验证一次配置
    setInterval(async () => {
      this.silentVerify();
    }, 600000); // 10分钟
  },

  // 在 app.js 的 App 对象中添加
  checkExpiry: async function() {
    // 如果已知配置无效，直接显示弹窗
    if (!this.globalData.configValid) {
      showPersistentExpiredModal();
      return false;
    }
    
    try {
      const result = await wx.cloud.callFunction({
        name: 'verifyConfig',
        data: {
          config: this.globalData.appConfig
        }
      });
      
      if (!result.result || !result.result.success) {
        console.log('验证失败:', result.result ? result.result.message : '未知错误');
        this.globalData.configValid = false;
        showPersistentExpiredModal();
        return false;
      }
      
      return true;
    } catch (error) {
      console.error('验证过程出错:', error);
      return true; // 出错时暂时允许继续使用
    }
  },

  // 添加新方法
  setupUIObserver: function() {
    // 创建一个观察器实例
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.addedNodes && mutation.addedNodes.length) {
          for (let i = 0; i < mutation.addedNodes.length; i++) {
            const node = mutation.addedNodes[i];
            // 检查是否是验证相关的UI元素
            if (node.className && (
                node.className.includes('wx-toast') || 
                node.className.includes('wx-loading') ||
                node.className.includes('wx-modal')
              )) {
              // 检查内容是否包含验证相关文字
              const text = node.textContent || '';
              if (text.includes('验证') || text.includes('配置')) {
                // 隐藏元素
                node.style.display = 'none';
                node.style.opacity = '0';
                node.style.visibility = 'hidden';
              }
            }
          }
        }
      });
    });
    
    // 开始观察document.body的变化
    observer.observe(document.body, { 
      childList: true, 
      subtree: true 
    });
    
    // 保存观察器实例以便后续清理
    this.uiObserver = observer;
  },

  onError: function(error) {
    // 忽略所有与验证相关的错误
    if (error && (
        error.includes('验证') || 
        error.includes('配置') ||
        error.includes('toast') ||
        error.includes('modal') ||
        error.includes('loading')
      )) {
      return;
    }
    
    // 处理其他错误...
    console.error('应用错误:', error);
  },

  // 在 app.js 中添加
  async quickLocalVerify() {
    // 快速本地验证，不调用云函数
    try {
      // 检查当前时间是否超过设置的到期时间
      const currentTime = new Date();
      const expiryTime = new Date("2025-03-29T04:10:00.000Z");
      
      if (currentTime > expiryTime) {
        this.globalData.configValid = false;
        
        // 显示授权到期弹窗
        originalShowModal({
          title: '授权已到期',
          content: '您的美甲小程序授权已到期，请联系开发者续期。\n开发者: 骆刚\n微信: naildidi\n电话: 19925762035\n邮箱: 745765426@qq.com',
          showCancel: false
        });
        
        return false;
      }
      
      // 验证版权信息
      const config = this.globalData.appConfig;
      if (!config.copyright || 
          config.copyright.author !== "骆刚" || 
          config.copyright.contact !== "naildidi" ||
          config.copyright.license !== "商业授权" ||
          config.copyright.verificationCode !== "19925762035" ||
          config.copyright.email !== "745765426@qq.com") {
        
        this.globalData.configValid = false;
        return false;
      }
      
      // 本地验证通过
      this.globalData.configValid = true;
      return true;
    } catch {
      // 捕获错误但不使用错误对象
      console.error('本地验证出错，允许继续使用');
      // 出错时允许继续使用
      return true;
    }
  },

  preloadCloudFunction() {
    // 预热云函数，减少首次调用的延迟
    wx.cloud.callFunction({
      name: 'verifyConfig',
      data: { preload: true } // 只是预热，不执行实际验证
    }).catch(() => {
      // 忽略错误
    });
  },

  onPageNotFound(res) {
    console.error('页面不存在:', res);
  },

  preloadLaunchImages() {
    console.log('[APP] 启动页图片由组件自行加载，跳过应用层预加载');
    
    // 设置标志，表示应用层预加载已完成
    this.globalData.launchImagesPreloaded = true;
    
    // 移除对启动页图片的直接引用，由组件自行处理
    this.globalData.launchImagePaths = [];
  },

  // 修改onPopupStateChange方法，移除原生TabBar调用
  onPopupStateChange: function(isPopupShown) {
    // 保留全局状态记录功能
    this.globalData.popupShowing = isPopupShown;
    
    // 使用自定义导航栏控制方法代替原生API
    if (isPopupShown) {
      this.hideTabBar(); // 使用我们自己的方法
    } else {
      this.showTabBar(); // 使用我们自己的方法
    }
  },

  // 修改导航栏控制方法，仅控制自定义导航栏
  showTabBar: function() {
    console.log('[导航栏监测] App.showTabBar被调用');
    
    // 设置存储值
    wx.setStorageSync('tabBarVisible', true);
    
    // 尝试直接控制TabBar组件
    try {
      const pages = getCurrentPages();
      if (pages && pages.length > 0) {
        const currentPage = pages[pages.length - 1];
        if (typeof currentPage.getTabBar === 'function') {
          const tabBar = currentPage.getTabBar();
          if (tabBar) {
            tabBar.setData({ isVisible: true });
          }
        }
      }
    } catch (e) {
      console.error('[导航栏监测] 控制失败:', e);
    }
  },
  
  hideTabBar: function() {
    console.log('[导航栏监测] App.hideTabBar被调用');
    
    // 设置存储值
    wx.setStorageSync('tabBarVisible', false);
    
    // 尝试直接控制TabBar组件
    try {
      const pages = getCurrentPages();
      if (pages && pages.length > 0) {
        const currentPage = pages[pages.length - 1];
        if (typeof currentPage.getTabBar === 'function') {
          const tabBar = currentPage.getTabBar();
          if (tabBar) {
            tabBar.setData({ isVisible: false });
          }
        }
      }
    } catch (e) {
      console.error('[导航栏监测] 控制失败:', e);
    }
  },
  
  // 更新所有页面的导航栏
  updateTabBarVisibility(visible) {
    const pages = getCurrentPages();
    if (!pages || pages.length === 0) return;
    
    for (const page of pages) {
      if (typeof page.getTabBar === 'function') {
        const tabBar = page.getTabBar();
        if (tabBar) {
          tabBar.setData({ isVisible: visible });
        }
      }
    }
  },

  // 添加一个方法，用于在出现异常状态时强制重置导航栏状态
  forceResetTabBarState: function() {
    console.log('[导航栏追踪] 强制重置导航栏状态');
    
    // 清理所有可能影响状态的标记
    wx.removeStorageSync('popupShowing');
    wx.removeStorageSync('launchPageShowing');
    
    // 获取当前页面
    const pages = getCurrentPages();
    if (!pages || pages.length === 0) return;
    
    const currentPage = pages[pages.length - 1];
    
    // 检查当前页面状态，决定应该显示还是隐藏导航栏
    let shouldBeVisible = true;
    
    // 如果是首页，检查是否有弹窗或启动页
    if (currentPage.route.includes('index')) {
      if (currentPage.data.showLaunch || currentPage.data.showVideoDetail) {
        shouldBeVisible = false;
      }
    }
    
    // 设置正确的状态
    wx.setStorageSync('tabBarVisible', shouldBeVisible);
    
    // 强制更新所有页面的导航栏
    this.updateTabBarVisibility(shouldBeVisible);
  },

  // 新增预加载视频数据方法
  preloadVideoData() {
    if (!this.globalData.videoList || this.globalData.videoList.length === 0) {
      return this.loadVideoList();
    }
    return Promise.resolve(this.globalData.videoList);
  },
  
  // 视频数据加载
  loadVideoListData() {
    // 检查是否已加载
    if (this.globalData.videoList && this.globalData.videoList.length > 0) {
      return Promise.resolve(this.globalData.videoList);
    }
    
    // 加载视频数据
    return new Promise((resolve, reject) => {
      // 根据您的API实现数据加载
      // 完成后存储到 this.globalData.videoList
    });
  },
  
  // 预加载瀑布流数据
  preloadGalleryData() {
    // 预加载瀑布流数据
    if (!this.globalData.gallery) {
      this.globalData.gallery = {};
    }
    
    if (!this.globalData.gallery.data) {
      // 静默加载第一页数据
      wx.cloud.callFunction({
        name: 'getGalleryFiles',
        data: {
          skip: 0,
          limit: 20
        }
      }).then(res => {
        if (res.result && res.result.data) {
          this.globalData.gallery.data = res.result.data;
          
          // 预加载图片
          this.preloadImages(res.result.data);
        }
      }).catch(err => {
        console.error('预加载瀑布流数据失败:', err);
      });
    }
  },

  // 预加载图片
  preloadImages(images) {
    if (!images || !Array.isArray(images)) return;
    
    images.forEach(img => {
      if (img.url) {
        wx.getImageInfo({
          src: img.url,
          success: () => {
            // 图片预加载成功，不需要任何处理
          },
          fail: () => {
            // 预加载失败也不显示错误
          }
        });
      }
    });
  },

  // 添加 loadVideoList 函数
  loadVideoList() {
    return wx.cloud.callFunction({
      name: 'getVideoList',
      data: {
        skip: 0,
        limit: 20
      }
    }).then(res => {
      if (res.result && res.result.data) {
        this.globalData.videoList = res.result.data;
      }
      return res;
    });
  },

  async preloadAllData() {
    // 防止重复预加载
    if (this.globalData.preloadedData.isPreloading) return;
    
    this.globalData.preloadedData.isPreloading = true;
    
    try {
      const result = await wx.cloud.callFunction({
        name: 'getGalleryFiles',
        data: {
          skip: 0,
          limit: 20
        }
      });

      if (result && result.result && result.result.data) {
        this.globalData.preloadedData.gallery = result.result.data;
        this.globalData.preloadedData.hasMore = result.result.data.length === 20;
        this.globalData.preloadedData.currentPage = 1;
      }
    } catch (err) {
      console.error('预加载失败:', err);
    } finally {
      this.globalData.preloadedData.isPreloading = false;
    }
  },

  async preloadVideos() {
    if (this.globalData.preloadedData.videos) {
      return this.globalData.preloadedData.videos;
    }

    const result = await wx.cloud.callFunction({
      name: 'getVideoList'
    });
    return result.result.data;
  },

  async preloadGallery() {
    if (this.globalData.preloadedData.gallery) {
      return this.globalData.preloadedData.gallery;
    }

    const result = await wx.cloud.callFunction({
      name: 'getGalleryFiles'
    });
    return result.result.data;
  }
})

// 修改循环显示弹窗的函数
function showPersistentExpiredModal() {
  // 使用原始的 showModal 函数显示授权到期弹窗
  originalShowModal({
    title: '授权已到期',
    content: '您的美甲小程序授权已到期，请联系开发者续期。\n开发者: 骆刚\n微信: naildidi\n电话: 19925762035\n邮箱: 745765426@qq.com',
    showCancel: false,
    success: (res) => {
      if (res.confirm) {
        setTimeout(showPersistentExpiredModal, 10000);
      }
    }
  });
}

// index.js
const { courseConfig } = require('../../utils/config.js');
const zhuyeConfig = require('../../config/zhuye/config.js');
const qidongyeConfig = require('../../config/qidongye/images.js');

Page({
  data: {
    currentIndex: 0,
    topIndex: 0,
    showLaunch: true,
    launchOpacity: 1,
    courseList: [],  // 初始为空
    launchAnimation: null,
    launchImages: qidongyeConfig.launchImages,
    animationConfig: qidongyeConfig.animation,   // 获取动画配置
    styleConfig: qidongyeConfig.style,          // 获取样式配置
    topSlides: zhuyeConfig.topSlides,
    activeIcon: '',  // 当前激活的图标
    iconTapLock: false,  // 防止重复点击
    showVideo: false,
    currentVideo: null,
    texts: [],
    configVersion: 0  // 添加配置版本号
  },

  onLoad(options) {
    try {
      // 根据配置决定是否显示启动页
      this.setData({
        showLaunch: true,
        launchImages: qidongyeConfig.launchImages
      });

      // 设置课程列表数据
      this.setData({
        courseList: courseConfig.list.map((item, index) => ({
          id: index + 1,
          number: String(index + 1),
          bgColor: item.bgColor || '#4DC591',
          text: item.text,
          video: item.video
        }))
      });

      // 预加载详情页资源
      this.preloadDetailPage();

      const config = require('../../config/zhuye/config.js');
      this.setData({
        texts: this._processTexts(config.texts)
      });

    } catch (error) {
      console.error('启动页初始化错误:', error);
    }
  },

  onShow() {
    this.setData({
      showVideo: false,
      currentVideo: null
    });
    
    this._initList();
    this.refreshConfig();
  },

  _initList() {
    this.setData({
      courseList: courseConfig.list.map((item, index) => ({
        id: index + 1,
        number: String(index + 1),
        bgColor: item.bgColor || '#4DC591',
        text: item.text,
        video: item.video,
        _ready: true
      }))
    });
  },

  // 背景切换事件处理
  onBackgroundChange(e) {
    this.setData({
      currentIndex: e.detail.current
    });
  },

  // 顶部组件切换事件处理
  onTopChange(e) {
    this.setData({
      topIndex: e.detail.current
    });
  },

  // 触摸事件处理
  handleTouchStart() {
    // 创建动画实例
    const animation = wx.createAnimation({
      duration: 1200,  // 恢复原来的动画时间
      timingFunction: 'ease-out',
      delay: 0
    });
    
    // 设置渐隐动画
    animation.opacity(0).step();
    
    this.setData({
      launchAnimation: animation.export()
    });

    setTimeout(() => {
      this.setData({
        showLaunch: false
      });
    }, 1200);  // 保持与动画时间一致
  },

  handleIconTap(e) {
    if (this.data.iconTapLock) return;
    this.setData({ iconTapLock: true });

    const { icon } = e.currentTarget.dataset;
    this.setData({ activeIcon: icon });

    // 根据不同图标执行不同操作
    if (icon === 'product') {
      // 跳转到产品详情页面
      wx.navigateTo({
        url: '/pages/detail/index',
        fail: (error) => {
          console.error('跳转失败:', error);
        }
      });
    } else if (icon === 'course') {
      // 跳转到图片预览页面
      wx.navigateTo({
        url: '/pages/gallery/index',
        fail: (error) => {
          console.error('跳转失败:', error);
        }
      });
    }

    // 延时解锁点击
    setTimeout(() => {
      this.setData({ iconTapLock: false });
    }, 500);
  },

  preloadDetailPage() {
    // 预加载详情页需要的图片等资源
    const preloadImages = [
      'https://cdn.jsdelivr.net/gh/745765425/TUPIAN/2.png'
    ];
    
    Promise.all(preloadImages.map(url => {
      return new Promise((resolve, reject) => {
        wx.getImageInfo({
          src: url,
          success: (res) => resolve(res),
          fail: (err) => reject(err)
        });
      });
    }))
    .catch(error => {
      console.error('Image preload failed:', error);
    });
  },

  onHide() {
    this.setData({
      showVideo: false,
      currentVideo: null,
      launchImages: null,
      animationConfig: null,
      styleConfig: null
    });
  },

  handleItemClick(e) {
    const { index } = e.currentTarget.dataset;
    const item = this.data.courseList[index];
    
    if (!item || !item.video) {
      console.error('视频数据不存在');
      return;
    }
    
    const videoInfo = {
      videoUrl: item.video.url,
      title: item.video.title || item.text,
      subtitle: item.video.subtitle || '',
      description: item.video.description || '',
      popupColor: item.video.popupColor || '#FFFFFF'
    };
    
    this.setData({
      currentVideo: videoInfo,
      showVideo: true
    });
  },

  onVideoClose() {
    this.setData({
      showVideo: false,
      currentVideo: null
    });
  },

  onPageTap() {
    if (this.data.showVideo) {
      this.setData({
        showVideo: false,
        currentVideo: null
      });
    }
  },

  onItemTap(e) {
    const { index } = e.currentTarget.dataset;
    const item = this.data.texts[index];
    
    if (item.videoUrl) {
      this.setData({
        showVideo: true,
        currentVideo: {
          videoUrl: item.videoUrl,
          title: item.text,
          subtitle: item.subtitle || '',
          description: item.description || ''
        }
      });
    }
  },

  _processTexts(texts) {
    return texts.map(text => {
      const [content, color, videoUrl, ...rest] = text.split('|');
      return {
        text: content,
        color: color || '#FFFFFF',
        videoUrl: videoUrl || '',
        subtitle: rest[0] || '',
        description: rest[1] || ''
      };
    });
  },

  refreshConfig() {
    this.setData({
      configVersion: this.data.configVersion + 1
    });
  }
});

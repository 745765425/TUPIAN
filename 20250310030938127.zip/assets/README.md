# 静态资源目录

## 目录结构
- svg/
  - icons/     # 存放图标类 SVG 文件
  - images/    # 存放插图、背景等大型 SVG 文件
- images/      # 存放其他格式图片文件
- fonts/       # 存放字体文件

## 使用说明
1. icons 目录用于存放界面交互相关的小型图标
2. images 目录用于存放较大的 SVG 插图
3. 建议 SVG 文件使用小写字母命名，用横线分隔，如：menu-icon.svg 
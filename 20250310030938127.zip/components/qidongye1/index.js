const { launchImages } = require('../../config/qidongye/images.js');

Component({
  options: {
    pureDataPattern: /^_/, // 优化数据更新性能
    styleIsolation: 'shared', // 优化样式性能
  },

  properties: {
    interval: {
      type: Number,
      value: 3000  // 总间隔3秒
    },
    currentIndex: {
      type: Number,
      value: 0
    },
    type: {
      type: String,
      value: 'launch' // 'launch' 或 'main'
    }
  },

  data: {
    backgrounds: launchImages,
    activeIndex: 0,
    _observer: null, // pure data
    screenHeight: 0
  },

  lifetimes: {
    attached() {
      this.startTransition();  // 组件加载后开始轮换
      // 获取设备屏幕信息
      const systemInfo = wx.getSystemInfoSync();
      this.setData({
        screenHeight: systemInfo.windowHeight
      });
    },
    detached() {
      this.stopTransition();   // 组件卸载时停止轮换
    }
  },

  methods: {
    startTransition() {
      console.log('开始切换 - 当前索引:', this.data.activeIndex);
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
      
      this.intervalId = setInterval(() => {
        try {
          const nextIndex = (this.data.activeIndex + 1) % this.data.backgrounds.length;
          this.setData({
            activeIndex: nextIndex
          });
          this.triggerEvent('change', { current: nextIndex });
        } catch (error) {
          console.error('transition error:', error);
          clearInterval(this.intervalId);
        }
      }, this.data.interval);
    },

    stopTransition() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    }
  }
}); 
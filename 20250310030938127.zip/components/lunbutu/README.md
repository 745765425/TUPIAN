# 轮播图组件

## 功能描述
实现顶部图片轮播效果，支持自动切换和手动滑动。

## 特性
- 支持自动轮播
- 支持手动滑动
- 支持循环播放
- 自定义切换时间
- 自定义指示器样式

## 文件结构
```
components/zhuye/lunbo/swiper/
├── README.md           # 使用说明文档
├── index.js           # 组件逻辑
├── index.json         # 组件配置
├── index.wxml         # 组件模板
├── index.wxss         # 组件样式
└── config/            # 配置文件夹
    └── shuju.js       # 配置文件
```

## 使用方法

### 1. 引入组件
```json
{
  "usingComponents": {
    "custom-swiper": "/components/zhuye/lunbo/swiper/index"
  }
}
```

### 2. 使用组件
```wxml
<custom-swiper 
  autoplay="{{true}}"
  interval="5000"
  duration="800"
  circular="{{true}}"
  bind:change="onSwiperChange"
/>
```

### 3. 配置说明
可以通过修改 config/shuju.js 来自定义组件配置：
```javascript
module.exports = {
  // 轮播配置
  swiper: {
    autoplay: true,
    interval: 5000,
    duration: 800,
    circular: true
  },
  
  // 指示器样式配置
  indicator: {
    color: 'rgba(255, 255, 255, 0.4)',
    activeColor: '#FFFFFF'
  }
};
```

## 引用方式
1. 组件内部引用配置：
```javascript
// 在 index.js 中
const config = require('./config/shuju.js');
```

2. 跨组件引用：
```javascript
// 在其他组件中
const swiperConfig = require('/components/zhuye/lunbo/swiper/config/shuju.js');
```

## 注意事项
1. 图片资源建议使用 CDN
2. 控制图片大小，避免卡顿
3. 建议使用 webp 格式
4. 配置文件修改后需要重新编译
5. 注意内存管理，及时释放资源 
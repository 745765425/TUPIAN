Component({
  properties: {
    visible: {
      type: Boolean,
      value: false,
      observer(newVal) {
        if (newVal) {
          // 当弹窗显示时，确保视频自动播放
          wx.nextTick(() => {
            this.data.videoContext?.play();
          });
        }
      }
    },
    videoInfo: {
      type: Object,
      value: null
    }
  },

  data: {
    videoContext: null,
    isFullscreen: false,
    videoWidth: 0,
    videoHeight: 0,
    isMuted: true  // 默认静音
  },

  lifetimes: {
    attached() {
      this.initVideoContext();
    },
    detached() {
      this.cleanup();
    }
  },

  methods: {
    initVideoContext() {
      this.data.videoContext = wx.createVideoContext('videoPlayer', this);
      // 初始化后立即尝试播放，但保持静音
      if (this.properties.visible) {
        this.data.videoContext?.play();
      }
    },

    cleanup() {
      if (this.data.videoContext) {
        this.data.videoContext.stop();
        this.data.videoContext = null;
      }
    },

    onMaskClick() {
      if (!this.data.isFullscreen) {
        this.triggerEvent('close');
      }
    },

    onVideoLoaded(e) {
      const { width, height } = e.detail;
      this.setData({
        videoWidth: width,
        videoHeight: height
      });
      // 视频加载完成后尝试播放
      if (this.properties.visible) {
        this.data.videoContext?.play();
      }
    },

    onFullScreenChange(e) {
      const { fullScreen } = e.detail;
      if (fullScreen && this.data.videoWidth && this.data.videoHeight) {
        const direction = this.data.videoWidth > this.data.videoHeight ? 90 : 0;
        this.data.videoContext?.requestFullScreen({
          direction,
          duration: 0
        });
        // 全屏时取消静音
        this.setData({ isMuted: false });
      } else {
        // 退出全屏时恢复静音
        this.setData({ isMuted: true });
      }
      this.setData({ isFullscreen: fullScreen });
      
      // 确保继续播放
      if (!fullScreen) {
        this.data.videoContext?.play();
      }
    },

    // 监听视频播放状态
    onVideoPlay() {
      // 非全屏状态确保静音
      if (!this.data.isFullscreen) {
        this.setData({ isMuted: true });
      }
    }
  }
}); 
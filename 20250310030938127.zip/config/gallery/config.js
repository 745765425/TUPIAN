module.exports = {
  // 存储配置
  storage: {
    domain: 'http://sstg3vn9n.hn-bkt.clouddn.com/',  // 您的七牛云域名
  },
  
  // 页面配置
  pageConfig: {
    title: '美甲作品',
  }
}; 
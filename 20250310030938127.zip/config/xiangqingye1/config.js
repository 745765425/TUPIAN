/**
 * =====================================================
 * 详情页1配置文件 (xiangqingye1)
 * =====================================================
 * 
 * 【使用说明】
 * 1. 用记事本打开此文件
 * 2. 找到需要修改的卡片，修改 cardColor 的值
 * 3. 保存文件后刷新小程序即可看到效果
 * 
 * 【颜色代码参考】
 * 1. 常用颜色：
 *    - 原谅绿：#4DC591（默认）
 *    - 天空蓝：#87CEEB
 *    - 浅粉红：#FFB6C1
 *    - 淡紫色：#E6E6FA
 *    - 杏仁色：#FAF0D7
 *    - 薄荷绿：#98FF98
 *    - 珊瑚粉：#FF7F50
 *    - 淡青色：#E0FFFF
 *    - 金色：  #FFD700
 * 
 * 2. 如何修改颜色：
 *    找到 cardColor: "#4DC591" 这样的配置
 *    把 #4DC591 改成你想要的颜色代码
 *    
 * 3. 测试方法：
 *    - 先小范围测试，改一个卡片的颜色
 *    - 确认效果后再修改其他卡片
 *    - 不确定时可以使用上面提供的颜色代码
 * 
 * 【修改卡片颜色说明】
 * 1. 找到需要修改的卡片
 * 2. 找到 cardColor: "#4DC591" 这一行
 * 3. 把 #4DC591 改成您想要的颜色代码
 * 4. 保存文件，刷新小程序即可看到效果
 * 
 * 【常用颜色代码】
 * - 绿色：#4DC591
 * - 蓝色：#87CEEB
 * - 粉色：#FFB6C1
 * - 紫色：#E6E6FA
 * 
 * 【注意事项】
 * - 请不要修改其他任何内容
 * - 颜色代码必须以#开头
 * - 保存文件后需要刷新小程序
 */

/**
 * =====================================================
 * 详情页配置文件 - 卡片颜色修改指南
 * =====================================================
 * 
 * 【如何修改卡片颜色】
 * 1. 在下方找到要修改的卡片
 * 2. 修改 cardColor 后面的颜色代码
 * 3. 保存文件后刷新小程序即可看到效果
 * 
 * 【推荐颜色】
 * - 粉红：#FFB6C1  - 适合美甲作品展示
 * - 薄荷：#98FF98  - 清新自然风格
 * - 天蓝：#87CEEB  - 高级感风格
 * - 紫色：#E6E6FA  - 优雅风格
 * - 珊瑚：#FF7F50  - 活力风格
 * - 杏色：#FAF0D7  - 温柔风格
 * 
 * 【注意事项】
 * - 只修改颜色代码，不要改动其他内容
 * - 颜色代码必须以 # 开头
 * - 建议一次只改一个卡片，确认效果
 */

/**
 * =====================================================
 * 详情页卡片配置文件
 * =====================================================
 */

const config = `
↓↓↓ 基础信息配置区域 ↓↓↓

状态栏标题|喷绘起源
背景大图链接|https://cdn.jsdelivr.net/gh/745765425/TUPIAN/IMG_0785.JPG
讲师头像链接|https://cdn.jsdelivr.net/gh/745765425/TUPIAN/IMG_0785.JPG
讲师姓名|Miss 苟的
讲师职位|创始人
讲师简介|十六年美甲行业从事经验  |  十二年美甲行业崇尚经验
页面主标题|最新美甲喷绘课
页面副标题|掌握专业技能，打造完美美

↑↑↑ 基础信息配置结束 ↑↑↑

↓↓↓ 课程卡片配置区域 ↓↓↓

不不是美甲师。|美甲基础|入门课程|学习美甲的基本工具使用 掌握指甲形状修整技巧 让您轻松掌握基础技能
--->#FEBA7B|http://sstg3vn9n.hn-bkt.clouddn.com/IMG_8012.JPG
好的。|美甲基础|入门课程|学习美甲的基本工具使用 掌握指甲形状修整技巧 让您轻松掌握基础技能
--->#FEBA7B|https://cdn.jsdelivr.net/gh/745765425/TUPIAN/IMG_0785.JPG
我命由我不|美甲基础||学习美甲的基本工具使用 掌握指甲形状修整技巧 让您轻松掌握基础技能
--->#743799|https://cdn.jsdelivr.net/gh/745765425/TUPIAN/IMG_9979.webp
我命由我不|美甲进阶|专业课程|掌握进阶技巧 专业设计方法 高级教程内容
--->#E16BBA|https://cdn.jsdelivr.net/gh/745765425/TUPIAN/IMG_9979.webp
我命由我不|创意设计|高级课程|创意美甲设计 个性化风格 专业进阶课程
--->#4DC591|https://cdn.jsdelivr.net/gh/745765425/TUPIAN/IMG_9979.webp

↑↑↑ 配置区域结束 ↑↑↑
`.trim().split('\n').filter(line => !line.startsWith('↑') && !line.startsWith('↓') && line.trim());

// 解析基础信息配置
const baseConfig = {};
for (let i = 0; i < 8; i++) {
  const [key, value] = config[i].split('|');
  baseConfig[key] = value;
}

// 解析卡片配置
const cards = config.slice(8);
const courseList = [];
for (let i = 0; i < cards.length; i += 2) {
  const contentLine = cards[i];
  const resourceLine = cards[i + 1].replace('--->','');
  
  const [date, titleLine1, titleLine2, description] = contentLine.split('|');
  const [cardColor, image] = resourceLine.split('|');
  
  courseList.push({
    date,
    title: {
      line1: titleLine1,
      line2: titleLine2
    },
    description: {
      line1: description,
      line2: ''
    },
    cardColor,
    image
  });
}

// 导出配置
module.exports = {
  // ↓↓↓ 第一部分：顶部状态栏 ↓↓↓
  statusBar: {
    title: baseConfig['状态栏标题'],
  },

  // ↓↓↓ 第二部分：页面内容 ↓↓↓
  content: {
    // === 1. 顶部大图 ===
    heroImage: baseConfig['背景大图链接'],

    // === 2. 讲师信息 ===
    teacher: {
      avatar: baseConfig['讲师头像链接'],
      name: baseConfig['讲师姓名'],
      title: baseConfig['讲师职位'],
      description: baseConfig['讲师简介']
    },

    // === 4. 页面标题区域 ===
    pageTitle: {
      main: baseConfig['页面主标题'],
      sub: baseConfig['页面副标题'],
      style: {
        width: '704rpx',
        padding: '24rpx 32rpx',
        margin: '20rpx 0',
        background: 'rgba(255, 255, 255, 0.4)',
        left: '0rpx',
        top: '-27rpx',
        height: '206rpx'
      }
    },

    // === 5. 课程卡片 ===
    courseList,
    courseListStyle: {
      marginTop: '-120rpx'
    }
  },

  // 课程列表配置
  courseList: [
    {
      title: '美甲基础课程',
      desc: '专业美甲喷绘1年',
      // ...
    }
  ]
}
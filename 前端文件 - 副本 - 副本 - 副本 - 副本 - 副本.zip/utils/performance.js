export const Performance = {
  _marks: new Map(),
  _measures: new Map(),

  mark(name) {
    this._marks.set(name, Date.now());
  },

  measure(name, startMark, endMark) {
    const start = this._marks.get(startMark);
    const end = this._marks.get(endMark);
    
    if (start && end) {
      const duration = end - start;
      this._measures.set(name, duration);
      
      // 上报性能数据
      wx.reportAnalytics('performance_measure', {
        name,
        duration,
        timestamp: Date.now()
      });
      
      return duration;
    }
    return 0;
  },

  clearMarks() {
    this._marks.clear();
  },

  clearMeasures() {
    this._measures.clear();
  }
}; 
export const NetworkManager = {
  _status: {
    isConnected: true,
    networkType: 'unknown'
  },

  init() {
    // 监听网络状态
    wx.onNetworkStatusChange((res) => {
      this._status.isConnected = res.isConnected;
      this._status.networkType = res.networkType;
      this._handleNetworkChange(res);
    });

    // 获取初始网络状态
    wx.getNetworkType({
      success: (res) => {
        this._status.networkType = res.networkType;
        this._status.isConnected = res.networkType !== 'none';
      }
    });
  },

  _handleNetworkChange(res) {
    wx.reportAnalytics('network_change', {
      isConnected: res.isConnected,
      networkType: res.networkType,
      timestamp: Date.now()
    });

    // 网络状态变化时通知页面
    if (!res.isConnected) {
      wx.showToast({
        title: '网络连接已断开',
        icon: 'none',
        duration: 2000
      });
    }
  },

  getNetworkStatus() {
    return this._status;
  }
}; 
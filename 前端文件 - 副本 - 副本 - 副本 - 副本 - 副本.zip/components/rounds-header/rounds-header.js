Component({
  options: {
    styleIsolation: 'isolated'
  },

  properties: {
    title: {
      type: String,
      value: 'Rounds',
      observer(newVal) {
        if (typeof newVal !== 'string') {
          console.warn('title should be string')
        }
      }
    },
    current: {
      type: Number,
      value: 1,
      observer(newVal) {
        if (newVal < 1 || newVal > this.data.total) {
          console.warn('Invalid current value')
        }
      }
    },
    total: {
      type: Number,
      value: 1,
      observer(newVal) {
        if (newVal < 1) {
          console.warn('Total should be greater than 0')
        }
      }
    }
  },

  data: {
    top: 0
  },

  lifetimes: {
    attached() {
      try {
        const systemInfo = wx.getWindowInfo();
        const top = systemInfo.windowHeight - 520;
        this.setData({ top });
      } catch(e) {
        console.error('获取窗口信息失败:', e)
        this.setData({ top: 100 })
      }
    }
  }
}) 
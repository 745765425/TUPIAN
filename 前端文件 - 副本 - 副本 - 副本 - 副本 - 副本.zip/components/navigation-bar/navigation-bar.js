Component({
  options: {
    multipleSlots: true,
    styleIsolation: 'isolated',
    pureDataPattern: /^_/,
    virtualHost: true,
  },
  /**
   * 组件的属性列表
   */
  properties: {
    extClass: {
      type: String,
      value: '',
      optionalTypes: [String]
    },
    background: {
      type: String,
      value: '',
      observer(newVal) {
        const validColorFormat = /^(#[0-9A-Fa-f]{3,8}|(rgb|rgba)\([0-9\s,%.]+\)|transparent|var\(--[a-zA-Z-]+\))$/
        if (newVal && !validColorFormat.test(newVal)) {
          this._handleError(newVal, '背景色格式不正确')
          return 'transparent'
        }
        return newVal
      }
    },
    color: {
      type: String,
      value: '',
      observer(newVal) {
        if (newVal && !/^#|rgb|rgba/.test(newVal)) {
          this._handleError(newVal, '文字颜色格式不正确')
          return ''
        }
        return newVal
      }
    },
    animated: {
      // 显示隐藏的时候opacity动画效果
      type: Boolean,
      value: true
    },
    show: {
      // 显示隐藏导航，隐藏的时候navigation-bar的高度占位还在
      type: Boolean,
      value: true,
      observer: '_showChange'
    },
  },
  /**
   * 组件的初始数据
   */
  data: {
    _ready: false,
    _systemInfo: null,
    _metrics: {
      initTime: 0,
      renderTime: 0,
      errorCount: 0,
      styleUpdateCount: 0,  // 添加样式更新计数
      lastUpdateTime: 0     // 记录最后更新时间
    },
    displayStyle: '',
    ios: false,
    innerPaddingRight: '',
    leftWidth: '',
    safeAreaTop: '',
    navigationBarHeight: '',
    menuButtonHeight: '',
    statusBarHeight: ''
  },
  lifetimes: {
    created() {
      // 记录组件创建时间
      this._startTime = Date.now()
    },
    attached() {
      try {
        const menuButtonInfo = wx.getMenuButtonBoundingClientRect()
        // 使用新API替代getSystemInfo
        const windowInfo = wx.getWindowInfo()
        const deviceInfo = wx.getDeviceInfo()
        const appBaseInfo = wx.getAppBaseInfo()
        
        // 合并所需信息
        const systemInfo = {
          platform: appBaseInfo.platform,
          windowWidth: windowInfo.windowWidth,
          safeArea: windowInfo.safeArea,
          statusBarHeight: windowInfo.statusBarHeight,
          screenWidth: windowInfo.screenWidth,
          screenHeight: windowInfo.screenHeight
        }
        
        // 添加设备类型判断
        const isDevtools = appBaseInfo.platform === 'devtools'
        const isIOS = appBaseInfo.platform === 'ios'
        const isAndroid = appBaseInfo.platform === 'android'
        
        // 针对不同设备调整布局
        const statusBarHeight = windowInfo.statusBarHeight
        const menuButtonHeight = menuButtonInfo.height
        const navigationBarHeight = isIOS ? 44 : 48

        this.setData({
          ios: !isAndroid,
          innerPaddingRight: `padding-right: ${windowInfo.windowWidth - menuButtonInfo.left}px`,
          leftWidth: `width: ${windowInfo.windowWidth - menuButtonInfo.left}px`,
          navigationBarHeight: navigationBarHeight,
          menuButtonHeight: menuButtonHeight,
          statusBarHeight: statusBarHeight,
          safeAreaTop: `height: ${navigationBarHeight + statusBarHeight}px; padding-top: ${statusBarHeight}px`
        })
      } catch(e) {
        console.error('[navigation-bar] 初始化失败:', e)
      }
    },
    ready() {
      this.setData({ _ready: true })
      // 记录渲染完成时间
      this.data._metrics.renderTime = Date.now() - this._startTime
      // 上报性能指标
      this._reportPerformance()
    },
    detached() {
      this._optimizeMemory()
      this.data._ready = false
      this._startTime = null
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    _showChange(show) {
      if (!this.data._ready) return
      
      const style = this._calculateDisplayStyle(show, this.data.animated)
      this.setData({ displayStyle: style })
    },
    _calculateDisplayStyle(show, animated) {
      if (animated) {
        return `opacity: ${show ? '1' : '0'};transition:opacity 0.5s;`
      }
      return `display: ${show ? '' : 'none'}`
    },
    _reportPerformance() {
      const metrics = this.data._metrics
      
      // 只在开发环境下输出日志
      if (process.env.NODE_ENV === 'development') {
        console.info('[navigation-bar] Performance metrics:', Object.assign({}, {
          initTime: metrics.initTime,
          renderTime: metrics.renderTime,
          errorCount: metrics.errorCount,
          timestamp: new Date().toISOString()
        }))
      }
      
      // 只上报关键性能指标
      wx.reportPerformance && wx.reportPerformance('navigation_bar_render', metrics.renderTime)
    },
    _handleError(error, message) {
      // 避免频繁更新数据
      if (!this._errorTimer) {
        this._errorTimer = setTimeout(() => {
          this.data._metrics.errorCount++
          this._errorTimer = null
        }, 1000)
      }
      
      console.error('[navigation-bar]', {
        message,
        error: error instanceof Error ? error.message : error,
        timestamp: new Date().toISOString()
      })
    },
    _handleDegradation() {
      // 增强降级处理
      const defaultStyles = {
        ios: false,
        innerPaddingRight: '',
        leftWidth: '',
        safeAreaTop: '',
        displayStyle: ''
      }

      try {
        // 尝试使用简化布局
        this.setData(defaultStyles)
        
        // 重置错误计数
        this.data._metrics.errorCount = 0
        
        // 记录降级事件
        console.warn('[navigation-bar] 组件已降级运行，使用基础布局')
        
        // 上报降级事件
        wx.reportAnalytics && wx.reportAnalytics('navigation_bar_degradation', {
          timestamp: Date.now(),
          reason: '错误次数过多'
        })
      } catch (e) {
        console.error('[navigation-bar] 降级失败:', e)
      }
    },
    // 添加节流方法
    _throttleSetData(data, wait = 50) {
      const now = Date.now()
      if (now - this.data._metrics.lastUpdateTime >= wait) {
        this.setData(data)
        this.data._metrics.styleUpdateCount++
        this.data._metrics.lastUpdateTime = now
        return true
      }
      return false
    },
    // 添加防抖方法
    _debounceSetData(data, wait = 50) {
      if (this._debounceTimer) {
        clearTimeout(this._debounceTimer)
      }
      
      this._debounceTimer = setTimeout(() => {
        this._throttleSetData(data)
        this._debounceTimer = null
      }, wait)
    },
    // 优化性能检测
    _checkPerformance() {
      const metrics = this.data._metrics
      const now = Date.now()

      const performanceData = {
        renderTime: metrics.renderTime,
        styleUpdates: metrics.styleUpdateCount,
        timeSinceLastUpdate: now - metrics.lastUpdateTime,
        memoryInfo: this._getMemoryInfo()
      }

      // 性能警告检查
      this._checkPerformanceWarnings(performanceData)

      return performanceData
    },
    _getMemoryInfo() {
      if (!wx.getPerformance) return null
      
      try {
        const performance = wx.getPerformance()
        const memory = performance.memory
        return memory ? {
          total: memory.totalJSHeapSize,
          limit: memory.jsHeapSizeLimit,
          used: memory.usedJSHeapSize,
          ratio: memory.totalJSHeapSize / memory.jsHeapSizeLimit
        } : null
      } catch (e) {
        this._handleError(e, '获取内存信息失败')
        return null
      }
    },
    _checkPerformanceWarnings(data) {
      const warnings = []
      const thresholds = {
        render: 100,    // 渲染时间阈值（ms）
        update: 10,     // 更新次数阈值
        updateInterval: 1000,  // 更新间隔阈值（ms）
        memoryRatio: 0.8  // 内存使用率阈值
      }

      // 更细致的性能检查
      if (data.renderTime > thresholds.render) {
        warnings.push({
          type: 'render',
          level: data.renderTime > thresholds.render * 2 ? 'error' : 'warn',
          message: '渲染时间过长',
          value: data.renderTime,
          threshold: thresholds.render
        })
      }

      // 样式更新频率检查
      if (data.styleUpdates > thresholds.update && data.timeSinceLastUpdate < thresholds.updateInterval) {
        warnings.push({
          type: 'update',
          level: 'warn',
          message: '样式更新过于频繁',
          value: data.styleUpdates,
          threshold: thresholds.update
        })
      }

      // 内存使用检查
      if (data.memoryInfo && data.memoryInfo.ratio > thresholds.memoryRatio) {
        warnings.push({
          type: 'memory',
          level: 'warn',
          message: '内存使用率过高',
          value: (data.memoryInfo.ratio * 100).toFixed(2) + '%',
          threshold: thresholds.memoryRatio
        })
      }

      // 根据警告级别采取不同措施
      warnings.forEach(warning => {
        if (warning.level === 'error') {
          this._handleDegradation()
        }
        console.warn(`[navigation-bar] ${warning.level.toUpperCase()}:`, warning)
      })
    },
    _checkDeviceInfo() {
      try {
        const windowInfo = wx.getWindowInfo()
        const deviceInfo = wx.getDeviceInfo()
        const appBaseInfo = wx.getAppBaseInfo()
        
        console.info('[navigation-bar] 设备信息:', {
          brand: deviceInfo.brand,
          model: deviceInfo.model,
          platform: appBaseInfo.platform,
          system: deviceInfo.system,
          screenWidth: windowInfo.screenWidth,
          screenHeight: windowInfo.screenHeight,
          windowWidth: windowInfo.windowWidth,
          windowHeight: windowInfo.windowHeight,
          statusBarHeight: windowInfo.statusBarHeight,
          safeArea: windowInfo.safeArea
        })
      } catch(e) {
        console.error('[navigation-bar] 获取设备信息失败:', e)
      }
    },
    // 优化内存使用
    _optimizeMemory() {
      if (this.data._systemInfo) {
        this.data._systemInfo = null
      }
      if (this._debounceTimer) {
        clearTimeout(this._debounceTimer)
        this._debounceTimer = null
      }
    }
  },
})

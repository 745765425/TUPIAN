// app.js
import { Performance } from './utils/performance'

App({
  // 先声明 globalData
  globalData: {
    navHeight: 88,
    statusBarHeight: 0,
    contentHeight: 400,
    isDevTools: false,
    performance: Performance
  },

  onLaunch() {
    try {
      // 获取设备信息并保存
      const systemInfo = {
        deviceInfo: wx.getDeviceInfo(),
        windowInfo: wx.getWindowInfo(),
        appBaseInfo: wx.getAppBaseInfo()
      }
      
      // 更新 globalData
      this.globalData = {
        navHeight: 88,  // 固定导航栏高度
        statusBarHeight: systemInfo.windowInfo.statusBarHeight,
        contentHeight: 400,  // 固定内容区域高度
        isDevTools: systemInfo.appBaseInfo.platform === 'devtools',
        performance: Performance
      }

      // 设置统一的页面样式
      wx.setPageStyle({
        enablePullDownRefresh: false,
        disableScroll: true
      })

      // 使用新的API替代废弃的wx.getSystemInfo
      // 获取设备信息
      const deviceInfo = wx.getDeviceInfo()
      // 获取窗口信息
      const windowInfo = wx.getWindowInfo()
      // 获取基础信息
      const appBaseInfo = wx.getAppBaseInfo()
      
      // 设置全局系统信息缓存
      this.globalSystemInfo = {
        ...deviceInfo,
        ...windowInfo,
        ...appBaseInfo
      }
      
      // 根据设备性能调整渲染策略
      if (appBaseInfo.benchmarkLevel >= 1) {
        wx.setPageStyle({
          enableOptimize: true,
          enableTransparentTitle: true
        })
      }

      // 初始化性能监控
      this.globalData.performance.mark('appLaunch');
      
      // 错误监控
      wx.onError((error) => {
        this._handleGlobalError(error);
      });
      
      // 内存警告监控
      wx.onMemoryWarning((res) => {
        console.warn('内存警告', res.level);
        this._handleMemoryWarning(res);
      });
    } catch(e) {
      console.error('初始化失败:', e)
      // 使用默认值
      this.globalData = {
        navHeight: 88,
        statusBarHeight: 20,
        contentHeight: 400,
        isDevTools: false,
        performance: Performance
      }
    }
  },

  _handleGlobalError(error) {
    console.error('全局错误:', error);
    wx.reportAnalytics('global_error', {
      message: error.message || String(error),
      timestamp: Date.now()
    });
  },

  _handleMemoryWarning(res) {
    // 处理内存警告
    wx.reportAnalytics('memory_warning', {
      level: res.level,
      timestamp: Date.now()
    });
    
    // 清理非必要资源
    if (res.level >= 10) {
      // 清理缓存
      wx.clearStorage();
      // 通知页面清理资源
      this._notifyPagesCleanup();
    }
  },

  _notifyPagesCleanup() {
    const pages = getCurrentPages();
    pages.forEach(page => {
      if (typeof page._cleanupResources === 'function') {
        page._cleanupResources();
      }
    });
  },

  // 添加全局错误监控
  onError(error) {
    console.error('App Error:', error)
    // 可以添加错误上报逻辑
  },

  // 添加内存警告监控
  onMemoryWarning() {
    console.warn('Memory Warning')
    // 可以添加内存清理逻辑
  }
})

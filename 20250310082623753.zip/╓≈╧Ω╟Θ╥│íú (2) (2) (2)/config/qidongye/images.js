/**
 * 启动页配置文件
 * ====================================
 * 
 * 【启动页开关使用说明】
 * 1. enabled: true  - 开启启动页，小程序启动时会显示启动页动画
 * 2. enabled: false - 关闭启动页，小程序将直接进入主页面
 * 
 * 【如何修改】
 * 1. 找到下方 enabled 配置项
 * 2. 设置为 true 开启启动页
 * 3. 设置为 false 关闭启动页
 * 4. 保存文件后重新编译小程序即可生效
 * 
 * 【其他说明】
 * - 启动页图片可以自行更换，确保链接可以正常访问
 * - 建议使用 CDN 图片链接以获得更好的加载性能
 * - 建议使用 webp 格式图片以提升加载速度
 * - 可以根据需要增加或删减图片数量
 * 
 * 【图片设计规范】
 * 1. 标准尺寸：建议使用 750×1624 像素
 * 2. 安全区域：中心区域 750×1334 像素
 * 3. 延展区域：上下各预留 145 像素
 * 
 * 【设计建议】
 * 1. 重要内容放在安全区域内（750×1334）
 * 2. 背景和装饰性内容可以延展到边缘
 * 3. 如果使用纯色或渐变背景，建议延展到边缘
 * 4. 图片格式推荐使用 webp，控制大小在 300KB 以内
 */

module.exports = {
  // 启动页图片配置
  launchImages: [
    {
      id: 'launch1',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%90%AF%E5%8A%A8%E9%A1%B5/%E5%90%AF%E5%8A%A8%E9%A1%B51.webp'
    },
    {
      id: 'launch2',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%90%AF%E5%8A%A8%E9%A1%B5/%E5%90%AF%E5%8A%A8%E9%A1%B52.webp'
    },
    {
      id: 'launch3',
      url: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%90%AF%E5%8A%A8%E9%A1%B5/%E5%90%AF%E5%8A%A8%E9%A1%B53.webp'
    }
  ],

  // 动画配置
  animation: {
    duration: 1200,
    timingFunction: 'ease-out',
    delay: 0
  },

  // 样式配置
  style: {
    width: '100%',
    height: '100%'
  },

  images: [
    // 启动页图片配置
  ]
}; 
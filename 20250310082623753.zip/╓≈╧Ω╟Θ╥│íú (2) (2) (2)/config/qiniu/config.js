module.exports = {
  // 存储配置
  storage: {
    domain: 'http://ssdue7pv4.hn-bkt.clouddn.com/',
  },
}; 
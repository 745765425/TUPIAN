// app.js
App({
  onLaunch() {
    // 预加载一些必要资源
    try {
      // 添加错误处理
      const systemInfo = wx.getSystemInfoSync();
      
      // 确保systemInfo存在后再使用
      if (systemInfo) {
        console.log('系统信息:', systemInfo);
      } else {
        console.warn('获取系统信息失败');
      }
      
      // 使用新的 API 获取系统信息
      const deviceInfo = wx.getDeviceInfo();
      const windowInfo = wx.getWindowInfo();
      
      this.globalData.systemInfo = {
        ...systemInfo,
        ...deviceInfo,
        ...windowInfo
      };
      
      // 判断是否为 iPhone X 系列
      this.globalData.isIPhoneX = windowInfo.safeArea && 
        windowInfo.screenHeight - windowInfo.safeArea.bottom > 34;
    } catch (error) {
      console.error('初始化错误:', error);
    }
  },

  onError(error) {
    console.error('App Error:', error);
    if (error && error.message) {
      wx.showToast({
        title: '遇到一些问题，请稍后重试',
        icon: 'none'
      });
    }
  },

  onPageNotFound() {
    wx.redirectTo({
      url: '/pages/index/index'
    });
  },

  globalData: {
    userInfo: null,
    systemInfo: {
      SDKVersion: '',
      brand: '',
      safeArea: {
        bottom: 0,
        height: 0,
        left: 0,
        right: 0,
        top: 0,
        width: 0
      }
    },
    isIPhoneX: false
  }
});

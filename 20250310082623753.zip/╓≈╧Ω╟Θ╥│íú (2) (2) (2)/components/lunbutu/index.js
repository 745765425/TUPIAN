Component({
  properties: {
    autoplay: {
      type: Boolean,
      value: true
    },
    interval: {
      type: Number,
      value: 5000
    },
    duration: {
      type: Number,
      value: 800
    },
    circular: {
      type: Boolean,
      value: true
    }
  },

  data: {
    currentIndex: 0,
    images: [
      'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/%E9%A3%8E%E6%89%8744.webp',
      'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/5.webp',
      'http://ssdue7pv4.hn-bkt.clouddn.com/%E8%AF%A6%E6%83%85%E9%A1%B5%E4%B8%80/6.webp'
    ]
  },

  methods: {
    onSwiperChange(e) {
      const { current } = e.detail;
      this.setData({
        currentIndex: current
      });
      this.triggerEvent('change', { current });
    }
  }
}); 
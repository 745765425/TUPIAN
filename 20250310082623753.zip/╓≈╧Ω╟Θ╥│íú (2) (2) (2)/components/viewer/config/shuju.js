// 图片查看器配置
module.exports = {
  // 容器样式配置
  containerStyle: {
    width: '100%',
    height: '100%',
    // 使用 flex 布局代替绝对定位
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative'
  },

  // 图片加载配置
  imageProps: {
    mode: 'aspectFill',
    lazyLoad: true,
    webp: true,
    // 简化图片样式
    style: 'width:100%;height:100%;display:block'
  },

  // 阴影效果配置
  shadowStyle: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    // 使用更简单的背景色
    backgroundColor: 'rgba(0,0,0,0.03)'
  },

  // Skyline 特定的优化配置
  skylineConfig: {
    // 使用更具体的优化配置
    optimization: {
      enableHardwareAcceleration: true,
      renderMode: 'skyline'
    }
  }
}; 
// 引入配置
const zhuyeConfig = require('../../config/zhuye/config.js');

Component({
  options: {
    pureDataPattern: /^_/, // 优化数据更新性能
    styleIsolation: 'shared', // 优化样式性能
  },

  properties: {
    interval: {
      type: Number,
      value: 3000  // 总间隔3秒
    },
    currentIndex: {
      type: Number,
      value: 0
    },
    type: {
      type: String,
      value: 'main'
    },
    configVersion: {
      type: Number,
      value: 0,
      observer(newVal, oldVal) {
        this.reloadImages();
      }
    }
  },

  data: {
    backgrounds: zhuyeConfig.topSlides,
    activeIndex: 0,
    _observer: null,
  },

  lifetimes: {
    attached() {
      try {
        this.data._observer = wx.createIntersectionObserver(this, {
          thresholds: [0, 0.5, 1]
        });
        this.data._observer
          .relativeToViewport()
          .observe('.background-container', (res) => {
            if (res.intersectionRatio > 0) {
              this.startTransition();
            } else {
              this.stopTransition();
            }
          });
      } catch (error) {
        console.error('组件初始化错误:', error);
      }
    },
    detached() {
      try {
        if (this.intervalId) {
          clearInterval(this.intervalId);
          this.intervalId = null;
        }
        if (this.data._observer) {
          this.data._observer.disconnect();
        }
      } catch (error) {
        console.error('detached error:', error);
      }
    }
  },

  methods: {
    reloadImages() {
      const newConfig = require('../../config/zhuye/config.js');
      this.setData({
        backgrounds: newConfig.topSlides
      });
    },

    startTransition() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
      
      this.intervalId = setInterval(() => {
        try {
          const nextIndex = (this.data.activeIndex + 1) % this.data.backgrounds.length;
          
          this.setData({
            activeIndex: nextIndex
          });
          this.triggerEvent('change', { current: nextIndex });
        } catch (error) {
          console.error('切换图片错误:', error);
          clearInterval(this.intervalId);
        }
      }, this.data.interval);
    },

    stopTransition() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    }
  }
}); 
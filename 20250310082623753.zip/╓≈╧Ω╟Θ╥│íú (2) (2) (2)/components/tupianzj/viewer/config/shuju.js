// 图片查看器配置
module.exports = {
  // 默认图片尺寸比例配置
  aspectRatio: {
    portrait: '4/5',      // 纵向
    landscape: '3/2',     // 横向
    classic: '4/3'        // 经典
  },

  // 容器样式配置
  containerStyle: {
    width: 'calc(100% - 160rpx)',
    margin: '40rpx auto',
    borderRadius: '32rpx',
    background: '#f5f5f5'
  },

  // 图片加载配置
  imageProps: {
    mode: 'aspectFill',
    lazyLoad: false,
    webp: true
  },

  // 阴影效果配置
  shadowStyle: {
    boxShadow: '0 8rpx 24rpx rgba(0, 0, 0, 0.35)'
  }
}; 
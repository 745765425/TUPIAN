const { launchImages } = require('../../config/qidongye/images.js');

Component({
  options: {
    pureDataPattern: /^_/, // 优化数据更新性能
    styleIsolation: 'shared', // 优化样式性能
  },

  properties: {
    interval: {
      type: Number,
      value: 3000  // 这里是轮播间隔时间，现在是3秒
    },
    currentIndex: {
      type: Number,
      value: 0
    },
    type: {
      type: String,
      value: 'launch' // 'launch' 或 'main'
    }
  },

  data: {
    backgrounds: launchImages,
    activeIndex: 0,
    _observer: null, // pure data
    screenHeight: 0,
    firstImageShown: true,
    secondImageShown: false,
    thirdImageShown: false  // 添加第三张图片状态
  },

  lifetimes: {
    attached() {
      // 第一张图片直接显示并开始1.5秒淡出
      this.setData({
        activeIndex: 0,
        firstImageShown: true
      });
      
      // 第一张开始淡出
      setTimeout(() => {
        this.setData({
          firstImageShown: false
        });
      }, 0);

      // 0.9秒时开始第二张图的1.5秒淡入
      setTimeout(() => {
        this.setData({
          activeIndex: 1,
          secondImageShown: true
        });
      }, 900);

      // 2.5秒时开始第三张图的1.5秒淡入
      setTimeout(() => {
        this.setData({
          activeIndex: 2,
          thirdImageShown: true
        });
      }, 2500);
      
      // 获取设备屏幕信息
      const systemInfo = wx.getSystemInfoSync();
      this.setData({
        screenHeight: systemInfo.windowHeight
      });
    },
    detached() {
      this.stopTransition();   // 组件卸载时停止轮换
    }
  },

  methods: {
    startNormalTransition() {
      // 恢复正常的过渡时间
      this.setData({ fastTransition: false });
      
      // 从第二张图开始正常轮播
      if (this.intervalId) {
        clearInterval(this.intervalId);
      }
      
      this.intervalId = setInterval(() => {
        const nextIndex = (this.data.activeIndex + 1) % this.data.backgrounds.length;
        this.setData({ activeIndex: nextIndex });
      }, 3000);  // 后续图片保持3秒间隔
    },

    stopTransition() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    }
  }
}); 
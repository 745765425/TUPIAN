import config from '../../config/xiangqingye1/config.js'

Page({
  data: {
    statusBarHeight: wx.getWindowInfo().statusBarHeight,
    titleWidth: 0,
    config: config,
    pageData: {
      statusBarTitle: config.statusBar.title,
      heroImage: config.content.heroImage,
      teacherInfo: {
        avatar: config.content.teacher.avatar,
        name: config.content.teacher.name,
        title: config.content.teacher.title,
        description: config.content.teacher.description
      },
      pageTitle: {
        main: config.content.pageTitle.main,
        sub: config.content.pageTitle.sub
      },
      courseList: config.content.courseList.map(card => ({
        date: card.date,
        title: `${card.title.line1}\n${card.title.line2}`,
        description: `${card.description.line1}\n${card.description.line2}`,
        cardColor: card.cardColor,
        image: card.image
      }))
    }
  },

  onLoad: function(options) {
    this.updateTitleWidth()
  },

  onImageLoad(e) {
    console.log('图片加载成功', e.detail);
  },

  onImageError(e) {
    console.log('图片加载失败', e.detail);
    // 可以在这里处理加载失败的情况
  },

  onHeroImageLoad(e) {
    console.log('Hero image loaded');
  },

  onHeroImageError(e) {
    console.error('Hero image load failed:', e);
  },

  handleBack() {
    wx.navigateBack();
  },

  updateTitleWidth() {
    // 使用 nextTick 确保在文字渲染后计算
    wx.nextTick(() => {
      const query = wx.createSelectorQuery()
      query.selectAll('.main-title, .author-name')
        .fields({ size: true, dataset: true }, function(res) {
          if (res) {
            this.setData({
              titleWidth: Math.max(...res.map(item => item.width)) + 1
            })
          }
        }.bind(this))
        .exec()
    })
  }
}); 
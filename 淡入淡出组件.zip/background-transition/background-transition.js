import { CONFIG } from '../../config/backgrounds/config.js';
import { backgroundImages } from '../../config/backgrounds/images.js';

Component({
  properties: {
    // 自动切换间隔时间，单位毫秒
    interval: {
      type: Number,
      value: CONFIG.transition.interval
    }
  },

  data: {
    backgrounds: [],
    currentIndex: 0
  },

  lifetimes: {
    created() {
      console.log('Component created');
    },

    attached() {
      console.log('Component attached');
      this.setData({
        backgrounds: backgroundImages.backgrounds
      }, () => {
        console.log('Loaded backgrounds:', this.data.backgrounds);
        this.startTransition();
      });
    },

    ready() {
      console.log('Component ready');
    },

    detached() {
      if (this.timer) {
        clearInterval(this.timer);
      }
    }
  },

  methods: {
    startTransition() {
      this.timer = setInterval(() => {
        const nextIndex = (this.data.currentIndex + 1) % this.data.backgrounds.length;
        this.setData({ currentIndex: nextIndex });
      }, this.properties.interval);
    },

    onImageLoad(e) {
      console.log('Image loaded successfully:', e);
    },

    onImageError(e) {
      console.error('Image load failed:', e);
    },

    onSwiperChange(e) {
      const { current } = e.detail;
      this.setData({ currentIndex: current });
    },

    onImageTap(e) {
      console.log('Image tapped:', e.currentTarget.dataset);
      const link = e.currentTarget.dataset.link;
      if (link) {
        // 解析 card 参数
        const cardMatch = link.match(/card=(\w+)/);
        if (cardMatch) {
          const cardId = cardMatch[1];  // 例如 "card1"
          try {
            // 加载对应的详情配置
            const detail = require(`../../config/swiper/${cardId}/detail`);
            // 获取页面实例
            const pages = getCurrentPages();
            const currentPage = pages[pages.length - 1];
            // 调用页面的 showDetail 方法
            currentPage.showDetail(detail);
          } catch (error) {
            console.error('加载详情配置失败:', error);
          }
        }
      }
    }
  }
}); 
# Background Transition 背景过渡组件

一个用于实现背景图片优雅淡入淡出效果的小程序组件。

## 功能特点

- 支持多张背景图片自动轮播
- 平滑的淡入淡出过渡效果
- 可配置过渡时间和间隔
- 支持图片预加载
- 支持点击事件处理

## 安装步骤

1. 复制组件文件夹到你的项目中：
```
components/
   └── background-transition/
       ├── background-transition.js    # 组件逻辑
       ├── background-transition.wxml  # 组件模板
       ├── background-transition.wxss  # 组件样式
       ├── background-transition.json  # 组件配置
       └── README.md                  # 使用说明
```

2. 复制配置文件夹：
```
config/
   └── backgrounds/
       ├── config.js       # 全局配置
       ├── images.js       # 背景图片配置
       └── images.json     # 图片详细信息
```

## 配置文件内容

### 1. config/backgrounds/config.js
```javascript
export const CONFIG = {
  transition: {
    interval: 5000,      // 切换间隔时间（毫秒）
    duration: 1500,      // 过渡动画持续时间（毫秒）
    timing: 'ease-out'   // 过渡动画类型
  },
  features: {
    showTopSwiper: true  // 是否显示顶部轮播
  }
};
```

### 2. config/backgrounds/images.js
```javascript
export const backgroundImages = {
  backgrounds: [
    {
      id: 1,
      imageUrl: "背景图片1的URL",
      title: "标题1",
      description: "描述文本1",
      linkTo: "card=card1"  // 点击跳转链接
    },
    {
      id: 2,
      imageUrl: "背景图片2的URL",
      title: "标题2",
      description: "描述文本2",
      linkTo: "card=card2"
    }
  ]
};
```

## 使用方法

### 1. 在页面的 json 文件中注册组件
```json
{
  "usingComponents": {
    "background-transition": "/components/background-transition/background-transition"
  }
}
```

### 2. 在页面中使用组件
```xml
<background-transition interval="5000" />
```

## 组件属性说明

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| interval | Number | 5000 | 图片切换间隔（毫秒） |
| autoplay | Boolean | true | 是否自动播放 |
| circular | Boolean | true | 是否循环播放 |

## 注意事项

1. 图片资源建议：
   - 尺寸建议：750x1334px（适配大多数手机屏幕）
   - 格式建议：webp 或 jpg
   - 大小建议：不超过 200KB

2. 性能优化：
   - 建议使用 CDN 加速图片加载
   - 图片数量建议不超过 5 张
   - 可以使用 webp 格式减小图片体积

## 更新记录

- v1.0.0 (2024-03)
  - 首次发布
  - 实现基础淡入淡出效果
  - 支持自定义配置 
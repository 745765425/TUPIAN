export const CONFIG = {
  // 全局功能开关
  features: {
    showBottomSwiper: false,  // 默认使用新版淡入淡出主题
    showTopSwiper: true      // 保持顶部轮播可用
  },
  version: Date.now(),
  transition: {
    duration: 500,    // 动画持续时间，单位毫秒
    timing: 'linear',  // 使用线性过渡更平滑
    interval: 5000     // 切换间隔时间，单位毫秒
  },
  imageBaseUrl: 'http://ssdue7pv4.hn-bkt.clouddn.com/%E5%BC%B9%E5%85%A5%E5%BC%B9%E5%87%BA%E5%9B%BE%E7%89%87%E6%B5%8B%E8%AF%95%E3%80%82/'
}; 
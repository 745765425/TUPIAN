/**
 * 首页轮播图配置文件 - 可以用记事本打开编辑
 * 
 * 简单替换图片的步骤：
 * 1. 用记事本打开这个文件
 * 2. 找到需要替换的图片链接（在 imageUrl 后面的引号中）
 * 3. 把新的图片链接粘贴进去（替换掉旧的链接）
 * 4. 保存文件（Ctrl+S）
 * 5. 回到小程序开发工具，点击"编译"按钮
 * 
 * 注意：
 * - 只修改引号里面的图片链接
 * - 其他内容建议不要改动
 * - 记得保持引号完整
 * - 每张图片都要以 .webp 或 .jpg 结尾
 * 
 * 图片要求：
 * - 尺寸：宽750像素 x 高800像素
 * - 格式：webp或jpg
 * - 大小：不要超过200KB
 */

export const backgroundImages = {
  backgrounds: [
    {
      "id": "bg1",  // 第1张图片配置
      "imageUrl": "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%BC%B9%E5%85%A5%E5%BC%B9%E5%87%BA%E5%9B%BE%E7%89%87%E6%B5%8B%E8%AF%95%E3%80%82/111.webp",  // 确保这个链接可访问
      "type": "url",  // 不要修改
      "title": "美甲喷绘",  // 可以修改标题
      "linkTo": "?card=card1",  // 简化参数
      "color": "#000000",  // 文字颜色，可以根据图片风格调整
      "description": "第一张背景图"  // 可以修改描述
    },
    {
      "id": "bg2",  // 第二张图片配置
      "imageUrl": "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%BC%B9%E5%85%A5%E5%BC%B9%E5%87%BA%E5%9B%BE%E7%89%87%E6%B5%8B%E8%AF%95%E3%80%82/2222.webp",  // 替换此URL更换第二张图片
      "type": "url",
      "title": "专业教程",
      "linkTo": "?card=card2",  // 简化参数
      "color": "#1a1a1a",
      "description": "第二张背景图"
    },
    {
      "id": "bg3",  // 第三张图片配置
      "imageUrl": "http://ssdue7pv4.hn-bkt.clouddn.com/%E5%BC%B9%E5%85%A5%E5%BC%B9%E5%87%BA%E5%9B%BE%E7%89%87%E6%B5%8B%E8%AF%95%E3%80%82/3333.webp",  // 替换此URL更换第三张图片
      "type": "url",
      "title": "技术学习",
      "linkTo": "?card=card3",  // 简化参数
      "color": "#2a2a2a",
      "description": "第三张背景图"
    }
  ]
};

/**
 * 注意事项：
 * 1. 只需要修改 imageUrl 的值即可更换图片
 * 2. 图片链接必须是可访问的完整URL
 * 3. 建议使用CDN或对象存储的图片链接
 * 4. 修改后需要重新编译小程序才能看到效果
 * 5. 保持数组中的三张图片结构不变
 * 
 * 图片要求：
 * - 建议尺寸：750x800像素
 * - 格式：webp（推荐）或jpg
 * - 大小：建议小于200KB
 * 
 * 修改步骤：
 * 1. 准备好新的图片并上传到图床获取URL
 * 2. 复制新的URL替换对应的 imageUrl 值
 * 3. 保存此文件
 * 4. 在开发工具中点击"编译"
 */ 